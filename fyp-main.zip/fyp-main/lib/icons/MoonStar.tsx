import { MoonStar } from 'lucide-react-native';
import { iconWithClassName } from './iconWithClassName';
iconWithClassName(MoonStar);
export { MoonStar };