import { X } from 'lucide-react-native';
import { iconWithClassName } from './iconWithClassName';
iconWithClassName(X);
export { X };