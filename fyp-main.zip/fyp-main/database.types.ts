export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      comments_replies: {
        Row: {
          comment_id: number | null
          content: string | null
          created_at: string
          id: number
          user_id: number | null
        }
        Insert: {
          comment_id?: number | null
          content?: string | null
          created_at?: string
          id?: number
          user_id?: number | null
        }
        Update: {
          comment_id?: number | null
          content?: string | null
          created_at?: string
          id?: number
          user_id?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "comments_replies_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "posts_replies_comment_id_fkey"
            columns: ["comment_id"]
            isOneToOne: false
            referencedRelation: "posts_comments"
            referencedColumns: ["id"]
          },
        ]
      }
      destination: {
        Row: {
          id: number
          location: string | null
        }
        Insert: {
          id?: number
          location?: string | null
        }
        Update: {
          id?: number
          location?: string | null
        }
        Relationships: []
      }
      favourite: {
        Row: {
          contentID: number | null
          created_at: string
          id: number
          type: string | null
        }
        Insert: {
          contentID?: number | null
          created_at?: string
          id?: number
          type?: string | null
        }
        Update: {
          contentID?: number | null
          created_at?: string
          id?: number
          type?: string | null
        }
        Relationships: []
      }
      feed_trips: {
        Row: {
          created_at: string
          id: number
          trips: number
        }
        Insert: {
          created_at?: string
          id?: number
          trips: number
        }
        Update: {
          created_at?: string
          id?: number
          trips?: number
        }
        Relationships: [
          {
            foreignKeyName: "feed_trips_trips_fkey"
            columns: ["trips"]
            isOneToOne: false
            referencedRelation: "trips"
            referencedColumns: ["id"]
          },
        ]
      }
      follow: {
        Row: {
          created_at: string
          following: number | null
          id: number
          user_id: number | null
        }
        Insert: {
          created_at?: string
          following?: number | null
          id?: number
          user_id?: number | null
        }
        Update: {
          created_at?: string
          following?: number | null
          id?: number
          user_id?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "follow_following_fkey"
            columns: ["following"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "follow_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      hashtags: {
        Row: {
          created_at: string
          hashtag: string
          id: number
          number: number | null
        }
        Insert: {
          created_at?: string
          hashtag: string
          id?: number
          number?: number | null
        }
        Update: {
          created_at?: string
          hashtag?: string
          id?: number
          number?: number | null
        }
        Relationships: []
      }
      post_likes: {
        Row: {
          created_at: string
          id: number
          post_id: number | null
          uesr_id: number | null
        }
        Insert: {
          created_at?: string
          id?: number
          post_id?: number | null
          uesr_id?: number | null
        }
        Update: {
          created_at?: string
          id?: number
          post_id?: number | null
          uesr_id?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "post_likes_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "post_likes_uesr_id_fkey"
            columns: ["uesr_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      posts: {
        Row: {
          content: string | null
          created_at: string
          created_by: number | null
          hashtags: string[] | null
          id: number
          likes: number | null
          title: string | null
          title_image: string | null
          trips: number | null
          visibility: Database["public"]["Enums"]["visbility"] | null
        }
        Insert: {
          content?: string | null
          created_at?: string
          created_by?: number | null
          hashtags?: string[] | null
          id?: number
          likes?: number | null
          title?: string | null
          title_image?: string | null
          trips?: number | null
          visibility?: Database["public"]["Enums"]["visbility"] | null
        }
        Update: {
          content?: string | null
          created_at?: string
          created_by?: number | null
          hashtags?: string[] | null
          id?: number
          likes?: number | null
          title?: string | null
          title_image?: string | null
          trips?: number | null
          visibility?: Database["public"]["Enums"]["visbility"] | null
        }
        Relationships: [
          {
            foreignKeyName: "posts_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "posts_trips_fkey"
            columns: ["trips"]
            isOneToOne: false
            referencedRelation: "trips"
            referencedColumns: ["id"]
          },
        ]
      }
      posts_comments: {
        Row: {
          content: string
          created_at: string
          id: number
          post_id: number
          reply_id: number | null
          user_id: number
        }
        Insert: {
          content: string
          created_at?: string
          id?: number
          post_id: number
          reply_id?: number | null
          user_id: number
        }
        Update: {
          content?: string
          created_at?: string
          id?: number
          post_id?: number
          reply_id?: number | null
          user_id?: number
        }
        Relationships: [
          {
            foreignKeyName: "posts_comments_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "posts_comments_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      saved: {
        Row: {
          created_at: string
          id: number
          post_id: number | null
          trip_id: number | null
          type: Database["public"]["Enums"]["save_type"] | null
          user_id: number | null
        }
        Insert: {
          created_at?: string
          id?: number
          post_id?: number | null
          trip_id?: number | null
          type?: Database["public"]["Enums"]["save_type"] | null
          user_id?: number | null
        }
        Update: {
          created_at?: string
          id?: number
          post_id?: number | null
          trip_id?: number | null
          type?: Database["public"]["Enums"]["save_type"] | null
          user_id?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "saved_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "saved_trip_id_fkey"
            columns: ["trip_id"]
            isOneToOne: false
            referencedRelation: "trips"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "saved_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      trips: {
        Row: {
          created_at: string
          created_by: number
          id: number
          trip: Json | null
          visibility: Database["public"]["Enums"]["visbility"]
        }
        Insert: {
          created_at?: string
          created_by: number
          id?: number
          trip?: Json | null
          visibility?: Database["public"]["Enums"]["visbility"]
        }
        Update: {
          created_at?: string
          created_by?: number
          id?: number
          trip?: Json | null
          visibility?: Database["public"]["Enums"]["visbility"]
        }
        Relationships: [
          {
            foreignKeyName: "trips_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      users: {
        Row: {
          created_at: string
          email: string | null
          id: number
          name: string | null
          post_liked: string[] | null
          uuid: string | null
        }
        Insert: {
          created_at?: string
          email?: string | null
          id?: number
          name?: string | null
          post_liked?: string[] | null
          uuid?: string | null
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: number
          name?: string | null
          post_liked?: string[] | null
          uuid?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      save_type: "TRIP" | "POST"
      transport_type: "CAR" | "PUBLIC_TRANSPORT" | "WALK"
      trip_content_type: "LOCATION" | "TRANSPORT" | "NOTES"
      visbility: "PUBLIC" | "LINK_ONLY" | "PRIVATE"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type PublicSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  PublicTableNameOrOptions extends
    | keyof (PublicSchema["Tables"] & PublicSchema["Views"])
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
        Database[PublicTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
      Database[PublicTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : PublicTableNameOrOptions extends keyof (PublicSchema["Tables"] &
        PublicSchema["Views"])
    ? (PublicSchema["Tables"] &
        PublicSchema["Views"])[PublicTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  PublicEnumNameOrOptions extends
    | keyof PublicSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends PublicEnumNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = PublicEnumNameOrOptions extends { schema: keyof Database }
  ? Database[PublicEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : PublicEnumNameOrOptions extends keyof PublicSchema["Enums"]
    ? PublicSchema["Enums"][PublicEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof PublicSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof PublicSchema["CompositeTypes"]
    ? PublicSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never
