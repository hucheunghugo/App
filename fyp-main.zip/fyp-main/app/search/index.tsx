import React, { useState, useEffect, useCallback } from 'react';
import { View, TextInput, FlatList, Text, TouchableOpacity, Image, ActivityIndicator } from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { SafeAreaView } from "react-native-safe-area-context";
import { ChevronLeft, Calendar, MapPin, Heart, User } from "lucide-react-native";
import { useRouter } from "expo-router";

// Define types for our data structure
interface TripLocation {
  type: string;
  name?: string;
  description?: string;
  img_url?: string;
  content?: {
    name: string;
    description: string;
    img_url: string;
  };
}

interface TripDay {
  day?: string;
  comments?: string;
  itinerary?: TripLocation[];
}

interface Trip {
  id: number;
  created_at: string;
  created_by: number;
  trip: {
    title?: string;
    name?: string;
    description: string;
    dateFrom: string;
    dateTo: string;
    day?: TripLocation[][];
    itineraries?: TripDay[];
  };
  visibility: string;
  users: {
    id: number;
    name: string;
    email: string | null;
  };
}

interface Post {
  id: number;
  title: string;
  content: string;
  created_at: string;
  created_by: number | null;
  hashtags: string[] | null;
  likes: number;
  title_image: string | null;
  trips: any | null;
  visibility: string;
  users: any | null;
}

interface SearchResponse {
  trips: Trip[];
  posts: Post[];
  meta: {
    query: string;
    limit: number;
    offset: number;
  };
}

// Custom hook for debounced search
const useDebouncedSearch = (searchTerm: string) => {
  const [debouncedValue, setDebouncedValue] = useState(searchTerm);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedValue(searchTerm);
    }, 500);

    return () => clearTimeout(timer);
  }, [searchTerm]);

  return useQuery<SearchResponse>({
    queryKey: ['search', debouncedValue],
    queryFn: async () => {
      if (!debouncedValue.trim() || debouncedValue.length < 2) {
        return { trips: [], posts: [], meta: { query: '', limit: 10, offset: 0 } };
      }

      try {
        const response = await fetch(
          `${process.env.EXPO_PUBLIC_API_URL}/api/lookup?query=${encodeURIComponent(debouncedValue)}`
        );

        return response.json();
      } catch (error) {
        console.error('Search error:', error);
        return { trips: [], posts: [], meta: { query: debouncedValue, limit: 10, offset: 0 } };
      }
    },
    enabled: debouncedValue.length >= 2,
  });
};

// Format date range for display
const formatDateRange = (from: string, to: string) => {
  const fromDate = new Date(from);
  const toDate = new Date(to);

  const options: Intl.DateTimeFormatOptions = { month: 'short', day: 'numeric' };
  return `${fromDate.toLocaleDateString('en-US', options)} - ${toDate.toLocaleDateString('en-US', options)}`;
};

// Get trip title (handles different data structures)
const getTripTitle = (trip: Trip) => {
  return trip.trip.title || trip.trip.name || 'Unnamed Trip';
};

// Get first image from trip
const getTripImage = (trip: Trip) => {
  if (trip.trip.day && trip.trip.day.length > 0 && trip.trip.day[0].length > 0) {
    return trip.trip.day[0][0].img_url;
  } else if (trip.trip.itineraries && trip.trip.itineraries.length > 0 &&
             trip.trip.itineraries[0].itinerary && trip.trip.itineraries[0].itinerary.length > 0) {
    return trip.trip.itineraries[0].itinerary[0].content?.img_url;
  }
  return 'https://images.unsplash.com/photo-1518684079-3c830dcef090?q=80&w=2069&auto=format&fit=crop';
};

export default function SearchScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'trips' | 'posts'>('all');
  const router = useRouter();

  const { data, isLoading, isError } = useDebouncedSearch(searchQuery);

  const filteredResults = useCallback(() => {
    if (!data) return { trips: [], posts: [] };

    if (activeTab === 'all') return data;
    if (activeTab === 'trips') return { ...data, posts: [] };
    if (activeTab === 'posts') return { ...data, trips: [] };

    return data;
  }, [data, activeTab]);

  const handleSearchChange = useCallback((text: string) => {
    setSearchQuery(text);
  }, []);

  const renderTripItem = ({ item }: { item: Trip }) => (
    <TouchableOpacity
      className="mb-4 bg-white rounded-lg overflow-hidden shadow-sm"
      onPress={() => router.push({pathname:'/trip',params: { id: item.id }})}
    >
      <Image
        source={{ uri: getTripImage(item) }}
        className="w-full h-40"
        style={{ resizeMode: 'cover' }}
      />
      <View className="p-3">
        <Text className="text-lg font-bold text-gray-800">{getTripTitle(item)}</Text>
        <View className="flex-row items-center mt-1">
          <Calendar size={14} color="#6b7280" />
          <Text className="text-sm text-gray-500 ml-1">
            {formatDateRange(item.trip.dateFrom, item.trip.dateTo)}
          </Text>
        </View>
        <View className="flex-row items-center mt-1">
          <User size={14} color="#6b7280" />
          <Text className="text-sm text-gray-500 ml-1">
            {item.users.name}
          </Text>
        </View>
        {item.trip.description && (
          <Text className="text-sm text-gray-600 mt-2" numberOfLines={2}>
            {item.trip.description}
          </Text>
        )}
      </View>
    </TouchableOpacity>
  );

  const renderPostItem = ({ item }: { item: Post }) => (
    <TouchableOpacity
      className="mb-4 bg-white rounded-lg overflow-hidden shadow-sm p-3"
      onPress={() => router.push({pathname:'/posts',params: { id: item.id }})}
    >
      <Text className="text-lg font-bold text-gray-800">{item.title}</Text>
      <View className="flex-row items-center justify-between mt-1">
        <Text className="text-xs text-gray-500">
          {new Date(item.created_at).toLocaleDateString()}
        </Text>
        <View className="flex-row items-center">
          <Heart size={14} color="#6b7280" />
          <Text className="text-sm text-gray-500 ml-1">{item.likes}</Text>
        </View>
      </View>
      <Text className="text-sm text-gray-600 mt-2" numberOfLines={3}>
        {item.content}
      </Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="p-4">
        {/* Header */}
        <View className="flex-row items-center gap-2 mb-4">
          <TouchableOpacity onPress={() => router.back()}>
            <ChevronLeft size={24} color="black" />
          </TouchableOpacity>
          <Text className="text-2xl font-bold">Search</Text>
        </View>

        {/* Search Input */}
        <View className="mb-4">
          <TextInput
            className="h-12 px-4 bg-white rounded-lg border border-gray-200"
            placeholder="Search trips and posts..."
            onChangeText={handleSearchChange}
            value={searchQuery}
            autoFocus
          />
        </View>

        {/* Tabs */}
        <View className="flex-row mb-4 bg-white rounded-lg overflow-hidden">
          <TouchableOpacity
            className={`flex-1 py-2 items-center ${activeTab === 'all' ? 'bg-blue-500' : 'bg-white'}`}
            onPress={() => setActiveTab('all')}
          >
            <Text className={`font-medium ${activeTab === 'all' ? 'text-white' : 'text-gray-700'}`}>All</Text>
          </TouchableOpacity>
          <TouchableOpacity
            className={`flex-1 py-2 items-center ${activeTab === 'trips' ? 'bg-blue-500' : 'bg-white'}`}
            onPress={() => setActiveTab('trips')}
          >
            <Text className={`font-medium ${activeTab === 'trips' ? 'text-white' : 'text-gray-700'}`}>Trips</Text>
          </TouchableOpacity>
          <TouchableOpacity
            className={`flex-1 py-2 items-center ${activeTab === 'posts' ? 'bg-blue-500' : 'bg-white'}`}
            onPress={() => setActiveTab('posts')}
          >
            <Text className={`font-medium ${activeTab === 'posts' ? 'text-white' : 'text-gray-700'}`}>Posts</Text>
          </TouchableOpacity>
        </View>

        {/* Loading State */}
        {isLoading && searchQuery.length >= 2 && (
          <View className="items-center py-8">
            <ActivityIndicator size="large" color="#3b82f6" />
            <Text className="text-gray-500 mt-2">Searching...</Text>
          </View>
        )}

        {/* Error State */}
        {isError && (
          <View className="items-center py-8">
            <Text className="text-red-500">Error loading results. Please try again.</Text>
          </View>
        )}

        {/* Results */}
        {!isLoading && data && (
          <FlatList
            data={[
              ...(filteredResults().trips || []).map(trip => ({ ...trip, type: 'trip' })),
              ...(filteredResults().posts || []).map(post => ({ ...post, type: 'post' }))
            ]}
            keyExtractor={(item) => `${item.type}-${item.id}`}
            renderItem={({ item }) =>
              item.type === 'trip'
                ? renderTripItem({ item: item as Trip })
                : renderPostItem({ item: item as Post })
            }
            ListEmptyComponent={() => (
              <View className="items-center py-8">
                <Text className="text-gray-500">
                  {searchQuery.length >= 2 ? 'No results found' : 'Start typing to search'}
                </Text>
              </View>
            )}
            contentContainerStyle={{ paddingBottom: 20 }}
          />
        )}
      </View>
    </SafeAreaView>
  );
}
