import { Ionicons } from '@expo/vector-icons';
import React, { useEffect, useState, useRef } from 'react';
import { View, Text, Image, TouchableOpacity, TextInput, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRoute, useNavigation } from '@react-navigation/native';
import { router, useLocalSearchParams } from "expo-router";
import { Avatar, AvatarFallback, AvatarImage } from "~/components/ui/avatar";
import { fetch } from 'expo/fetch';
import Markdown from "react-native-markdown-display";

interface Message {
    id: number;
    text: string;
    time: string;
    isUser: boolean;
    isImage?: boolean;
    imageUrl?: string;
    jsonData?: string;
}

interface ChatResponse {
    event: string;
    message_id?: string;
    conversation_id?: string;
    answer?: string;
    created_at?: number;
    task_id?: string;
    metadata?: any;
    usage?: any;
    retriever_resources?: any[];
    status?: number;
    code?: string;
    message?: string;
}

export default function MessageScreen() {
    const route = useRoute();
    const navigation = useNavigation();
    const { initialMessage } = useLocalSearchParams();
    const [messages, setMessages] = useState<Message[]>([]);
    const [inputMessage, setInputMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [currentConversationId, setCurrentConversationId] = useState<string>('');
    const scrollViewRef = useRef<ScrollView>(null);
    const abortControllerRef = useRef<AbortController | null>(null);

    const sendMessage = async (userMessage: string) => {
        setIsLoading(true);

        // Create user message
        const newMessage = {
            id: messages.length + 1,
            text: userMessage,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isUser: true,
        };

        // Add user message to chat
        setMessages(prev => [...prev, newMessage]);

        // Create a placeholder for AI response
        const aiMessageId = messages.length + 2;
        const aiMessage: Message = {
            id: aiMessageId,
            text: '',
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isUser: false,
        };

        // Add AI message placeholder
        setMessages(prev => [...prev, aiMessage]);

        // Create abort controller for the request
        abortControllerRef.current = new AbortController();

        try {
            const response = await fetch(`${process.env.EXPO_PUBLIC_CHATBOT_API_URL}/chat-messages`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${process.env.EXPO_PUBLIC_CHATBOT_API_KEY}`,
                    'Accept': 'text/event-stream',
                },
                body: JSON.stringify({
                    inputs: {},
                    query: userMessage,
                    response_mode: "streaming",
                    conversation_id: currentConversationId,
                    user: "user-123",
                    files: []
                }),
                signal: abortControllerRef.current.signal,
            });

            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            if (!response.body) {
                throw new Error('Response body is null');
            }

            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';

            while (true) {
                const { done, value } = await reader.read();
                
                if (done) {
                    break;
                }
                
                buffer += decoder.decode(value, { stream: true });
                
                // Process complete events in the buffer
                const lines = buffer.split('\n');
                
                // Keep the last line in the buffer if it's incomplete
                buffer = lines.pop() || '';
                
                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        try {
                            const jsonStr = line.substring(6).trim();
                            // Only try to parse if we have actual content
                            if (jsonStr) {
                                const jsonData = JSON.parse(jsonStr) as ChatResponse;
                                handleSSEEvent(jsonData, aiMessageId);
                            }
                        } catch (e) {
                            console.error('Error parsing SSE data:', e, 'Raw data:', line.substring(6));
                            // Don't add to buffer if parsing failed
                        }
                    }
                }
            }
        } catch (error) {
            console.error('Error in chat request:', error);
            // Add error message to chat
            setMessages(prev => {
                // Check if the AI message is still empty, if so, update it instead of adding a new one
                const lastMessage = prev[prev.length - 1];
                if (lastMessage && !lastMessage.isUser && lastMessage.text === '') {
                    return prev.map((msg, index) =>
                        index === prev.length - 1
                            ? { ...msg, text: "Sorry, I couldn't process that request. Please try again." }
                            : msg
                    );
                }

                return [
                    ...prev,
                    {
                        id: prev.length + 2,
                        text: "Sorry, I couldn't process that request. Please try again.",
                        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                        isUser: false,
                    },
                ];
            });
        } finally {
            setIsLoading(false);
            abortControllerRef.current = null;
        }
    };

    // Handle different SSE events
    const handleSSEEvent = (data: ChatResponse, aiMessageId: number) => {
        // console.log("Received SSE event:", data);
        
        if (data.event === 'agent_message') {
            // Update conversation ID if it's set
            if (data.conversation_id && !currentConversationId) {
                setCurrentConversationId(data.conversation_id);
            }
            
            // Append text chunk to the AI message
            if (data.answer) {
                // Check for markdown JSON code blocks
                const isJsonCodeBlock = (text: string, existingText: string) => {
                    // Check if this chunk contains or completes a markdown JSON code block
                    const combinedText = existingText + text;
                    return combinedText.includes("```json") && combinedText.includes("```");
                };
                
                setMessages(prev =>
                    prev.map(msg => {
                        if (msg.id === aiMessageId) {
                            // If we detect a JSON code block in markdown, extract the JSON and replace with button placeholder
                            if (isJsonCodeBlock(data.answer || '', msg.text)) {
                                // Combine existing text with new chunk
                                let updatedText = msg.text + data.answer;
                                let jsonData = '';
                                
                                // Extract JSON data from code blocks
                                const jsonMatch = updatedText.match(/```json\s*([\s\S]*?)```/);
                                if (jsonMatch && jsonMatch[1]) {
                                    jsonData = jsonMatch[1].trim();
                                }
                                
                                // Replace all JSON code blocks with a button placeholder
                                updatedText = updatedText.replace(
                                    /```json\s*([\s\S]*?)```/g, 
                                    '<button class="view-itinerary-btn">View Itinerary</button>'
                                );
                                
                                return { 
                                    ...msg, 
                                    text: updatedText,
                                    jsonData: jsonData // Store the extracted JSON
                                };
                            } else {
                                // Normal text, just append
                                return { ...msg, text: msg.text + data.answer };
                            }
                        }
                        return msg;
                    })
                );
            }
        } else if (data.event === 'message_end') {
            // Message is complete
            if (data.conversation_id) {
                setCurrentConversationId(data.conversation_id);
            }
        } else if (data.event === 'error') {
            console.error('SSE error:', data.message);
        }
    };

    useEffect(() => {
        if (initialMessage) {
            sendMessage(initialMessage as string);
        }

        // Cleanup function to abort any ongoing requests when component unmounts
        return () => {
            if (abortControllerRef.current) {
                abortControllerRef.current.abort();
            }
        };
    }, [initialMessage]);

    // Scroll to bottom when messages change
    useEffect(() => {
        if (scrollViewRef.current) {
            setTimeout(() => {
                scrollViewRef.current?.scrollToEnd({ animated: true });
            }, 100);
        }
    }, [messages]);

    const handleSendMessage = () => {
        if (inputMessage.trim()) {
            sendMessage(inputMessage);
            setInputMessage('');
        }
    };

    const handleViewItinerary = (jsonData?: string) => {
        if (jsonData) {
            try {
                router.push({pathname:'/trip/preview',params:{tripData:jsonData}})
                // Here you can navigate to an itinerary view or display the data
            } catch (error) {
                console.error("Error parsing JSON:", error);
            }
        }
    };

    const GITHUB_AVATAR_URI = 'https://github.com/mrzachnugent.png';

    return (
        <SafeAreaView className="flex-1 bg-white">
            {/* Header */}
            <View className="flex-row items-center border-b border-gray-200 p-4">
                <TouchableOpacity className="mr-3" onPress={() => navigation.goBack()}>
                    <Ionicons name="chevron-back" size={24} color="#2B6777" />
                </TouchableOpacity>
                <View className="ml-3 flex-1 flex-row gap-2">
                    <Avatar alt="Zach Nugent's Avatar">
                        <AvatarImage source={{ uri: GITHUB_AVATAR_URI }} />
                        <AvatarFallback>
                            <Text>ZN</Text>
                        </AvatarFallback>
                    </Avatar>
                    <View className={"flex flex-col"}>
                        <Text className="text-md">TripGenie</Text>
                        <Text className="text-sm text-gray-500">{isLoading ? 'Typing...' : 'Ready'}</Text>
                    </View>
                </View>
            </View>

            {/* Chat Messages */}
            <ScrollView
                ref={scrollViewRef}
                className="flex-1 px-4 py-4"
                contentContainerStyle={{ flexGrow: 1 }}
            >
                {messages.map((message) => (
                    <View
                        key={message.id}
                        className={`mb-4 flex ${message.isUser ? 'items-end' : 'items-start'}`}>
                        <View
                            className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                                message.isUser ? 'rounded-tr-none bg-[#2B6777]' : 'rounded-tl-none bg-gray-100'
                            }`}>
                            {
                                message.isUser ? (
                                    <Text className={message.isUser ? 'text-white' : 'text-black'}>{message.text}</Text>
                                ) : (
                                    message.text.includes('<button class="view-itinerary-btn">') ? (
                                        <View className='my-2'>
                                            <Markdown>
                                                {message.text.replace(
                                                    /<button class="view-itinerary-btn">View Itinerary<\/button>/g, 
                                                    ''
                                                )}
                                            </Markdown>
                                            <TouchableOpacity 
                                                className="mt-2 bg-[#2B6777] py-2 px-4 rounded-lg"
                                                onPress={() => handleViewItinerary(message.jsonData)}
                                            >
                                                <Text className="text-white text-center">View Itinerary</Text>
                                            </TouchableOpacity>
                                        </View>
                                    ) : (
                                        <Markdown>
                                            {message.text}
                                        </Markdown>
                                    )
                                )
                            }
                        </View>
                        <Text className="mt-1 text-xs text-gray-500">{message.time}</Text>
                    </View>
                ))}
            </ScrollView>

            {/* Input Area */}
            <View className="flex-row items-center gap-4 space-x-2 border-t border-gray-200 p-4">
                <TouchableOpacity>
                    <Ionicons name="ellipsis-horizontal" size={24} color="#2B6777" />
                </TouchableOpacity>
                <View className="flex-1 flex-row items-center rounded-full bg-gray-100 px-4 py-2">
                    <TextInput
                        placeholder="Type your message here..."
                        className="flex-1"
                        value={inputMessage}
                        onChangeText={setInputMessage}
                        onSubmitEditing={handleSendMessage}
                        editable={!isLoading}
                    />
                    <TouchableOpacity onPress={handleSendMessage} disabled={isLoading}>
                        <Ionicons name={isLoading ? 'timer-outline' : 'send'} size={20} color="#2B6777" />
                    </TouchableOpacity>
                </View>
            </View>
        </SafeAreaView>
    );
}
