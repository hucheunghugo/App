import React, {useEffect, useRef, useState} from 'react';
import { View, Image, ScrollView, TouchableOpacity, TextInput, Modal, StyleSheet, Animated, Vibration } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Text } from "~/components/ui/text";
import { useNavigation } from "@react-navigation/native";
import {Link, router, useLocalSearchParams} from "expo-router";
import {useTripStore} from "~/app/globalStorage";
import supabase from "~/lib/supabase";
import {saveTripToDatabase} from "~/app/query";
import {
    DndProvider,
    Draggable,
    DraggableStack,
    DraggableStackProps,
    useDraggable
} from "@mgcrea/react-native-dnd";

interface PlaceCardProps {
    name: string;
    rating: number;
    reviews: number;
    imageUrl: string;
    time: string;
    price: string;
    onPress?: () => void;
    index: number;
    onLongPressStart: () => void;
}

interface Place {
    name: string;
    rating: number;
    reviews: number;
    time: string;
    price: string;
    imageUrl: string;
}

interface ItineraryItem {
    type: 'location'; // This can be expanded if there are other types of itinerary items
    name: string;
    description: string;
    img_url: string;
}

interface Trip {
    title: string | undefined;
    description: string;
    dateFrom: string;
    dateTo: string;
    day: ItineraryItem[][];
}

function DraggablePlaceCard({ name, rating, reviews, imageUrl, time, price, onPress, index, onLongPressStart }: PlaceCardProps) {
    const { dragActivators, isDragging } = useDraggable({
        id: index.toString(),
        activationMode: 'longPress',
        longPressDelay: 300,
        onLongPressStart: () => {
            Vibration.vibrate(50); // Add haptic feedback
            onLongPressStart();
        }
    });

    return (
        <View
            {...dragActivators}
            style={{
                opacity: isDragging ? 0.5 : 1,
                transform: [{ scale: isDragging ? 1.05 : 1 }],
            }}
        >
            <TouchableOpacity
                className={`mb-4 overflow-hidden rounded-xl bg-white ${isDragging ? 'shadow-lg' : ''}`}
                onPress={onPress}
                disabled={isDragging}
            >
                <Image
                    source={{ uri: imageUrl }}
                    className="h-24 w-full"
                />
                <View className="p-3">
                    <View className="flex-row justify-between items-center">
                        <Text className="text-lg font-semibold">{name}</Text>
                        {isDragging && (
                            <Ionicons name="move" size={20} color="#10B981" />
                        )}
                    </View>
                    <View className="mt-1 flex-row items-center">
                        <View className="flex-row">
                            {[...Array(5)].map((_, i) => (
                                <Ionicons
                                    key={i}
                                    name="star"
                                    size={16}
                                    color={i < rating ? "#FFD700" : "#E0E0E0"}
                                />
                            ))}
                        </View>
                        <Text className="ml-1 text-sm text-gray-600">({reviews} reviews)</Text>
                    </View>
                    <View className="mt-2 flex-row items-center justify-between">
                        <View className="flex-row items-center">
                            <Ionicons name="time-outline" size={16} color="#666" />
                            <Text className="ml-1 text-sm text-gray-600">{time}</Text>
                        </View>
                        <Text className="text-sm text-gray-600">{price}</Text>
                    </View>
                </View>
            </TouchableOpacity>
        </View>
    );
}

const generateDateRange = (startDate: string, endDate: string): string[] => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const dates = [];

    for (let dt = start; dt <= end; dt.setDate(dt.getDate() + 1)) {
        dates.push(new Intl.DateTimeFormat('en-US', { month: 'long', day: 'numeric' }).format(new Date(dt)));
    }

    return dates;
};

function DateSelector({ dateFrom, dateTo, selectedDate, onDateSelect }: { dateFrom: string; dateTo: string; selectedDate: number; onDateSelect: (day: number) => void }) {
    const dates = generateDateRange(dateFrom, dateTo);

    return (
        <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            className="mb-4"
        >
            {dates.map((date, index) => (
                <TouchableOpacity
                    key={date}
                    className={`mr-3 rounded-full px-6 py-2 ${index === selectedDate ? "bg-black" : "bg-gray-100"}`}
                    onPress={() => onDateSelect(index)}
                >
                    <Text className={index === selectedDate ? "text-white" : "text-gray-600"}>
                        {date}
                    </Text>
                </TouchableOpacity>
            ))}
        </ScrollView>
    );
}

export default function TripItineraryScreen() {
    // Retrieve Global State
    const trip_data = useTripStore((state) => state.trip);
    const trip_title = useTripStore((state) => state.trip?.title);
    const dateFrom = useTripStore((state) => state.trip?.dateFrom) || new Date().toISOString().split('T')[0];
    const dateTo = useTripStore((state) => state.trip?.dateTo) || new Date().toISOString().split('T')[0];
    const navigation = useNavigation();
    const itineraries = useTripStore((state) => state.trip?.day);

    const [selectedDate, setSelectedDate] = useState(0);
    const [isExpanded, setIsExpanded] = useState(false);
    const [isDragging, setIsDragging] = useState(false);
    const [longPressActive, setLongPressActive] = useState(false);

    // Animation values
    const animation = useRef(new Animated.Value(0)).current;

    const handleDateSelect = (dateIndex: number) => {
        setSelectedDate(dateIndex);
    };

    const toggleMenu = () => {
        const toValue = isExpanded ? 0 : 1;

        Animated.spring(animation, {
            toValue,
            friction: 5,
            useNativeDriver: true,
        }).start();

        setIsExpanded(!isExpanded);
    };

    const handleItinerariesData = () => {
        const selectedItinerary = itineraries?.[selectedDate];

        if (selectedItinerary && selectedItinerary.length > 0) {
            // Store the selected itinerary directly into the global state
            useTripStore.getState().addDayItinerary(selectedDate, selectedItinerary);
        } else {
            console.log("Itinerary for this day is empty.");
        }
    };

    // Ensure to call handleItinerariesData whenever the selectedDate changes
    useEffect(() => {
        handleItinerariesData();
    }, [selectedDate]);

    // Calculate animations for each mini-FAB
    const addPlaceStyle = {
        transform: [
            { scale: animation },
            {
                translateY: animation.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0, -120],
                }),
            },
        ],
    };

    const addActivityStyle = {
        transform: [
            { scale: animation },
            {
                translateY: animation.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0, -60],
                }),
            },
        ],
    };

    const addTransportStyle = {
        transform: [
            { scale: animation },
            {
                translateY: animation.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0, -180],
                }),
            },
        ],
    };

    // Rotation animation for the plus icon
    const rotation = animation.interpolate({
        inputRange: [0, 1],
        outputRange: ['0deg', '45deg'],
    });

    const addPlacePress = () => {
        router.push({
            pathname: '/trip/add_place',
            params: {
                selectedDate: selectedDate.toString()
            }
        });
    };

    const saveTrip = async () => {
        try {
            const tripUpload = await saveTripToDatabase(trip_data);
            console.log('Trip uploaded successfully:', tripUpload);
            useTripStore.getState().resetTrip();
            router.push({ pathname: '/(tabs)' });
        } catch (error) {
            console.error('Error saving trip:', error);
        }
    };

    const onDragStart = () => {
        setIsDragging(true);
    };

    const onDragEnd = () => {
        setIsDragging(false);
        // Keep longPressActive true for a moment to show the user they can continue rearranging
        setTimeout(() => {
            setLongPressActive(false);
        }, 2000);
    };

    const handleLongPressStart = () => {
        setLongPressActive(true);
    };

    const onStackOrderChange: DraggableStackProps["onOrderChange"] = (value) => {
        // Optional: Add visual feedback when order changes
    };

    const onStackOrderUpdate: DraggableStackProps["onOrderUpdate"] = (value) => {
        // Get the current itineraries for the selected date
        const currentDateItineraries = [...itineraries[selectedDate]];

        // Create a new array with the updated order
        const newOrderItineraries = value.map(index => currentDateItineraries[Number(index)]);

        // Update the itineraries
        useTripStore.getState().updateDayItinerary(selectedDate, newOrderItineraries);
    };

    return (
        <SafeAreaView className="flex-1 bg-gray-50">
            {/* Header */}
            <View className="flex-row items-center justify-between px-4 py-4 border-b border-gray-200">
                <View className="flex-row items-center gap-4">
                    <TouchableOpacity onPress={() => { navigation.goBack(); }}>
                        <Ionicons name="chevron-back-outline" size={24} color="black" />
                    </TouchableOpacity>
                    <Text className={"text-2xl font-bold"}>{trip_title}</Text>
                </View>

                <View className="flex-row">
                    <TouchableOpacity className="mr-4">
                        <Ionicons name="share-outline" size={24} color="black" />
                    </TouchableOpacity>
                    <TouchableOpacity>
                        <Ionicons name="ellipsis-horizontal" size={24} color="black" />
                    </TouchableOpacity>
                </View>
            </View>

            <View className="p-4 pb-1">
                {/* Title Section */}
                <View>
                    <View className="mt-2 pb-1">
                        <Image
                            source={{ uri: 'https://plus.unsplash.com/premium_photo-1661887292499-cbaefdb169ce?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG9uZyUyMGtvbmclMjBza3lsaW5lfGVufDB8fDB8fHww' }}
                            style={{ width: '100%', height: 200, borderRadius: 8 }}
                        />
                    </View>
                    <View className="mt-2">
                        <DateSelector
                            dateFrom={dateFrom}
                            dateTo={dateTo}
                            selectedDate={selectedDate}
                            onDateSelect={handleDateSelect}
                        />
                    </View>
                </View>
            </View>

            {/* Updated instruction messages */}
            {itineraries[selectedDate]?.length > 1 && !isDragging && !longPressActive && (
                <View className="px-4 py-2 mb-2">
                    <Text className="text-gray-500 text-center italic">
                        Long press and hold an item to rearrange
                    </Text>
                </View>
            )}

            {longPressActive && !isDragging && (
                <View className="px-4 py-2 mb-2 bg-yellow-50">
                    <Text className="text-yellow-700 text-center font-semibold">
                        Now you can drag items to rearrange them
                    </Text>
                </View>
            )}

            {isDragging && (
                <View className="px-4 py-2 mb-2 bg-blue-50">
                    <Text className="text-blue-600 text-center font-semibold">
                        Drag to your desired position • Release to drop
                    </Text>
                </View>
            )}

            {/* Places List (for the selected day) */}
            <ScrollView className="flex-1 px-4">
                <DndProvider onDragStart={onDragStart} onDragEnd={onDragEnd}>
                    <DraggableStack
                        direction="column"
                        gap={10}
                        onOrderChange={onStackOrderChange}
                        onOrderUpdate={onStackOrderUpdate}
                        dragOverlayStyle={{
                            shadowColor: "#000",
                            shadowOffset: { width: 0, height: 4 },
                            shadowOpacity: 0.3,
                            shadowRadius: 4,
                            elevation: 5,
                        }}
                    >
                        {[...itineraries[selectedDate] || []].map((itinerary, index) => (
                            <DraggablePlaceCard
                                key={index}
                                index={index}
                                name={itinerary.name}
                                rating={2}
                                reviews={2}
                                imageUrl={itinerary.img_url}
                                time={itinerary.description}
                                price={"$20"}
                                onPress={() => {}}
                                onLongPressStart={handleLongPressStart}
                            />
                        ))}
                    </DraggableStack>
                </DndProvider>
            </ScrollView>

            {/* Expanded FAB Menu with consistent alignment */}
            <View className="absolute bottom-6 right-6" style={{ width: 45, alignItems: 'center' }}>
                {/* Transport Button */}
                <Animated.View style={[addTransportStyle, { position: 'absolute', right: 0 }]}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <View style={{ backgroundColor: 'rgba(0, 0, 0, 0.8)', borderRadius: 8, paddingVertical: 4, paddingHorizontal: 8, marginRight: 8, position: 'absolute', right: 52 }}>
                            <Text style={{ color: 'white', fontSize: 12 }}>Place</Text>
                        </View>
                        <TouchableOpacity
                            style={{ backgroundColor: '#10B981', borderRadius: 50, width: 48, height: 48, alignItems: 'center', justifyContent: 'center', elevation: 5 }}
                            onPress={addPlacePress}
                        >
                            <Ionicons name="location" size={24} color="white" />
                        </TouchableOpacity>
                    </View>
                </Animated.View>

                {/* Place Button */}
                <Animated.View style={[addPlaceStyle, { position: 'absolute', right: 0 }]}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <View style={{ backgroundColor: 'rgba(0, 0, 0, 0.8)', borderRadius: 8, paddingVertical: 4, paddingHorizontal: 8, marginRight: 8, position: 'absolute', right: 52 }}>
                            <Text style={{ color: 'white', fontSize: 12 }}>Place</Text>
                        </View>
                        <TouchableOpacity
                            style={{ backgroundColor: '#10B981', borderRadius: 50, width: 48, height: 48, alignItems: 'center', justifyContent: 'center', elevation: 5 }}
                            onPress={addPlacePress}
                        >
                            <Ionicons name="location" size={24} color="white" />
                        </TouchableOpacity>
                    </View>
                </Animated.View>

                {/* Save Button */}
                <Animated.View style={[addActivityStyle, { position: 'absolute', right: 0 }]}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <View style={{ backgroundColor: 'rgba(0, 0, 0, 0.8)', borderRadius: 8, paddingVertical: 4, paddingHorizontal: 8, marginRight: 8, position: 'absolute', right: 52 }}>
                            <Text style={{ color: 'white', fontSize: 12 }}>Save</Text>
                        </View>
                        <TouchableOpacity
                            style={{ backgroundColor: '#A83232', borderRadius: 50, width: 48, height: 48, alignItems: 'center', justifyContent: 'center', elevation: 5 }}
                            onPress={saveTrip}
                        >
                            <Ionicons name="save-outline" size={24} color="white" />
                        </TouchableOpacity>
                    </View>
                </Animated.View>

                {/* Main FAB Button */}
                <TouchableOpacity
                    className="bg-black rounded-full w-14 h-14 items-center justify-center shadow-lg"
                    onPress={toggleMenu}
                >
                    <Animated.View style={{ transform: [{ rotate: rotation }] }}>
                        <Ionicons name="add" size={24} color="white" />
                    </Animated.View>
                </TouchableOpacity>
                <TouchableOpacity
                    className="bg-black rounded-full w-14 h-14 items-center justify-center shadow-lg"
                    onPress={() => router.push('/locations')}
                >
                    <Animated.View style={{ transform: [{ rotate: rotation }] }}>
                        <Ionicons name="add" size={24} color="white" />
                    </Animated.View>
                </TouchableOpacity>
            </View>
        </SafeAreaView>
    );
}
