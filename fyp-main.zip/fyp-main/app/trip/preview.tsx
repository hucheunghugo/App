import React, { useState } from 'react';
import { View, Text, ScrollView, Image, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useLocalSearchParams, router } from 'expo-router';
import supabase from '~/lib/supabase';
import { getUserId } from '~/app/utils/userData';

interface ItineraryItem {
  type: 'location';
  name: string;
  description: string;
  img_url: string;
}

interface Trip {
  title: string;
  description: string;
  dateFrom: string;
  dateTo: string;
  day: ItineraryItem[][];
}

const generateDateRange = (startDate: string, endDate: string): string[] => {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const dates = [];

  for (let dt = new Date(start); dt <= end; dt.setDate(dt.getDate() + 1)) {
    dates.push(new Intl.DateTimeFormat('en-US', { month: 'long', day: 'numeric' }).format(new Date(dt)));
  }

  return dates;
};

function DateSelector({ dateFrom, dateTo, selectedDate, onDateSelect }: { dateFrom: string; dateTo: string; selectedDate: number; onDateSelect: (day: number) => void }) {
  const dates = generateDateRange(dateFrom, dateTo);

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      className="mb-4"
    >
      {dates.map((date, index) => (
        <TouchableOpacity
          key={date}
          className={`mr-3 rounded-full px-6 py-2 ${index === selectedDate ? "bg-black" : "bg-gray-100"}`}
          onPress={() => onDateSelect(index)}
        >
          <Text className={index === selectedDate ? "text-white" : "text-gray-600"}>
            {date}
          </Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

export default function TripPreviewScreen() {
  const navigation = useNavigation();
  const params = useLocalSearchParams();
  console.log(params.tripData);

  // Parse the tripData from params
  let tripData: Trip | null = null;
  const [selectedDate, setSelectedDate] = React.useState(0);
  const [isSaving, setIsSaving] = useState(false);

  try {
    if (params.tripData) {
      tripData = JSON.parse(params.tripData as string);
    }
  } catch (error) {
    console.error('Error parsing trip data:', error);
  }

  if (!tripData) {
    return (
      <SafeAreaView className="flex-1 bg-white">
        <View className="flex-1 justify-center items-center p-4">
          <Ionicons name="alert-circle-outline" size={48} color="#FF6B6B" />
          <Text className="text-xl font-bold mt-4">No Trip Data Found</Text>
          <Text className="text-gray-500 text-center mt-2">
            We couldn't find any trip data to preview.
          </Text>
          <TouchableOpacity
            className="mt-6 bg-[#2B6777] py-3 px-6 rounded-lg"
            onPress={() => router.back()}
          >
            <Text className="text-white font-semibold">Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const handleDateSelect = (day: number) => {
    setSelectedDate(day);
  };

  const saveTrip = async () => {
    if (!tripData) return;

    try {
      setIsSaving(true);

      // Get current user ID
      const userId = await getUserId();
      if (!userId) {
        Alert.alert('Error', 'You need to be logged in to save a trip');
        setIsSaving(false);
        return;
      }

      // Update trip title with current date and time
      const now = new Date();
      const formattedDateTime = now.toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
      const updatedTripData = {
        ...tripData,
        title: `${tripData.name} - Created at ${formattedDateTime}`
      };

      // Format trip data according to the database schema
      const tripJson = {
        title: updatedTripData.title,
        description: updatedTripData.description,
        dateFrom: updatedTripData.dateFrom,
        dateTo: updatedTripData.dateTo,
        day: updatedTripData.day
      };

      // Prepare data for Supabase based on the correct schema
      const tripToSave = {
        created_by: userId,
        trip: tripJson,
        visibility: "PUBLIC" as const, // Using the enum type from the schema
        created_at: new Date().toISOString()
      };

      // Save to Supabase
      const { data, error } = await supabase
        .from('trips')
        .insert(tripToSave)
        .select('id')
        .single();

      if (error) {
        console.error('Error saving trip:', error);
        Alert.alert('Error', 'Failed to save trip. Please try again.');
        setIsSaving(false);
        return;
      }

      // Navigate to trip/index.tsx with the saved trip ID
      router.push({
        pathname: '/trip',
        params: { id: data.id }
      });

    } catch (error) {
      console.error('Error in save process:', error);
      Alert.alert('Error', 'An unexpected error occurred. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-white">
      {/* Header */}
      <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#2B6777" />
        </TouchableOpacity>
        <Text className="text-xl font-bold text-[#2B6777]">Trip Preview</Text>
        <View style={{ width: 70 }} /> {/* Empty view for spacing */}
      </View>

      <ScrollView className="flex-1">
        {/* Trip Header with Background Image */}
        <View className="relative h-56">
          <Image
              source={{ uri: 'https://images.unsplash.com/photo-1542051841857-5f90071e7989?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8dG9reW8lMjBjaGVycnklMjBibG9zc29tfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60' }}
              className="h-full w-full"
              style={{ tintColor: '#ffb6c1', opacity: 0.8 }}
          />
          <View className="absolute inset-0 bg-black bg-opacity-40" />

          {/* Header Content */}
          <View className="absolute top-0 left-0 right-0 p-4 flex-row justify-between items-start">
            <View className="flex-1">
              {/* Empty view for spacing */}
            </View>
          </View>

          <View className="absolute bottom-0 left-0 right-0 p-4">
            <Text className="text-white text-2xl font-bold">{tripData.title}</Text>
            <Text className="text-white opacity-90">{tripData.description}</Text>
          </View>
        </View>

        {/* Date Selector */}
        <View className="mt-2 px-4 pt-2">
          <DateSelector
            dateFrom={tripData.dateFrom}
            dateTo={tripData.dateTo}
            selectedDate={selectedDate}
            onDateSelect={handleDateSelect}
          />
        </View>

        {/* Attractions List */}
        <View className="px-4">
          {tripData && tripData.day && tripData.day[selectedDate] ? (
            tripData.day[selectedDate].map((item, index) => (
              <View key={index} className="mb-4 flex-row">
                {/* Left side with icon and vertical line */}
                <View className="w-12 items-center pt-4 mr-2">
                  <View className="w-8 h-8 rounded-full bg-green-100 items-center justify-center">
                    <Ionicons
                      name={item.type === 'location' ? "location" : "business"}
                      size={16}
                      color="#22c55e"
                    />
                  </View>
                  {/* Only show the line if it's not the last item */}
                  {index < tripData.day[selectedDate].length - 1 && (
                    <View className="w-0.5 flex-1 bg-gray-200 mt-2" />
                  )}
                </View>

                {/* Card content */}
                <View className="flex-1 bg-white rounded-lg shadow-sm overflow-hidden border border-gray-100">
                  <Image
                    source={{ uri: item.img_url }}
                    className="w-full h-40"
                    resizeMode="cover"
                  />
                  <View className="p-3">
                    <Text className="font-medium text-base">{item.name}</Text>
                    <Text className="text-sm text-gray-500 mt-1">{item.description}</Text>

                    <View className="flex-row mt-3 justify-between items-center">
                      <View className="flex-row">
                        <TouchableOpacity className="mr-5 flex-row items-center">
                          <Ionicons name="thumbs-up-outline" size={16} color="#666" />
                          <Text className="ml-1 text-xs text-gray-600">Like</Text>
                        </TouchableOpacity>
                        <TouchableOpacity className="mr-5 flex-row items-center">
                          <Ionicons name="chatbubble-outline" size={16} color="#666" />
                          <Text className="ml-1 text-xs text-gray-600">Comment</Text>
                        </TouchableOpacity>
                        <TouchableOpacity className="flex-row items-center">
                          <Ionicons name="share-social-outline" size={16} color="#666" />
                          <Text className="ml-1 text-xs text-gray-600">Share</Text>
                        </TouchableOpacity>
                      </View>
                      <TouchableOpacity>
                        <Text className="text-xs text-green-500">View Details</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </View>
            ))
          ) : (
            <View className="py-8 items-center">
              <Text className="text-gray-500">No itinerary items for this day</Text>
            </View>
          )}
        </View>
      </ScrollView>

      {/* Action Buttons */}
      <View className="p-4 border-t border-gray-200">
        <TouchableOpacity
          className={`bg-[#2B6777] py-3 rounded-lg flex-row justify-center items-center ${isSaving ? 'opacity-70' : ''}`}
          onPress={saveTrip}
          disabled={isSaving}
        >
          {isSaving ? (
            <>
              <ActivityIndicator size="small" color="white" />
              <Text className="text-white text-center font-semibold ml-2">Saving...</Text>
            </>
          ) : (
            <Text className="text-white text-center font-semibold">Save Trip</Text>
          )}
        </TouchableOpacity>
        <TouchableOpacity
          className="mt-3 py-3 rounded-lg border border-[#2B6777]"
          onPress={() => router.back()}
          disabled={isSaving}
        >
          <Text className="text-[#2B6777] text-center font-semibold">Edit Trip</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
