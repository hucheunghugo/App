import {View, Image, ScrollView, TouchableOpacity, Pressable, Alert, Share} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Text } from "~/components/ui/text";
import {useNavigation, useFocusEffect} from "@react-navigation/native";
import {router, useLocalSearchParams} from "expo-router";
import {useMutation, useQuery, useQueryClient} from "@tanstack/react-query";
import supabase from "~/lib/supabase";
import React, {useEffect, useState, useRef} from "react";
import {Skeleton} from "~/components/ui/skeleton";
import Carousel, {Pagination} from "react-native-reanimated-carousel";
import {getUserId} from "~/app/utils/userData";
import {fetchPostSavedStatus, fetchTripIndex, fetchTripSavedStatus, loadMyTrips, savedPostAndTrip} from "~/app/query";
import {Animated} from "react-native";

interface ItineraryItem {
    type: 'location'; // This can be expanded if there are other types of itinerary items
    name: string;
    description: string;
    img_url: string;
}

interface Trip {
    title: string | undefined;
    description: string;
    dateFrom: string;
    dateTo: string;
    day: ItineraryItem[][];
}

type Attraction = {
    id: string;
    name: string;
    rating: number;
    reviews: number;
    image: string;
    type: string;
};

const generateDateRange = (startDate: string, endDate: string): string[] => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const dates = [];

    for (let dt = start; dt <= end; dt.setDate(dt.getDate() + 1)) {
        dates.push(new Intl.DateTimeFormat('en-US', { month: 'long', day: 'numeric' }).format(new Date(dt)));
    }

    return dates;
};

function DateSelector({ dateFrom, dateTo, selectedDate, onDateSelect }: { dateFrom: string; dateTo: string; selectedDate: number; onDateSelect: (day: number) => void }) {
    const dates = generateDateRange(dateFrom, dateTo);

    return (
        <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            className="mb-4"
        >
            {dates.map((date, index) => (
                <TouchableOpacity
                    key={date}
                    className={`mr-3 rounded-full px-6 py-2 ${index === selectedDate ? "bg-black" : "bg-gray-100"}`} // Change color based on selection
                    onPress={() => onDateSelect(index)}
                >
                    <Text className={index === selectedDate ? "text-white" : "text-gray-600"}>
                        {date}
                    </Text>
                </TouchableOpacity>
            ))}
        </ScrollView>
    );
}

export default function TripItineraryScreen() {
    const params = useLocalSearchParams();
    const { id } = params;
    const navigation = useNavigation();
    const [selectedDate, setSelectedDate] = useState(0);
    const queryClient = useQueryClient();
    const [isCreator, setIsCreator] = useState(false);
    const [userId, setUserId] = useState<number>(0); // Default value of 0

    // Animation state for FAB
    const [isExpanded, setIsExpanded] = useState(false);
    const animation = useRef(new Animated.Value(0)).current;

    const handleDateSelect = (date: number) => {
        setSelectedDate(date); // Set the selected date
    };

    // Query for trip data with enabled: false to control when it runs
    const { data: trip, refetch: refetchTrip, isLoading: isLoadingTrip } = useQuery({
        queryKey: ['Trip', id],
        queryFn: async () => {
            const userId = await getUserId();
            if (!userId) throw new Error('User ID is not available');
            return fetchTripIndex(Number(id));
        },
        // This ensures we can manually control when the query runs
        staleTime: 0,
        cacheTime: 0
    });

    const {data: isSaved, refetch: refetchIsSavedStatus, isLoading: isLoadingSavedStatus} = useQuery({
        queryKey: ['savedStatus', id],
        queryFn: () => fetchTripSavedStatus(String(id), userId),
    });

    // Use useFocusEffect to refetch data when the screen comes into focus
    useFocusEffect(
        React.useCallback(() => {
            console.log("Screen focused, refetching trip data");
            // Invalidate and refetch the trip data
            queryClient.invalidateQueries({ queryKey: ['Trip', id] });
            refetchTrip();
            refetchIsSavedStatus();

            return () => {
                // Cleanup if needed
            };
        }, [id, queryClient, refetchTrip, refetchIsSavedStatus])
    );

    const deleteTrip = async () => {
        try {

            // Confirm deletion with user
            Alert.alert(
                'Delete Trip',
                'Are you sure you want to delete this trip? This action cannot be undone.',
                [
                    {
                        text: 'Cancel',
                        style: 'cancel',
                    },
                    {
                        text: 'Delete',
                        style: 'destructive',
                        onPress: async () => {

                            // Delete the trip
                            const {error} = await supabase.from('trips').delete().eq('id', Number(id));

                            if (error) {
                                console.error('Error deleting trip:', error);
                                Alert.alert('Error', 'Failed to delete trip');
                                return;
                            }

                            // Navigate back and refresh posts list
                            queryClient.invalidateQueries({
                                queryKey: ['trip']
                            });
                            navigation.goBack();
                        },
                    },
                ],
                {cancelable: true}
            );
        } catch (error) {
            console.error('Error in delete process:', error);
            Alert.alert('Error', 'An unexpected error occurred');
        }
    };


    const handleSave = async () => {
        if (isSaved){
            await supabase
                .from('saved')
                .delete()
                .eq('trip_id', Number(id))
                .eq('user_id', userId);
            console.log("deleted")
        } else {
            try {
                await savedPostAndTrip("TRIP", userId, Number(id));
            } catch (error) {
                console.error("Error saving trip:", error);
                Alert.alert('Error', 'Failed to save trip');
            }
        }

        await refetchIsSavedStatus();
    };

    const handleShare = async () => {
        try {
            // Generate a shareable link with the trip ID
            const shareableLink = `https://hsubadcat.xyz/trip/${id}`;

            // Use the Share API if available
            await Share.share({
                message: `Check out this trip! ${shareableLink}`,
            });
        } catch (error) {
            console.error('Error sharing trip:', error);
            Alert.alert('Error', 'Failed to share trip');
        }
    };

    const [showDropdown, setShowDropdown] = useState(false);
    const toggleDropdown = () => {
        setShowDropdown(!showDropdown);
    };

    // FAB menu toggle
    const toggleMenu = () => {
        const toValue = isExpanded ? 0 : 1;

        Animated.spring(animation, {
            toValue,
            friction: 5,
            useNativeDriver: true,
        }).start();

        setIsExpanded(!isExpanded);
    };

    // Calculate animations for FAB buttons
    const addLocationStyle = {
        transform: [
            { scale: animation },
            {
                translateY: animation.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0, -120],
                }),
            },
        ],
    };

    const saveStyle = {
        transform: [
            { scale: animation },
            {
                translateY: animation.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0, -60],
                }),
            },
        ],
    };

    // Rotation animation for the plus icon
    const rotation = animation.interpolate({
        inputRange: [0, 1],
        outputRange: ['0deg', '45deg'],
    });

    useEffect(() => {
        // Function to load user ID
        const loadUserId = async () => {
            try {
                const id = await getUserId(); // Await the Promise
                if (id !== null) { // Check for null explicitly
                    setUserId(id);
                }
            } catch (error) {
                console.error("Error loading user ID:", error);
            }
        };

        // Load the user ID
        loadUserId();

        // Check if the user is the creator of the trip
        if (!isLoadingTrip && trip) {
            setIsCreator(trip.created_by === userId);
        }

    }, [isLoadingTrip, trip, userId]); // Combine dependencies

    return (
        <SafeAreaView className="flex-1 bg-white">
            <ScrollView className="flex-1">
                {/* Header Image */}
                <View className="relative h-48">
                    <Image
                        source={{ uri: 'https://images.unsplash.com/photo-1542051841857-5f90071e7989?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8dG9reW8lMjBjaGVycnklMjBibG9zc29tfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60' }}
                        className="h-full w-full"
                        style={{ tintColor: '#ffb6c1', opacity: 0.8 }}
                    />
                    <Image
                        source={{ uri: 'https://images.unsplash.com/photo-1536098561742-ca998e48cbcc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8dG9reW8lMjB0b3dlcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60' }}
                        className="absolute h-full w-full"
                        style={{ opacity: 0.7 }}
                    />
                    <View className="absolute top-4 left-4 right-4 flex-row justify-between">
                        <TouchableOpacity
                            className="bg-white rounded-full p-2"
                            onPress={() => router.back()}
                        >
                            <Ionicons name="arrow-back" size={20} color="#333" />
                        </TouchableOpacity>
                        <View className="flex-row">
                            {/* Share Button */}
                            <TouchableOpacity
                                className="bg-white rounded-full p-2 mr-2"
                                onPress={handleShare}>
                                <Ionicons name="share-social-outline" size={20} color="#333" />
                            </TouchableOpacity>

                            {/* Save Button */}
                            <TouchableOpacity
                                className="bg-white rounded-full p-2 mr-2"
                                onPress={handleSave}>
                                {isSaved ? (
                                    <Ionicons name="bookmark" size={20} color="#333" />
                                ) : (
                                    <Ionicons name="bookmark-outline" size={20} color="#333" />
                                )}
                            </TouchableOpacity>

                            {/* More Options Button */}
                            <TouchableOpacity className="bg-white rounded-full p-2"
                                              onPress={toggleDropdown}>
                                <Ionicons name="ellipsis-vertical-outline" size={20} color="black"/>
                            </TouchableOpacity>

                            {/* Dropdown menu */}
                            {showDropdown && (
                                <View className="absolute right-2 top-12 bg-white rounded-lg shadow-lg z-10 w-30">
                                    {isCreator ? (
                                        <TouchableOpacity
                                            className="px-4 py-3 border-b border-gray-200"
                                            onPress={() => {
                                                console.log('Delete Trip');
                                                setShowDropdown(false);
                                                deleteTrip();
                                            }}
                                        >
                                            <Text className="text-gray-800">Delete Trip</Text>
                                        </TouchableOpacity>
                                    ) : (
                                        <View/>
                                    )}
                                    <TouchableOpacity
                                        className="px-4 py-3 border-b border-gray-200"
                                        onPress={() => {
                                            handleSave();
                                            setShowDropdown(false);
                                        }}
                                    >
                                        <Text className="text-gray-800">Save Trip</Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity
                                        className="px-4 py-3"
                                        onPress={() => {
                                            console.log('Report Trip');
                                            setShowDropdown(false);
                                        }}
                                    >
                                        <Text className="text-gray-800">Report</Text>
                                    </TouchableOpacity>
                                </View>
                            )}
                        </View>
                    </View>
                    <View className="absolute bottom-0 left-0 right-0 p-4">
                        <Text className="text-white text-2xl font-bold">{trip?.title}</Text>
                        <Text className="text-white opacity-90">{trip?.description}</Text>
                    </View>
                </View>

                {/* Date Selector */}
                <View className="mt-2 px-4 pt-2">
                    <DateSelector
                        dateFrom={trip?.dateFrom || ""}
                        dateTo={trip?.dateTo || ""}
                        selectedDate={selectedDate}
                        onDateSelect={handleDateSelect}
                    />
                </View>

                {/* Attractions List */}
                <View className="px-4">
                    {trip && trip.day && trip.day[selectedDate] ? (
                        trip.day[selectedDate].map((item, index) => (
                            <View key={index} className="mb-4 flex-row">
                                {/* Left side with icon and vertical line */}
                                <View className="w-12 items-center pt-4 mr-2">
                                    <View className="w-8 h-8 rounded-full bg-green-100 items-center justify-center">
                                        <Ionicons
                                            name={item.type === 'location' ? "location" : "business"}
                                            size={16}
                                            color="#22c55e"
                                        />
                                    </View>
                                    <View className="w-0.5 flex-1 bg-gray-200 mt-2" />
                                </View>

                                {/* Card content */}
                                <View className="flex-1 bg-white rounded-lg shadow-sm overflow-hidden border border-gray-100">
                                    <Image
                                        source={{ uri: item.img_url }}
                                        className="w-full h-40"
                                        resizeMode="cover"
                                    />
                                    <View className="p-3">
                                        <Text className="font-medium text-base">{item.name}</Text>
                                        <Text className="text-sm text-gray-500 mt-1">{item.description}</Text>

                                        <View className="flex-row mt-3 justify-between items-center">
                                            <View className="flex-row">
                                                <TouchableOpacity className="mr-5 flex-row items-center">
                                                    <Ionicons name="thumbs-up-outline" size={16} color="#666" />
                                                    <Text className="ml-1 text-xs text-gray-600">Like</Text>
                                                </TouchableOpacity>
                                                <TouchableOpacity className="mr-5 flex-row items-center">
                                                    <Ionicons name="chatbubble-outline" size={16} color="#666" />
                                                    <Text className="ml-1 text-xs text-gray-600">Comment</Text>
                                                </TouchableOpacity>
                                                <TouchableOpacity className="flex-row items-center">
                                                    <Ionicons name="share-social-outline" size={16} color="#666" />
                                                    <Text className="ml-1 text-xs text-gray-600">Share</Text>
                                                </TouchableOpacity>
                                            </View>
                                            <TouchableOpacity>
                                                <Text className="text-xs text-green-500">View Details</Text>
                                            </TouchableOpacity>
                                        </View>
                                    </View>
                                </View>
                            </View>
                        ))
                    ) : (
                        <View className="py-8 items-center">
                            <Text className="text-gray-500">No itinerary items for this day</Text>
                        </View>
                    )}
                </View>
            </ScrollView>

            {/* Floating Action Button Menu */}
            <View className="absolute bottom-6 right-6" style={{ width: 45, alignItems: 'center' }}>
                {/* Add Location Button */}
                <Animated.View style={[addLocationStyle, { position: 'absolute', right: 0 }]}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <View style={{ backgroundColor: 'rgba(0, 0, 0, 0.8)', borderRadius: 8, paddingVertical: 4, paddingHorizontal: 8, marginRight: 8, position: 'absolute', right: 52 }}>
                            <Text style={{ color: 'white', fontSize: 12 }}>Add Location</Text>
                        </View>
                        <TouchableOpacity
                            style={{ backgroundColor: '#10B981', borderRadius: 50, width: 48, height: 48, alignItems: 'center', justifyContent: 'center', elevation: 5 }}
                            onPress={() => {
                                router.push({
                                    pathname: '/trip/add_place',
                                    params: {
                                        selectedDate: selectedDate.toString(),
                                        tripId: id
                                    }
                                });
                            }}
                        >
                            <Ionicons name="location" size={24} color="white" />
                        </TouchableOpacity>
                    </View>
                </Animated.View>

                {/* Delete Trip Button (only for creator) */}
                {isCreator && (
                    <Animated.View style={[saveStyle, { position: 'absolute', right: 0 }]}>
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <View style={{ backgroundColor: 'rgba(0, 0, 0, 0.8)', borderRadius: 8, paddingVertical: 4, paddingHorizontal: 8, marginRight: 8, position: 'absolute', right: 52 }}>
                                <Text style={{ color: 'white', fontSize: 12 }}>Delete Trip</Text>
                            </View>
                            <TouchableOpacity
                                style={{ backgroundColor: '#EF4444', borderRadius: 50, width: 48, height: 48, alignItems: 'center', justifyContent: 'center', elevation: 5 }}
                                onPress={deleteTrip}
                            >
                                <Ionicons name="trash-outline" size={24} color="white" />
                            </TouchableOpacity>
                        </View>
                    </Animated.View>
                )}

                {/* Main FAB Button */}
                <TouchableOpacity
                    className="bg-black rounded-full w-14 h-14 items-center justify-center shadow-lg"
                    onPress={toggleMenu}
                >
                    <Animated.View style={{ transform: [{ rotate: rotation }] }}>
                        <Ionicons name="add" size={24} color="white" />
                    </Animated.View>
                </TouchableOpacity>
                <TouchableOpacity
                    className="bg-black rounded-full w-14 h-14 items-center justify-center shadow-lg"
                    onPress={() => router.push('/trip/edit')}
                >
                    <Animated.View style={{ transform: [{ rotate: rotation }] }}>
                        <Ionicons name="pencil-outline" size={24} color="white" />
                    </Animated.View>
                </TouchableOpacity>
            </View>
        </SafeAreaView>
    );
}
