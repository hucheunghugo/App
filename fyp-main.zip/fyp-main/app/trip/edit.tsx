import React, { useState, useEffect } from 'react';
import { View, Image, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Text } from "~/components/ui/text";
import { router, useLocalSearchParams } from "expo-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchTripIndex, updateTrip } from "~/app/query";
import { getUserId } from "~/app/utils/userData";
import DraggableFlatList from 'react-native-draggable-flatlist';

interface ItineraryItem {
  id?: string;
  type: string;
  name: string;
  description: string;
  img_url: string;
}

interface Trip {
  id: number;
  title: string;
  description: string;
  dateFrom: string;
  dateTo: string;
  day: ItineraryItem[][];
  created_by: number;
}

const generateDateLabels = (dateFrom: string, dateTo: string): string[] => {
  const start = new Date(dateFrom);
  const end = new Date(dateTo);
  const dates = [];
  
  for (let dt = new Date(start); dt <= end; dt.setDate(dt.getDate() + 1)) {
    const month = dt.toLocaleString('default', { month: 'long' });
    const day = dt.getDate();
    const suffix = getDaySuffix(day);
    dates.push(`Day ${dates.length + 1}: ${month} ${day}${suffix}`);
  }
  
  return dates;
};

const getDaySuffix = (day: number): string => {
  if (day > 3 && day < 21) return 'th';
  switch (day % 10) {
    case 1: return 'st';
    case 2: return 'nd';
    case 3: return 'rd';
    default: return 'th';
  }
};

export default function EditItineraryScreen() {
  const params = useLocalSearchParams();
  const { id } = params;
  const queryClient = useQueryClient();
  const [trip, setTrip] = useState<Trip | null>(null);
  const [dateLabels, setDateLabels] = useState<string[]>([]);
  const [hasChanges, setHasChanges] = useState(false);
  
  // Fetch trip data
  const { data: tripData, isLoading, error } = useQuery({
    queryKey: ['Trip', id],
    queryFn: async () => {
      try {
        const userId = await getUserId();
        if (!userId) {
          throw new Error('User ID is not available');
        }
        return fetchTripIndex(Number(id));
      } catch (error) {
        console.error('Error fetching trip data:', error);
        throw error;
      }
    },
    // Use reasonable stale time and cache time
    staleTime: 1000 * 60, // 1 minute
    retry: 2, // Retry failed requests twice
    onError: (error) => {
      console.error('Query error:', error);
      Alert.alert('Error', 'Failed to load trip data. Please try again.');
    }
  });
  
  // Update trip mutation
  const updateTripMutation = useMutation({
    mutationFn: updateTrip,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['Trip', id] });
      Alert.alert('Success', 'Itinerary updated successfully');
      router.back();
    },
    onError: (error) => {
      Alert.alert('Error', `Failed to update itinerary: ${error}`);
    }
  });
  
  useEffect(() => {
    if (tripData) {
      setTrip(tripData);
      setDateLabels(generateDateLabels(tripData.dateFrom, tripData.dateTo));
    }
  }, [tripData]);
  
  const handleSaveChanges = () => {
    if (trip) {
      updateTripMutation.mutate(trip);
    }
  };
  
  const handleDeleteItem = (dayIndex: number, itemIndex: number) => {
    if (!trip) return;
    
    Alert.alert(
      'Delete Item',
      'Are you sure you want to remove this item from your itinerary?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive',
          onPress: () => {
            const updatedTrip = { ...trip };
            updatedTrip.day[dayIndex].splice(itemIndex, 1);
            setTrip(updatedTrip);
            setHasChanges(true);
          }
        }
      ]
    );
  };
  
  const handleReorderItems = (dayIndex: number, data: ItineraryItem[]) => {
    if (!trip) return;
    
    const updatedTrip = { ...trip };
    updatedTrip.day[dayIndex] = data;
    setTrip(updatedTrip);
    setHasChanges(true);
  };
  
  const handleAddMoreEvents = (dayIndex: number) => {
    router.push({
      pathname: '/trip/add_place',
      params: {
        selectedDate: dayIndex.toString(),
        tripId: id
      }
    });
  };
  
  if (isLoading) {
    return (
      <SafeAreaView className="flex-1 bg-white">
        <View className="flex-1 justify-center items-center">
          <Text>Loading itinerary...</Text>
        </View>
      </SafeAreaView>
    );
  }
  
  if (error || !tripData) {
    return (
      <SafeAreaView className="flex-1 bg-white">
        <View className="flex-1 justify-center items-center">
          <Ionicons name="alert-circle-outline" size={48} color="#FF6B6B" />
          <Text className="text-xl font-bold mt-4">Error Loading Trip</Text>
          <Text className="text-gray-500 text-center mt-2">
            {error instanceof Error ? error.message : "Couldn't load trip data"}
          </Text>
          <TouchableOpacity 
            className="mt-6 bg-[#2B6777] py-3 px-6 rounded-lg"
            onPress={() => router.back()}
          >
            <Text className="text-white font-semibold">Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }
  
  return (
    <SafeAreaView className="flex-1 bg-white">
      {/* Header */}
      <View className="flex-row items-center px-4 py-2 border-b border-gray-200">
        <TouchableOpacity onPress={() => router.back()} className="mr-4">
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text className="text-xl font-semibold">Edit Itinerary</Text>
      </View>
      
      <ScrollView className="flex-1">
        {trip.day.map((dayItems, dayIndex) => (
          <View key={dayIndex} className="mb-6">
            <Text className="px-4 py-2 font-semibold text-lg">{dateLabels[dayIndex]}</Text>
            
            {dayItems.map((item, itemIndex) => (
              <View key={`${dayIndex}-${itemIndex}`} className="flex-row items-center px-4 py-2">
                <TouchableOpacity className="mr-2">
                  <Ionicons name="reorder-three" size={24} color="#888" />
                </TouchableOpacity>
                
                <View className="flex-row flex-1 items-center bg-white rounded-lg border border-gray-100 overflow-hidden">
                  <Image 
                    source={{ uri: item.img_url }} 
                    className="w-16 h-16 rounded-l-lg"
                  />
                  <View className="flex-1 px-3 py-2">
                    <Text className="font-medium">{item.name}</Text>
                    <Text className="text-xs text-gray-500">{item.description}</Text>
                  </View>
                  
                  <TouchableOpacity 
                    className="px-3 py-3"
                    onPress={() => handleDeleteItem(dayIndex, itemIndex)}
                  >
                    <Ionicons name="trash-outline" size={20} color="#FF6B6B" />
                  </TouchableOpacity>
                </View>
              </View>
            ))}
            
            <TouchableOpacity 
              className="mx-4 my-2 py-3 bg-gray-100 rounded-lg items-center"
              onPress={() => handleAddMoreEvents(dayIndex)}
            >
              <Text className="text-gray-600">Add More Events</Text>
            </TouchableOpacity>
          </View>
        ))}
        
        <View className="h-24" /> {/* Spacer for bottom button */}
      </ScrollView>
      
      {/* Save Button */}
      <View className="absolute bottom-6 left-4 right-4">
        <TouchableOpacity 
          className="bg-green-500 py-4 rounded-full items-center"
          onPress={handleSaveChanges}
        >
          <Text className="text-white font-medium">Save Changes</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
} 