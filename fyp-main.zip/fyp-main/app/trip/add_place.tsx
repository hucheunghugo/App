import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Image, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useTripStore } from "~/app/globalStorage";
import { useQuery } from '@tanstack/react-query';
import { useDebounce } from '~/hooks/useDebounce';

interface Location {
  location_id: string;
  name: string;
  address_obj: {
    street1: string;
    street2: string;
    city: string;
    country: string;
    postalcode: string;
    address_string: string;
  };
  isSelected?: boolean;
}

interface ItineraryItem {
  type: 'location';
  name: string;
  description: string;
  img_url: string;
}

export default function AddEventScreen() {
  const navigation = useNavigation();
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const debouncedSearchQuery = useDebounce(searchQuery, 500);
  const [locations, setLocations] = useState<Location[]>([]);
  const { selectedDate } = useLocalSearchParams();

  // Fetch locations using TanStack Query
  const { data, isLoading, error } = useQuery({
    queryKey: ['locations', debouncedSearchQuery],
    queryFn: async () => {
      if (!debouncedSearchQuery || debouncedSearchQuery.length < 2) return [];

      const response = await fetch(`${process.env.EXPO_PUBLIC_API_URL}/api/locations/search?searchQuery=${encodeURIComponent(debouncedSearchQuery)}`);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    },
    enabled: debouncedSearchQuery.length >= 2,
  });

  // Update locations when data changes
  useEffect(() => {
    if (data) {
      console.log(data)
      // Map the API response to our locations state with isSelected property
      const mappedLocations = data.data.map((location: Location) => ({
        ...location,
        isSelected: false
      }));

      setLocations(mappedLocations);
    }
  }, [data]);

  const toggleLocationSelection = (id: string) => {
    setLocations(locations.map(location =>
      location.location_id === id
        ? { ...location, isSelected: !location.isSelected }
        : location
    ));
  };

  const handleSave = async () => {
    const selectedLocations = locations.filter(location => location.isSelected);
    if (selectedLocations.length === 0) {
      Alert.alert('No Locations Selected', 'Please select at least one location for your event.');
      return;
    }

    selectedLocations.forEach(selectedLocation => {
      const newItinerary: ItineraryItem = {
        type: 'location',
        name: selectedLocation.name,
        description: selectedLocation.address_obj.address_string,
        img_url: "https://via.placeholder.com/150" // Default placeholder image
      };

      // Add each new itinerary item to the store
      useTripStore.getState().addItineraryItem(Number(selectedDate), newItinerary);
    });
    router.back();
  };

  return (
    <SafeAreaView className="flex-1 bg-white">
      <View className="flex-row items-center px-4 py-3 border-b border-gray-200">
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text className="flex-1 text-xl font-semibold text-center mr-6">Add Event</Text>
      </View>

      <View className="px-4 py-3">
        <View className="flex-row items-center bg-gray-100 rounded-lg px-3 py-2">
          <Ionicons name="search" size={20} color="#666" />
          <TextInput
            placeholder="Search for locations"
            className="flex-1 text-base ml-2"
            placeholderTextColor="#666"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
      </View>

      <ScrollView className="flex-1">
        {isLoading && searchQuery.length >= 2 && (
          <View className="py-8 items-center">
            <Text className="text-gray-500">Searching...</Text>
          </View>
        )}

        {error && (
          <View className="py-8 items-center">
            <Text className="text-red-500">Error loading locations. Please try again.</Text>
          </View>
        )}

        {locations.length > 0 ? (
          locations.map((location) => (
            <TouchableOpacity
              key={location.location_id}
              className="flex-row items-center px-4 py-2 border-b border-gray-100"
              onPress={() => toggleLocationSelection(location.location_id)}
              activeOpacity={0.7}
            >
              <View className="w-16 h-16 rounded-lg bg-gray-200 items-center justify-center">
                <Ionicons name="location" size={24} color="#666" />
              </View>
              <View className="flex-1 ml-3">
                <Text className="text-lg font-semibold">{location.name}</Text>
                <Text className="text-gray-500" numberOfLines={1}>
                  {location.address_obj.address_string}
                </Text>
              </View>
              {location.isSelected ? (
                <Ionicons name="checkmark-circle" size={24} color="#10B981" />
              ) : (
                <Ionicons name="add-circle-outline" size={24} color="#10B981" />
              )}
            </TouchableOpacity>
          ))
        ) : (
          searchQuery.length >= 2 && !isLoading && (
            <View className="py-8 items-center">
              <Text className="text-gray-500">No locations found matching "{searchQuery}"</Text>
            </View>
          )
        )}

        {searchQuery.length < 2 && (
          <View className="py-8 items-center">
            <Text className="text-gray-500">Enter at least 2 characters to search</Text>
          </View>
        )}
      </ScrollView>

      <View className="p-4">
        <TouchableOpacity
          className="bg-[#10B981] py-3 rounded-lg"
          onPress={handleSave}
        >
          <Text className="text-white text-center text-lg font-semibold">
            Save
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
