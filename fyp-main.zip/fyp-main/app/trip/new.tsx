import React, { useState } from 'react';
import { View, Image, ScrollView, TouchableOpacity, TextInput, Modal, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Text } from "~/components/ui/text";
import { useNavigation } from "@react-navigation/native";
import { Calendar } from 'react-native-calendars';
import {Link, router} from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {useTripStore} from '../globalStorage';
import {
    AlertDialog, AlertDialogAction, AlertDialogCancel,
    AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
    AlertDialogTrigger
} from "~/components/ui/alert-dialog";
import {ChevronLeft} from "lucide-react-native";

interface PlaceCardProps {
    name: string;
    rating: number;
    reviews: number;
    imageUrl: string;
    time: string;
    price: string;
    onPress?: () => void;
}

interface DateSelectorProps {
    dateFrom: string;
    dateTo: string;
    setDateFrom: (date: string) => void;
    setDateTo: (date: string) => void;
}

interface ItineraryItem {
    type: 'location'; // This can be expanded if there are other types of itinerary items
    name: string;
    description: string;
    img_url: string;
}

interface Trip {
    title: string | undefined;
    description: string;
    dateFrom: string;
    dateTo: string;
    day: ItineraryItem[][];
}

function PlaceCard({ name, rating, reviews, imageUrl, time, price, onPress }: PlaceCardProps) {

    return (
        <TouchableOpacity
            className="mb-4 overflow-hidden rounded-xl bg-white"
            onPress={onPress}
        >
            <Image
                source={{ uri: imageUrl }}
                className="h-48 w-full"
            />
            <View className="p-3">
                <Text className="text-lg font-semibold">{name}</Text>
                <View className="mt-1 flex-row items-center">
                    <View className="flex-row">
                        {[...Array(5)].map((_, i) => (
                            <Ionicons
                                key={i}
                                name="star"
                                size={16}
                                color={i < rating ? "#FFD700" : "#E0E0E0"}
                            />
                        ))}
                    </View>
                    <Text className="ml-1 text-sm text-gray-600">({reviews} reviews)</Text>
                </View>
                <View className="mt-2 flex-row items-center justify-between">
                    <View className="flex-row items-center">
                        <Ionicons name="time-outline" size={16} color="#666" />
                        <Text className="ml-1 text-sm text-gray-600">{time}</Text>
                    </View>
                    <Text className="text-sm text-gray-600">{price}</Text>
                </View>
            </View>
        </TouchableOpacity>
    );
}


function DateSelector({ dateFrom, dateTo, setDateFrom, setDateTo }: DateSelectorProps) {
    const [showFrom, setShowFrom] = useState(false);
    const [showTo, setShowTo] = useState(false);
    const [tempDateFrom, setTempDateFrom] = useState(dateFrom);
    const [tempDateTo, setTempDateTo] = useState(dateTo);

    const confirmFromDate = () => {
        setDateFrom(tempDateFrom);
        setShowFrom(false);
    };

    const confirmToDate = () => {
        setDateTo(tempDateTo);
        setShowTo(false);
    };

    const handleBackgroundPress = (setter: { (value: React.SetStateAction<boolean>): void; (value: React.SetStateAction<boolean>): void; (arg0: boolean): void; }) => {
        setter(false);
    };

    return (
        <View className="mt-4">
            <View className="rounded-lg border border-gray-300 p-4 bg-white">
                {/* From Date Row */}
                <TouchableOpacity
                    onPress={() => {
                        setTempDateFrom(dateFrom);
                        setShowFrom(true);
                        setShowTo(false);
                    }}
                    className="mb-4"
                >
                    <Text className="text-lg font-semibold text-gray-600">
                        From: {dateFrom}
                    </Text>
                </TouchableOpacity>

                {/* To Date Row */}
                <TouchableOpacity
                    onPress={() => {
                        setTempDateTo(dateTo);
                        setShowTo(true);
                        setShowFrom(false);
                    }}
                >
                    <Text className="text-lg font-semibold text-gray-600">
                        To: {dateTo}
                    </Text>
                </TouchableOpacity>
            </View>

            {/* Modal for From Calendar */}
            <Modal
                visible={showFrom}
                transparent={true}
                animationType="fade"
                onRequestClose={() => setShowFrom(false)}
            >
                <TouchableOpacity
                    style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.5)' }}
                    activeOpacity={1}
                    onPress={() => handleBackgroundPress(setShowFrom)}
                >
                    <TouchableOpacity
                        activeOpacity={1}
                        onPress={(e) => e.stopPropagation()}
                        className="w-11/12 bg-white rounded-lg p-4"
                    >
                        <Calendar
                            onDayPress={(day: { dateString: string }) => {
                                setTempDateFrom(day.dateString);
                            }}
                            markedDates={{
                                [tempDateFrom]: { selected: true, disableTouchEvent: true, selectedDotColor: 'orange' }
                            }}
                        />
                        <View className="border-t border-gray-300 my-4" />
                        <TouchableOpacity
                            onPress={confirmFromDate}
                            className="px-6 py-2"
                        >
                            <Text className="text-blue-500 font-medium text-center">Confirm</Text>
                        </TouchableOpacity>
                    </TouchableOpacity>
                </TouchableOpacity>
            </Modal>

            {/* Modal for To Calendar */}
            <Modal
                visible={showTo}
                transparent={true}
                animationType="fade"
                onRequestClose={() => setShowTo(false)}
            >
                <TouchableOpacity
                    style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.5)' }}
                    activeOpacity={1}
                    onPress={() => handleBackgroundPress(setShowTo)}
                >
                    <TouchableOpacity
                        activeOpacity={1}
                        onPress={(e) => e.stopPropagation()}
                        className="w-11/12 bg-white rounded-lg p-4"
                    >
                        <Calendar
                            onDayPress={(day: { dateString: string }) => {
                                setTempDateTo(day.dateString);
                            }}
                            markedDates={{
                                [tempDateTo]: { selected: true, disableTouchEvent: true, selectedDotColor: 'orange' }
                            }}
                        />
                        <View className="border-t border-gray-300 my-4" />
                        <TouchableOpacity
                            onPress={confirmToDate}
                            className="px-6 py-2"
                        >
                            <Text className="text-blue-500 font-medium text-center">Confirm</Text>
                        </TouchableOpacity>
                    </TouchableOpacity>
                </TouchableOpacity>
            </Modal>
        </View>
    );
}

export default function TripItineraryScreen() {
    const navigation = useNavigation();

    const [title, setTitle] = useState(useTripStore((state) => state.trip?.title));
    const dateFromCheck = useTripStore((state) => state.trip?.dateFrom) || new Date().toISOString().split('T')[0];
    const [dateFrom, setDateFrom] = useState(dateFromCheck);
    const dateToCheck = useTripStore((state) => state.trip?.dateTo) || new Date().toISOString().split('T')[0];
    const [dateTo, setDateTo] = useState(dateToCheck);

    const handleItineraryPress = () => {
        if (!title.trim()) {
            alert("Please enter a name for your trip.");
            return; // Prevent submission if title is empty
        }

        // Proceed with storing the title and navigating
        useTripStore.getState().setTripTitle(title);
        useTripStore.getState().setDateTo(dateTo);
        useTripStore.getState().setDateFrom(dateFrom);
        router.push({
            pathname: '/trip/itinerary',
        });
    };

    const clearItineraryData = async () => {
        try {
            await AsyncStorage.removeItem('place_info');
            console.log('Itinerary data cleared successfully');
            // Optionally reset the state
        } catch (error) {
            console.error('Error clearing itinerary data:', error);
        }
    };

    return (
        <SafeAreaView className="flex-1 bg-gray-50">
            <View className="flex-row items-center justify-between px-4 py-4 border-b border-gray-200">
                <View className="flex-row items-center gap-4">
                    <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <ChevronLeft size={24} color="black"/>
                        </AlertDialogTrigger>
                        <AlertDialogContent className={"w-full"}>
                            <AlertDialogHeader>
                                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                    This action cannot be undone.
                                </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                                <AlertDialogCancel>
                                    <Text>Cancel</Text>
                                </AlertDialogCancel>
                                <AlertDialogAction onPress={() => {
                                    navigation.goBack();
                                    useTripStore.getState().resetTrip();
                                }}>
                                    <Text>Continue</Text>
                                </AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                    </AlertDialog>
                    <Text className={"text-2xl font-bold"}>New Trip</Text>
                </View>

                <View className="flex-row">
                    <TouchableOpacity className="mr-4">
                        <Ionicons name="share-outline" size={24} color="black" />
                    </TouchableOpacity>
                    <TouchableOpacity>
                        <Ionicons name="ellipsis-horizontal" size={24} color="black" />
                    </TouchableOpacity>
                </View>
            </View>

            <View className="flex-1 justify-center p-12">
                {/* Cover Image Section */}
                <TouchableOpacity className="relative rounded-lg overflow-hidden border border-gray-300 mb-4">
                    <Image
                        source={{ uri: 'https://plus.unsplash.com/premium_photo-1661887292499-cbaefdb169ce?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG9uZyUyMGtvbmclMjBza3lsaW5lfGVufDB8fDB8fHww' }}
                        style={{ width: '100%', height: 200, borderRadius: 8 }}
                    />
                    <View className="absolute inset-0 flex justify-center items-center" style={{ backgroundColor: 'rgba(0, 0, 0, 0.25)' }}>
                        <Text className="text-white font-bold">Choose a cover image</Text>
                    </View>
                </TouchableOpacity>

                <View className="mb-4">
                    <TextInput
                        value={title}
                        onChangeText={setTitle}
                        className="text-lg font-bold px-4 py-3 bg-gray-300 rounded-lg text-center"
                        placeholder="Name of your trip"
                    />
                </View>

                <DateSelector dateFrom={dateFrom} dateTo={dateTo} setDateFrom={setDateFrom} setDateTo={setDateTo} />
            </View>


            <View className="absolute bottom-6 right-6" style={{ width: 45, alignItems: 'center' }}>
                <TouchableOpacity
                    className="bg-black rounded-full w-14 h-14 items-center justify-center shadow-lg"
                    onPress={handleItineraryPress}
                >
                    <Ionicons name="arrow-forward-outline" size={24} color="white" />
                </TouchableOpacity>
            </View>
        </SafeAreaView>
    );
}
