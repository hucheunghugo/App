import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import supabase from "~/lib/supabase";

export default function SignupScreen() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [loading, setLoading] = useState(false);

    // Get form values (similar to what getValues() would do in React Hook Form)
    const getValues = () => {
        return {
            email,
            password
        };
    };

    async function signUpWithEmail() {

        if (!email.trim()) {
            Alert.alert("Error", "Please enter your email");
            return;
        }

        if (password.length < 6) {
            Alert.alert("Error", "Password should be at least 6 characters");
            return;
        }

        if (password !== confirmPassword) {
            Alert.alert("Error", "Passwords don't match");
            return;
        }

        setLoading(true);
        const { email: emailValue, password: passwordValue } = getValues();

        try {
            const {
                data: { session },
                error,
            } = await supabase.auth.signUp({
                email: emailValue,
                password: passwordValue,
            });

            if (error) Alert.alert("Error", error.message);
            if (!session) {
                Alert.alert("Success", "Please check your inbox for email verification!", [
                    { text: "OK", onPress: () => router.back() },
                ]);
            }
        } catch (error) {
            Alert.alert("Error", "An unexpected error occurred");
        } finally {
            setLoading(false);
        }
    }

    return (
        <View className="flex-1 bg-white p-6">
            <TouchableOpacity
                className="mt-12"
                onPress={() => router.back()}
            >
                <Ionicons name="arrow-back" size={24} color="black" />
            </TouchableOpacity>

            <View className="mt-6 mb-8">
                <Text className="text-3xl font-bold mb-2">Create Account</Text>
            </View>

            <View className="space-y-4">
                <View className="bg-gray-50 rounded-xl p-4 mb-2">
                    <TextInput
                        placeholder="Email"
                        value={email}
                        onChangeText={setEmail}
                        className="text-base"
                        keyboardType="email-address"
                        autoCapitalize="none"
                    />
                </View>

                <View className="bg-gray-50 rounded-xl p-4 mb-2">
                    <TextInput
                        placeholder="Password"
                        value={password}
                        onChangeText={setPassword}
                        secureTextEntry
                        className="text-base"
                    />
                </View>

                <View className="bg-gray-50 rounded-xl p-4 mb-2">
                    <TextInput
                        placeholder="Confirm Password"
                        value={confirmPassword}
                        onChangeText={setConfirmPassword}
                        secureTextEntry
                        className="text-base"
                    />
                </View>

                <TouchableOpacity
                    className="bg-amber-500 rounded-full p-4 items-center mt-4"
                    onPress={signUpWithEmail}
                    disabled={loading}
                >
                    <Text className="text-white font-semibold text-base">
                        {loading ? "SIGNING UP..." : "SIGN UP →"}
                    </Text>
                </TouchableOpacity>
            </View>

            <View className="flex-row justify-center mt-6">
                <Text className="text-gray-500">Already have an account? </Text>
                <TouchableOpacity onPress={() => router.push('/auth/emailLogin')}>
                    <Text className="text-amber-500">Sign in</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
}