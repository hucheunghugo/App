import React, { createContext, useEffect, useState } from 'react';
import supabase from '~/lib/supabase';

interface AuthContextType {
    session: any;
    user: any;
    loading: boolean;
}

export const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
    const [session, setSession] = useState<any>(null);
    const [user, setUser] = useState<any>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const getSession = async () => {
            const { data: sessionData } = await supabase.auth.getSession();
            setSession(sessionData?.session || null);
            setUser(sessionData?.session?.user || null);
            setLoading(false);
        };

        getSession();

        const { data } = supabase.auth.onAuthStateChange((event, session) => {
            if (event === 'SIGNED_IN') {
                setSession(session);
                setUser(session?.user || null);
            } else if (event === 'SIGNED_OUT') {
                setSession(null);
                setUser(null);
            }
        });

        // Clean up the subscription when the component unmounts
        return () => {
            data.subscription.unsubscribe();
        };
    }, []);

    return (
        <AuthContext.Provider value={{ session, user, loading }}>
            {children}
        </AuthContext.Provider>
    );
};
