import { View, Text, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import {useEffect, useState} from 'react';
import {router} from "expo-router";
import supabase from "~/lib/supabase";

interface PreferenceOption {
    id: string;
    label: string;
    icon: string;
  }


export default function userInfoScreen() {    const [username, setUsername] = useState('');
    const [uid, setUid] = useState<string | null>(null);
    const [email, setEmail] = useState('');
    const [loading, setLoading] = useState(false);

    const [selectedPreferences, setSelectedPreferences] = useState<string[]>([]);
    const [searchQuery, setSearchQuery] = useState('');
  
    const preferenceOptions: PreferenceOption[] = [
      { id: 'adventure', label: 'Adventure Travel ✈️', icon: '✈️' },
      { id: 'city', label: 'City Breaks 🏙️', icon: '🏙️' },
      { id: 'cultural', label: 'Cultural Exploration 🏛️', icon: '🏛️' },
      { id: 'glamping', label: 'Glamping 🏕️', icon: '🏕️' },
      { id: 'beach', label: 'Beach Vacations 🏖️', icon: '🏖️' },
      { id: 'nature', label: 'Nature Escapes 🌿', icon: '🌿' },
      { id: 'relaxing', label: 'Relaxing Getaways 🏨', icon: '🏨' },
      { id: 'road', label: 'Road Trips 🚗', icon: '🚗' },
      { id: 'food', label: 'Food Tourism 🍔', icon: '🍔' },
      { id: 'backpacking', label: 'Backpacking 🎒', icon: '🎒' },
      { id: 'cruise', label: 'Cruise Vacations 🚢', icon: '🚢' },
      { id: 'staycation', label: 'Staycations 🏡', icon: '🏡' },
      { id: 'skiing', label: 'Skiing/Snowboarding 🏂', icon: '🏂' },
      { id: 'wine', label: 'Wine Tours 🍷', icon: '🍷' },
      { id: 'wildlife', label: 'Wildlife Safaris 🦁', icon: '🦁' },
      { id: 'art', label: 'Art Galleries 🖼️', icon: '🖼️' },
    ];
  
    const togglePreference = (id: string) => {
      setSelectedPreferences(prev => 
        prev.includes(id) 
          ? prev.filter(item => item !== id) 
          : [...prev, id]
      );
    };
  
    const filteredOptions = preferenceOptions.filter(option => 
      option.label.toLowerCase().includes(searchQuery.toLowerCase())
    );
  
    const handleContinue = () => {
      router.push('/(tabs)');
    };

    // Fetch user session when the component mounts
    useEffect(() => {
        const fetchSession = async () => {
            try {
                const { data, error } = await supabase.auth.getSession();

                if (error) {
                    console.error("Error fetching session:", error);
                    return;
                }

                if (data?.session?.user) {
                    setUid(data.session.user.id); // Set the user's ID
                    setEmail(data.session.user.email || "default@gmail.com");
                } else {
                    console.warn("No user is logged in.");
                    setUid(null);
                }
            } catch (err) {
                console.error("Unexpected error fetching user info:", err);
            }
        };

        fetchSession();
    }, []); // Empty dependency array to run only once when component mounts

    const insertInfo = async () => {
        if (!username || !uid) {
            Alert.alert("Please enter a username and ensure you're logged in.");
            return;
        }

        setLoading(true);

        try {
            const { data, error } = await supabase
                .from('users')
                .insert([ // Use upsert to insert or update the data
                    {
                        uuid: uid,
                        name: username,
                        email: email,
                    },
                ])
                .select();

            if (error) {
                console.error("Error inserting info:", error);
                return;
            }

            console.log("User info inserted successfully:", data);
            router.push("/(tabs)"); // Navigate to the tabs page after successful submission
        } catch (err) {
            console.error("Unexpected error:", err);
        } finally {
            setLoading(false);
        }
    };

    return (
        <SafeAreaView className="flex-1 bg-white p-6">
        {/* Header with back button and progress bar */}
        <View className="flex-row items-center mb-4">
          <TouchableOpacity onPress={() => router.back()}>
            <Ionicons name="arrow-back" size={24} color="black" />
          </TouchableOpacity>
        </View>
  
        {/* Title and description */}
        <View className="mb-6">
          <Text className="text-3xl font-bold mb-2">Personal Information and Travel Preferences ✈️</Text>
          <Text className="text-gray-600">
            Tell us your travel preferences, and we'll tailor recommendations to your style.
          </Text>
        </View>

                        {/* Input Section */}
                        <View className="px-4">
                    <View className="mb-4 overflow-hidden rounded-lg bg-gray-100">
                        <TextInput
                            placeholder="Username"
                            className="px-4 py-3 text-base"
                            placeholderTextColor="#666"
                            value={username}
                            onChangeText={setUsername}
                        />

                    </View>
                </View>
  
        {/* Search bar */}
        <View className="bg-gray-100 rounded-full px-4 py-3 mb-6 flex-row items-center">
          <Ionicons name="search" size={20} color="#9CA3AF" />
          <TextInput
            placeholder="Search travel preferences"
            className="ml-2 flex-1 text-base"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
  
        {/* Preferences grid */}
        <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
          <View className="flex-row flex-wrap justify-between">
            {filteredOptions.map((option) => (
              <TouchableOpacity
                key={option.id}
                className={`mb-4 py-3 px-4 rounded-full ${
                  selectedPreferences.includes(option.id)
                    ? 'bg-emerald-500'
                    : 'bg-gray-100'
                }`}
                style={{ width: '48%' }}
                onPress={() => togglePreference(option.id)}
              >
                <Text 
                  className={`text-center ${
                    selectedPreferences.includes(option.id)
                      ? 'text-white'
                      : 'text-gray-800'
                  }`}
                >
                  {option.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
  
        {/* Continue button */}
        <TouchableOpacity
          className="bg-emerald-500 rounded-full py-4 mt-4"
          onPress={() => {
              insertInfo();
              handleContinue();
          }}
          disabled={loading}
        >
          <Text className="text-white text-center font-semibold">
              {loading ? "Loading..." : "Continue " + selectedPreferences.length + "/5" }
          </Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
};