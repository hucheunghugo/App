import React from 'react';
import {View, Text, TouchableOpacity, Image, Platform} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Mail, Chrome, Apple, Facebook, Twitter } from 'lucide-react-native';
import {Link} from "expo-router";

interface SocialButtonProps {
    icon: any;
    text: string;
    onPress: () => void;
    isLucideIcon?: boolean;
}

const SocialButton: React.FC<SocialButtonProps> = ({ icon: Icon, text, onPress, isLucideIcon }) => (
    <TouchableOpacity
        onPress={onPress}
        className="flex-row items-center bg-white rounded-md py-4 px-4 mb-4 mx-4 border-gray-200 border"
    >
        <Icon size={24} color={'#000000'}/>

        <Text className="flex-1 text-center text-base font-semibold text-gray-800">
            {text}
        </Text>
    </TouchableOpacity>
);

const LoginScreen: React.FC = () => {
    return (
        <SafeAreaView className="flex-1 bg-white">
            <View className="flex-1 justify-center items-center">
                {/* Logo */}
                <Image
                    source={require('../../assets/images/image.png')}
                    className="w-20 h-20 mb-8 rounded-full"
                />

                {/* Header Text */}
                <Text className="text-3xl font-bold mb-2">
                    Let's Get Started!
                </Text>
                <Text className="text-gray-600 text-lg mb-12">
                    Your Passport to Adventure Awaits
                </Text>

                {/* Social Login Buttons */}
                <Link href={'/auth/emailLogin'} asChild={true}>
                    <SocialButton
                        icon={Mail}
                        text="Continue with Email"
                        onPress={() => {}}
                        isLucideIcon
                    />
                </Link>

                <Link href={'/(tabs)'} asChild={true}>
                    <SocialButton
                        icon={Chrome}
                        text="Continue with Google"
                        onPress={() => {}}
                        isLucideIcon
                    />
                </Link>

                {Platform.OS === 'ios'?<SocialButton
                    icon={Apple}
                    text="Continue with Apple"
                    onPress={() => {}}
                    isLucideIcon
                />:<></>}


                <SocialButton
                    icon={Facebook}
                    text="Continue with Facebook"
                    onPress={() => {}}
                />

                <SocialButton
                    icon={Twitter}
                    text="Continue with Twitter"
                    onPress={() => {}}
                />

                {/* Footer Links */}
                <View className="flex-row mt-8">
                    <Text
                        className="text-gray-500 mx-2"
                        onPress={() => {}}
                    >
                        Privacy Policy
                    </Text>
                    <Text className="text-gray-500">·</Text>
                    <Text
                        className="text-gray-500 mx-2"
                        onPress={() => {}}
                    >
                        Terms of Service
                    </Text>
                </View>
            </View>
        </SafeAreaView>
    );
};

export default LoginScreen;
