import { View, Text, TextInput, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import React, { useState } from 'react';
import {router} from "expo-router";
import supabase from "~/lib/supabase";
import {Button} from "~/components/ui/button";
import { useForm, Controller } from 'react-hook-form';
import { useMutation } from '@tanstack/react-query';
import { cn } from '~/lib/utils';
import { useNavigation } from '@react-navigation/native';

interface IFormInput {
    email: string;
    password: string;
}

export default function EmailLoginScreen() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const navigation = useNavigation();
    const { control, handleSubmit, formState: { errors }, getValues } = useForm<IFormInput>({
        defaultValues: {
            email: '',
            password: ''
        }
    });

    // Sign In Mutation
    const signInMutation = useMutation({
        mutationFn: async (credentials: IFormInput) => {
            const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword(credentials);
            if (signInError) throw signInError;
            return signInData;
        },
        onSuccess: async (data) => {
            const { data: userData, error } = await supabase.auth.getUser();
            if (error) throw error;

            if (userData?.user) {
                const { data: userExists } = await supabase
                    .from('users')
                    .select('uuid')
                    .eq('uuid', userData.user.id)
                    .single();

                if (!userExists) {
                    router.push("/auth/userInfo");
                } else {
                    router.push("/(tabs)");
                }
            }
        },
        onError: (error: Error) => {
            Alert.alert("Login Failed", error.message);
        }
    });

    async function signUpWithEmail() {
        setLoading(true);
        const { email, password } = getValues();

        const {
            data: { session },
            error,
        } = await supabase.auth.signUp({
            email: email,
            password: password,
        })

        if (error) Alert.alert(error.message)
        if (!session) {
            Alert.alert("Please check your inbox for email verification!", "", [
                { text: "OK", onPress: () => navigation.goBack() },
            ]);
        }
        setLoading(false)
    }

    const onSubmitSignIn = handleSubmit((data) => {
        signInMutation.mutate(data);
    });

    return (
        <View className="flex-1 bg-white p-6 justify-center">
            <View className="mb-8">
                <Text className="text-3xl font-bold mb-2">Login</Text>
                <Text className="text-gray-500">Please sign in to continue.</Text>
            </View>

            <View className="space-y-4">
                <View className="bg-gray-50 rounded-xl p-4 mb-2">
                    <Controller
                        control={control}
                        name="email"
                        rules={{ required: 'Email is required' }}
                        render={({ field: { onChange, onBlur, value } }) => (
                            <TextInput
                                placeholder="Email"
                                value={value}
                                onChangeText={onChange}
                                onBlur={onBlur}
                                className="text-base"
                                keyboardType="email-address"
                                autoCapitalize="none"
                            />
                        )}
                    />
                    {errors.email && <Text className="text-red-500 text-sm mt-1">{errors.email.message}</Text>}
                </View>

                <View className="bg-gray-50 rounded-xl p-4 mb-2">
                    <Controller
                        control={control}
                        name="password"
                        rules={{ required: 'Password is required' }}
                        render={({ field: { onChange, onBlur, value } }) => (
                            <TextInput
                                placeholder="Password"
                                value={value}
                                onChangeText={onChange}
                                onBlur={onBlur}
                                secureTextEntry
                                className="text-base"
                            />
                        )}
                    />
                    {errors.password && <Text className="text-red-500 text-sm mt-1">{errors.password.message}</Text>}
                </View>

                <TouchableOpacity className ="mb-2" onPress={() => router.push('/auth/forgotPassword')}>
                    <Text className="text-amber-500 text-right">Forgot?</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    className="bg-amber-500 rounded-full p-4 items-center"
                    onPress={onSubmitSignIn}
                >
                    <Text className="text-white font-semibold text-base">LOGIN →</Text>
                </TouchableOpacity>
            </View>

            <View className="flex-row justify-center mt-6">
                <Text className="text-gray-500">Don't have an account? </Text>
                <TouchableOpacity onPress={() => router.push('/auth/emailSignUp')}>
                    <Text className="text-amber-500">Sign up</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
}
