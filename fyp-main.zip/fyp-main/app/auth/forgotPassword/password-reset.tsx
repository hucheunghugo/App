import { View, Text, TextInput, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import React, {useEffect, useState} from 'react';
import {router} from "expo-router";
import supabase from "~/lib/supabase";
import { useForm, Controller } from 'react-hook-form';
import { useMutation } from '@tanstack/react-query';
import { useNavigation } from '@react-navigation/native';

interface IFormInput {
    newPassword: string;
}

export default function NewPasswordScreen() {
    const [email, setEmail] = useState('');
    const [loading, setLoading] = useState(false);
    const navigation = useNavigation();
    const { control, handleSubmit, formState: { errors }, getValues } = useForm<IFormInput>({
        defaultValues: {
            newPassword: '',
        }
    });

    useEffect(() => {
        supabase.auth.onAuthStateChange(async (event, session) => {
            if (event == "PASSWORD_RECOVERY") {
                const newPassword = prompt("What would you like your new password to be?");
                const { data, error } = await supabase.auth
                    .updateUser({ password: newPassword })
                if (data) alert("Password updated successfully!")
                if (error) alert("There was an error updating your password.")
            }
        })
    }, [])

    // Sign In Mutation
    const resetPasswordMutation = useMutation({
        mutationFn: async (credentials: IFormInput) => {
            const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword(credentials);
            if (signInError) throw signInError;
            return signInData;
        },
        onSuccess: async (data) => {
            const { data: userData, error } = await supabase.auth.getUser();
            if (error) throw error;

            if (userData?.user) {
                const { data: userExists } = await supabase
                    .from('users')
                    .select('uuid')
                    .eq('uuid', userData.user.id)
                    .single();

                if (!userExists) {
                    router.push("/auth/userInfo");
                } else {
                    router.push("/(tabs)");
                }
            }
        },
        onError: (error: Error) => {
            Alert.alert("Login Failed", error.message);
        }
    });


    const onSubmitResetPassword = handleSubmit(async (data) => {
        console.log(data)
    });

    return (
        <View className="flex-1 bg-white p-6 justify-center">
            <View className="mb-8">
                <Text className="text-3xl font-bold mb-2">Reset password</Text>
                <Text className="text-gray-500">Set up your new password continue.</Text>
            </View>

            <View className="space-y-4">
                <View className="bg-gray-50 rounded-xl p-4 mb-2">
                    <Controller
                        control={control}
                        name="newPassword"
                        rules={{ required: 'Password is required' }}
                        render={({ field: { onChange, onBlur, value } }) => (
                            <TextInput
                                placeholder="New password"
                                value={value}
                                onChangeText={onChange}
                                onBlur={onBlur}
                                secureTextEntry
                                className="text-base"
                            />
                        )}
                    />
                    {errors.password && <Text className="text-red-500 text-sm mt-1">{errors.password.message}</Text>}
                </View>

                <TouchableOpacity
                    className="bg-amber-500 rounded-full p-4 items-center"
                    onPress={onSubmitResetPassword}
                >
                    <Text className="text-white font-semibold text-base">Send link</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
}
