import { View, Text, TextInput, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import React, { useState } from 'react';
import {router} from "expo-router";
import supabase from "~/lib/supabase";
import {Button} from "~/components/ui/button";
import { useForm, Controller } from 'react-hook-form';
import { useMutation } from '@tanstack/react-query';
import { useNavigation } from '@react-navigation/native';
import * as Linking from "expo-linking";

interface IFormInput {
    email: string;
}

export default function ConfirmEmailScreen() {
    const [email, setEmail] = useState('');
    const [loading, setLoading] = useState(false);
    const navigation = useNavigation();
    const { control, handleSubmit, formState: { errors }, getValues } = useForm<IFormInput>({
        defaultValues: {
            email: '',
        }
    });

    const onSubmitResetPassword = handleSubmit(async (data) => {
        const resetPasswordURL = Linking.createURL("auth/forgotPassword/password-reset");

        const { data:dbResponse, error } = await supabase.auth
            .resetPasswordForEmail(data.email,{
                redirectTo:`${process.env.EXPO_PUBLIC_API_URL}/password-reset-redirect`
            })
        alert('Check your mail.')
        console.log(`${process.env.EXPO_PUBLIC_API_URL}/password-reset-redirect`)
        console.log(dbResponse)
        console.log(error)
    });

    return (
        <View className="flex-1 bg-white p-6 justify-center">
            <View className="mb-8">
                <Text className="text-3xl font-bold mb-2">Forgot password</Text>
                <Text className="text-gray-500">Please sign in to continue.</Text>
            </View>

            <View className="space-y-4">
                <View className="bg-gray-50 rounded-xl p-4 mb-2">
                    <Controller
                        control={control}
                        name="email"
                        rules={{ required: 'Email is required' }}
                        render={({ field: { onChange, onBlur, value } }) => (
                            <TextInput
                                placeholder="Email"
                                value={value}
                                onChangeText={onChange}
                                onBlur={onBlur}
                                className="text-base"
                                keyboardType="email-address"
                                autoCapitalize="none"
                            />
                        )}
                    />
                    {errors.email && <Text className="text-red-500 text-sm mt-1">{errors.email.message}</Text>}
                </View>

                <TouchableOpacity
                    className="bg-amber-500 rounded-full p-4 items-center"
                    onPress={onSubmitResetPassword}
                >
                    <Text className="text-white font-semibold text-base">Send link</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
}
