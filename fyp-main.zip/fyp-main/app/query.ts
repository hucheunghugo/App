import supabase from "~/lib/supabase";
import {number, string} from "prop-types";
import {formatDistanceToNow} from "date-fns";

// User Auth
type SupabaseAuthData = {
    user: {
        id: string;
        // You can add other user properties if needed
        email?: string;
        app_metadata?: Record<string, any>;
        user_metadata?: Record<string, any>;
    } | null;
};

interface postCards {
    id: number,
    title: string,
    username: string | null
}

interface tripCards {
    id: number,
    title: string,
    username: string | null
}

interface ItineraryItem {
    type: 'location'; // This can be expanded if there are other types of itinerary items
    name: string;
    description: string;
    img_url: string;
}

interface Trip {
    title: string | undefined;
    description: string;
    dateFrom: string;
    dateTo: string;
    day: ItineraryItem[][];
    created_by: number;
}

type MyTripData = {
    id: number;
    title: string | undefined;
    dateFrom: string | undefined;
    dateTo: string | undefined;
    description: string | undefined;
    imageUrl: string;
};

interface MyPostData {
    id: number;
    title: string;
    likes: number;
    imageUrl: string;
    onPress?: () => void;
}

interface PostIndex {
    id: number,
    created_by: number,
    title: string,
    content: string,
    hashtags: string[],
    likes: number,
}

interface PostComment {
    id: number; // Assuming the comment ID is a string
    content: string; // The content of the comment
    user_id: string | number; // User ID can be a string or number depending on your data model
    username: string; // The name of the user who made the comment
    timeAgo: string; // A formatted string representing the time since the comment was created
}

interface CommentReply {
    reply_id: number,
    content: string | null;
    user_id: number | null; // Change this to number | null
    username: string | null | undefined;
    comment_id: number | null;
    timeAgo: string;
}

interface SavedData {
    type: "TRIP" | "POST";  // Restricting type to specific string literals
    user_id: number;        // Assuming user_id is a required field
    trip_id?: number;       // Optional property for TRIP type
    post_id?: number;       // Optional property for POST type
}
interface SavedPostData {
    id: number;
    title: string;
    likes: number;
    imageUrl: string;
    onPress?: () => void;
}

type SavedTripData = {
    id: number;
    title: string;
    dateFrom: string;
    dateTo: string;
    description: string;
    imageUrl: string;
    onPress?: () => void;
};

//(tabs)/index.tsx
export const postsQuery = async (): Promise<postCards[]> => {
    const { data, error } = await supabase
        .from('posts')
        .select('*, users (name)');

    if (error) throw error;

    // Map through the fetched data and return an array of PostCard
    return data.map(post => ({
        id: post.id as number,
        title: post.title as string,
        username: post.users ? post.users.name as string : null,
    }));
};

export const tripsQuery = async (): Promise<tripCards[]> => {
    const { data, error } = await supabase
        .from('trips')
        .select('*, users (name)');

    if (error) throw error;

    // Map through the fetched data and extract from the trip JSON field
    return data.map(tripRow => {
        // Parse the JSON trip data if needed
        const parsedTrip = typeof tripRow.trip === 'string'
            ? JSON.parse(tripRow.trip)
            : tripRow.trip;

        // Check if trip is an array and use the first item if it exists
        const tripData = Array.isArray(parsedTrip) && parsedTrip.length > 0
            ? parsedTrip[0]
            : parsedTrip;

        return {
            id: tripRow.id,
            // Extract title from the nested trip JSON
            title: tripData?.title ,
            username: tripRow.users?.name || null,
        };
    });
}

//(tabs)/trip.tsx
export const saveTripToDatabase = async (tripData: any) => {
    // Get authenticated user
    const { data: authData } = await supabase.auth.getUser();
    if (!authData.user) throw new Error('Not authenticated');

    // Get the user's ID from the users table
    const { data: userData, error: userError } = await supabase
        .from('users')
        .select('id')
        .eq('uuid', authData.user.id)
        .single();

    if (userError) {
        console.error('User error:', userError);
        throw new Error('Could not find user');
    }

    // Convert Trip object to JSON
    const tripJson = JSON.stringify(tripData);

    // Insert the trip data
    const { data: tripUpload, error: tripError } = await supabase
        .from('trips')
        .insert([
            {
                trip: JSON.parse(tripJson), // Ensure this matches your schema
                visibility: 'PUBLIC', // Ensure this is correctly spelled
                created_by: userData.id,
            },
        ])
        .select('id');

    if (tripError) {
        throw new Error(`Failed to save trip: ${tripError.message}`);
    }

    return tripUpload;
};

//(tabs)/me.tsx

export const loadMyTrips = async (id: number): Promise<MyTripData[]> => {
    const { data, error } = await supabase
        .from('trips')
        .select('id, trip')
        .eq("created_by", id);

    if (error) throw error;

    // Handle the case where trip is an array of objects
    return data.map(item => {
        // Parse the JSON if it's a string
        const parsedTrip = typeof item.trip === 'string'
            ? JSON.parse(item.trip)
            : item.trip;

        // Check if trip is an array and use the first item if it exists
        const tripData = Array.isArray(parsedTrip) && parsedTrip.length > 0
            ? parsedTrip[0]
            : parsedTrip;

        return {
            id: item?.id,
            title: tripData?.title || undefined,
            dateFrom: tripData?.dateFrom || undefined,
            dateTo: tripData?.dateTo || undefined,
            description: tripData?.description || undefined,
            imageUrl: "https://plus.unsplash.com/premium_photo-1661887292499-cbaefdb169ce?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG9uZyUyMGtvbmclMjBza3lsaW5lfGVufDB8fDB8fHww" // Your placeholder
        };
    });
};

export const loadMyPosts = async (id:number): Promise <MyPostData[]> => {
    const { data, error } = await supabase
        .from('posts')
        .select('id, title, likes')
        .eq('created_by', id)

    if (error) throw error;

    return data.map(post => ({
        id: post.id as number,
        title: post.title as string,
        likes: post.likes as number,
        imageUrl: "https://plus.unsplash.com/premium_photo-1661887292499-cbaefdb169ce?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG9uZyUyMGtvbmclMjBza3lsaW5lfGVufDB8fDB8fHww" // Your placeholder
    }));
}


export const userInfoQuery = async (id:number) => {
    const { data, error } = await supabase
        .from('users')
        .select('name, email, posts(id), trips(id), saved(id)')
        .eq('id', id)
        .single();

    if (error) throw error;

    return {
        ...data,
        postCount: data.posts ? data.posts.length : 0,
        tripCount: data.trips ? data.trips.length : 0,
        saveCount: data.saved ? data.saved.length : 0
    };
}

export const usernameQuery = async (input: string) => {
    // For a "starts with" search pattern
    const { data, error } = await supabase
        .from('users')
        .select('name,id')
        .ilike('name', `${input}%`) // The % wildcard means "anything after"
        .order('name'); // Optional: ordering results alphabetically

    return { data, error };
}

//post/index.tsx
export const fetchPostIndex= async (id: string): Promise<PostIndex[]> => {
    const { data, error } = await supabase
        .from('posts')
        .select('id, title, content, likes, hashtags, created_by')
        .eq('id', Number(id));
    if (error) throw error;
    return data.map(post => ({
        id: post.id as number,
        created_by: post.created_by as number,
        title: post.title as string,
        content: post.content as string,
        hashtags: post.hashtags || [],
        likes: post.likes as number,
    }));
};

export const fetchPostComments = async (id: string): Promise<PostComment[]> => {
    const { data, error } = await supabase
        .from('posts_comments')
        .select('content, user_id, created_at, users (name), id')
        .eq('post_id', Number(id));
    if (error) throw error;
    return data.map(comment => ({
        id: comment.id as number,
        content: comment.content as string,
        user_id: comment.user_id as number,
        username: comment.users.name as string,
        timeAgo: formatDistanceToNow(new Date(comment.created_at), { addSuffix: true }) as string,
    }));
};

export const fetchCommentReplies = async (commentId: string): Promise<CommentReply[]> => {
    const { data, error } = await supabase
        .from('comments_replies')
        .select('id, comment_id, user_id, content, created_at, users (name)')
        .eq('comment_id', Number(commentId));
    if (error) throw error;
    return data.map(reply => ({
        reply_id: reply.id,
        content: reply.content,
        user_id: reply.user_id,
        username: reply.users?.name,
        comment_id: reply.comment_id,
        timeAgo: formatDistanceToNow(new Date(reply.created_at), { addSuffix: true }),
    }));
};

export const fetchLikeStatus = async (postId: string): Promise<boolean> => {
    const { data: authData } = await supabase.auth.getUser();
    if (!authData.user) throw new Error('Not authenticated');
    const { data: userData, error } = await supabase
        .from('users')
        .select('post_liked')
        .eq('uuid', authData.user.id)
        .single();
    if (error) throw error;
    const postLikedArray = userData.post_liked || [];
    return postLikedArray.includes(postId);
};

export const fetchImages = async (postId: string): Promise<string[]> => {
    const { data: files, error } = await supabase.storage
        .from('image')
        .list(`posts/${postId}`, { sortBy: { column: 'name', order: 'asc' } });
    if (error) throw error;
    return files.map(file =>
        supabase.storage.from('image').getPublicUrl(`posts/${postId}/${file.name}`).data.publicUrl
    );
};

export const fetchPostSavedStatus = async (postId: string, user_id: number): Promise<boolean> => {
    const { data: authData } = await supabase.auth.getUser();
    if (!authData.user) throw new Error('Not authenticated');

    const { data: userData, error } = await supabase
        .from('saved')
        .select('*')
        .eq('user_id', user_id) // Check for authenticated user
        .eq('post_id', Number(postId)) // Check for the specific postId

    if (error) throw error;

    return userData.length > 0;
};

//trip/index.tsx
export const fetchTripIndex = async (id: number): Promise<Trip> => {
    const { data, error } = await supabase
        .from('trips')
        .select('trip, created_by')
        .eq("id", id)
        .single(); // This ensures we get a single record, not an array

    if (error) throw error;

    //console.log("Raw data from Supabase:", JSON.stringify(data, null, 2));

    // Parse the JSON if it's a string
    const parsedTrip = typeof data.trip === 'string'
        ? JSON.parse(data.trip)
        : data.trip;

    // Check if trip is an array and use the first item if it exists
    const tripData = Array.isArray(parsedTrip) && parsedTrip.length > 0
        ? parsedTrip[0]
        : parsedTrip;

    return {
        title: tripData?.title || undefined,
        dateFrom: tripData?.dateFrom || undefined,
        dateTo: tripData?.dateTo || undefined,
        description: tripData?.description || undefined,
        day: tripData?.day || undefined,
        created_by: data.created_by || 0,
    };
};

export const fetchTripSavedStatus = async (trip_id: string, user_id: number): Promise<boolean> => {
    const { data: authData } = await supabase.auth.getUser();
    if (!authData.user) throw new Error('Not authenticated');

    const { data: userData, error } = await supabase
        .from('saved')
        .select('*')
        .eq('user_id', user_id) // Check for authenticated user
        .eq('trip_id', Number(trip_id)) // Check for the specific postId

    if (error) throw error;
    return userData.length > 0;
};


export const savedPostAndTrip = async (type: "TRIP" | "POST", userId: number, id: number) => {

    // Prepare the data to be inserted
    const insertData: SavedData = {
        type: type,
        user_id: userId,  // Include user_id in the insert data
    };

    // Add the appropriate ID based on the type
    if (type === 'TRIP') {
        insertData.trip_id = id; // Insert trip_id for TRIP type
    } else if (type === 'POST') {
        insertData.post_id = id; // Insert post_id for POST type
    } else {
        throw new Error("Invalid type. Must be 'TRIP' or 'POST'.");
    }

    // Insert the trip/post data and select the id of the inserted row
    const { data, error } = await supabase
        .from('saved')
        .insert([insertData])
        .select('id');  // This ensures that the inserted id is returned

    if (error) {
        throw new Error(`Failed to save: ${error.message}`);
    }

    return data; // Return the inserted data, which includes the id
};

export const loadSavedPosts = async (id: number): Promise<SavedPostData[]> => {
    const { data, error } = await supabase
        .from('saved')
        .select('id, posts (id, title, likes)')
        .eq('user_id', id)
        .eq('type', "POST")

    if (error) throw error;

    return data.map(item => ({
        id: item.posts?.id as number,
        title: item.posts?.title as string,
        likes: item.posts?.likes as number,
        imageUrl: "https://plus.unsplash.com/premium_photo-1661887292499-cbaefdb169ce?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG9uZyUyMGtvbmclMjBza3lsaW5lfGVufDB8fDB8fHww" // Your placeholder
    }));
}

export const loadSavedTrips = async (id: number): Promise<SavedTripData[]> => {

    const { data, error } = await supabase
        .from('saved')
        .select('trips (id, trip)')
        .eq('user_id', id)
        .eq('type', "TRIP")

    console.log(error)
    if (error) throw error;

    // Handle the case where trip is an array of objects
    return data.map(item => {
        // Parse the JSON if it's a string
        const parsedTrip = typeof item.trips?.trip === 'string'
            ? JSON.parse(item.trips?.trip)
            : item.trips?.trip;

        // Check if trip is an array and use the first item if it exists
        const tripData = Array.isArray(parsedTrip) && parsedTrip.length > 0
            ? parsedTrip[0]
            : parsedTrip;

        console.log(tripData);

        return {
            id: item?.trips?.id || 0,
            title: tripData?.title || undefined,
            dateFrom: tripData?.dateFrom || undefined,
            dateTo: tripData?.dateTo || undefined,
            description: tripData?.description || undefined,
            imageUrl: "https://plus.unsplash.com/premium_photo-1661887292499-cbaefdb169ce?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG9uZyUyMGtvbmclMjBza3lsaW5lfGVufDB8fDB8fHww" // Your placeholder
        };
    });
};