import supabase from "~/lib/supabase";

export const getUserId = async (): Promise<number | null> => {
    try {
        // Get authenticated user
        const { data: authData } = await supabase.auth.getUser();
        if (!authData.user) {
            throw new Error('Not authenticated');
        }

        // Get the user's ID from the users table
        const { data: userData, error } = await supabase
            .from('users')
            .select('id')
            .eq('uuid', authData.user.id)
            .single();

        if (error) {
            console.error('Error fetching user ID:', error);
            throw error;
        }

        return userData?.id ?? null; // Return user ID or null if not found
    } catch (error) {
        console.error('Error in getUserId:', error);
        throw error; // Re-throw error for further handling
    }
};

