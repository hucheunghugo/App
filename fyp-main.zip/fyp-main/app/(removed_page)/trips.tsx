import {View, Text, Image, TouchableOpacity, ScrollView, Pressable} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {Ionicons} from '@expo/vector-icons';
import {Link, router, useFocusEffect} from "expo-router";
import {useQuery} from "@tanstack/react-query";
import {loadMyPosts, loadMyTrips, postsQuery, saveTripToDatabase} from "~/app/query";
import {getUserId} from "~/app/utils/userData";
import {string} from "prop-types";
import {useTripStore} from "~/app/globalStorage";
import React, {useEffect, useState} from "react";

type MyTripData = {
    title: string;
    dateFrom: string;
    dateTo: string;
    description: string;
    imageUrl: string;
    onPress?: () => void;
};

interface MyPostData {
    id: number;
    title: string;
    likes: number;
    imageUrl: string;
    onPress?: () => void;
}

function MyTripCard({ title, dateFrom, dateTo, description, imageUrl, onPress }: MyTripData) {
    return (
        <TouchableOpacity
            className="mb-4 overflow-hidden rounded-xl bg-gray-100"
            onPress={onPress}
        >
            <View className="flex-row">
                <Image
                    source={{ uri: imageUrl }}
                    className="h-full w-36 rounded-xl"
                />
                <View className="flex-1 p-3 justify-center">
                    <Text className="text-lg font-semibold">{title}</Text>
                    <View className="mt-2">
                        <View className="flex-row items-center">
                            <Ionicons name="time-outline" size={16} color="#666" />
                            <Text className="ml-1 text-sm text-gray-600">{"From: " + dateFrom +"  To: "+ dateTo}</Text>
                        </View>
                        <Text className="text-sm text-gray-600 mt-1">{"Description: " + description}</Text>
                    </View>
                </View>
            </View>
        </TouchableOpacity>
    );
}

function MyPostCard({ title, likes, imageUrl, onPress }: MyPostData) {
    return (
        <TouchableOpacity
            className="mb-4 overflow-hidden rounded-xl bg-gray-100"
            onPress={onPress}
            style={{ height: 110 }} // Set a fixed height
        >
            <View className="flex-row h-full">
                <Image
                    source={{ uri: imageUrl }}
                    className="h-full w-36 rounded-xl"
                />
                <View className="flex-1 p-3 justify-center">
                    <Text className="text-lg font-semibold">{title}</Text>
                    <View className="mt-2">
                        <View className="flex-row items-center">
                            <Ionicons name="heart-outline" size={16} color="#666" />
                            <Text className="ml-1 text-sm text-gray-600">{likes}</Text>
                        </View>
                        <Text className="text-sm text-gray-600 mt-1">{"Description: "}</Text>
                    </View>
                </View>
            </View>
        </TouchableOpacity>
    );
}

export default function TravelPlanner() {

    const { data: myTrips, refetch: refetchTrips, isLoading: isLoadingMyTrips } = useQuery({
        queryKey: ['myTrips'],
        queryFn: async () => {
            const userId = await getUserId();
            if (!userId) throw new Error('User ID is not available');
            return loadMyTrips(userId);
        }
    });

    const { data: myPosts, refetch: refetchPosts, isLoading: isLoadingMyPosts } = useQuery({
        queryKey: ['myPosts'],
        queryFn: async () => {
            const userId = await getUserId();
            if (!userId) throw new Error('User ID is not available');
            return loadMyPosts(userId);
        }
    });

    // Use focus effect to refetch data when the screen gains focus
    useFocusEffect(
        React.useCallback(() => {
            refetchTrips();
            refetchPosts();
        }, [refetchTrips, refetchPosts])
    );

    // Function to render the horizontal trip section
    const TripSection = () => (
        <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            className="flex"
        >
            {myTrips?.map((tripData, index) => (
                <View key={index} className="mr-4" style={{ width: 280 }}>
                    <Pressable>
                        <MyTripCard
                            title={tripData.title || "Untitled Trip"}
                            description={tripData.description || ""}
                            dateFrom={tripData.dateFrom || ""}
                            dateTo={tripData.dateTo || ""}
                            imageUrl={tripData.imageUrl}
                            onPress={() => console.log(`Trip ${index} pressed`)}
                        />
                    </Pressable>
                </View>
            ))}
        </ScrollView>
    );

    const PostSection = () => (
        <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            className="flex"
        >
            {myPosts?.map((postData) => (
                <Link
                    key={postData.id}
                    href={{
                        pathname: '/posts',
                        params: { id: postData.id as unknown as string }
                    }}
                    asChild={true}
                >
                <View key={postData.id} className="mr-4" style={{ width: 280 }}>
                    <Pressable>
                        <MyPostCard
                            id={postData.id}
                            title={postData.title || "Untitled Post"}
                            likes={postData.likes}
                            imageUrl={postData.imageUrl}
                            onPress={() => router.push({
                                pathname: '/posts',
                                params: {
                                    PostID: postData.id,
                                }
                            })}
                        />
                    </Pressable>
                </View>
                </Link>
            ))}
        </ScrollView>
    );

    return (
        <SafeAreaView className="flex-1 bg-white">
            <View className="flex-1 px-4 pt-4">
                {isLoadingMyTrips ? (
                    <Text>Loading your trips...</Text>
                ) : myTrips && myTrips.length > 0 ? (
                    <>
                        {/* Top section - Horizontal Scrolling */}
                        <View className="mb-4">
                            <Text className="mb-4 text-2xl font-bold">Trips</Text>
                            {TripSection()}
                        </View>

                        {/* Divider */}
                        <View className="h-0.5 bg-gray-200 my-1" />

                        {/* Bottom section - Vertical layout */}
                        <View>
                            <Text className="mb-4 text-2xl font-bold">Posts</Text>
                            {PostSection()}
                        </View>
                    </>
                ) : (
                    <Text>No trips found. Create your first trip!</Text>
                )}
            </View>
        </SafeAreaView>
    );
}