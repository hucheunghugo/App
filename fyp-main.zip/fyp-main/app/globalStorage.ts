import {create} from "zustand";

interface ItineraryItem {
    type: 'location'; // This can be expanded if there are other types of itinerary items
    name: string;
    description: string;
    img_url: string;
}

interface Trip {
    title: string; // Changed from title to name for consistency
    description: string;
    dateFrom: string;
    dateTo: string;
    day: ItineraryItem[][];
}

interface TripState {
    trip: Trip; // Changed to always have a trip object, initialized with empty values
    isLoading: boolean;
    error: string | null;

    // Trip actions
    setTrip: (trip: Trip) => void;
    updateTrip: (tripData: Partial<Trip>) => void;
    resetTrip: () => void;

    // Field-by-field setters
    setTripTitle: (title: string) => void; // Changed from setTripTitle to setTripName
    setDescription: (description: string) => void;
    setDateFrom: (date: string) => void;
    setDateTo: (date: string) => void;

    // Itinerary management
    addDayItinerary: (dayIndex: number, itineraryItems: ItineraryItem[]) => void;
    updateDayItinerary: (dayIndex: number, updatedItems: ItineraryItem[]) => void;
    deleteDayItinerary: (dayIndex: number) => void;

    // Itinerary item management
    addItineraryItem: (dayIndex: number, item: ItineraryItem) => void;
    updateItineraryItem: (dayIndex: number, itemIndex: number, updatedItem: Partial<ItineraryItem>) => void;
    deleteItineraryItem: (dayIndex: number, itemIndex: number) => void;

    // Loading and error states
    setLoading: (isLoading: boolean) => void;
    setError: (error: string | null) => void;
}

const emptyTrip: Trip = {
    title: '',
    description: '',
    dateFrom: '',
    dateTo: '',
    day: []
};

export const useTripStore = create<TripState>((set) => ({
    trip: emptyTrip, // Initialize with empty trip instead of null
    isLoading: false,
    error: null,

    // Set the whole trip
    setTrip: (trip) => set({ trip }),

    // Update specific fields of the trip
    updateTrip: (tripData) => set((state) => ({
        trip: { ...state.trip, ...tripData },
    })),

    // Reset the trip to empty values
    resetTrip: () => set({ trip: emptyTrip }),

    // Set individual fields
    setTripTitle: (title) => set((state) => ({
        trip: { ...state.trip, title }
    })),
    
    setDescription: (description) => set((state) => ({
        trip: { ...state.trip, description }
    })),
    
    setDateFrom: (dateFrom) => set((state) => ({
        trip: { ...state.trip, dateFrom }
    })),

    setDateTo: (dateTo) => set((state) => ({
        trip: { ...state.trip, dateTo }
    })),

    // Day itinerary management - removed duplicate
    addDayItinerary: (dayIndex, itineraryItems) => set((state) => {
        const updatedDays = [...state.trip.day];
        // Ensure the array has enough elements
        while (updatedDays.length <= dayIndex) {
            updatedDays.push([]);
        }
        updatedDays[dayIndex] = itineraryItems;
        return { trip: { ...state.trip, day: updatedDays } };
    }),

    updateDayItinerary: (dayIndex, updatedItems) => set((state) => {
        if (dayIndex >= 0 && dayIndex < state.trip.day.length) {
            const updatedDays = [...state.trip.day];
            updatedDays[dayIndex] = updatedItems;
            return { trip: { ...state.trip, day: updatedDays } };
        }
        return {};
    }),

    deleteDayItinerary: (dayIndex) => set((state) => {
        if (dayIndex >= 0 && dayIndex < state.trip.day.length) {
            const updatedDays = [...state.trip.day];
            updatedDays.splice(dayIndex, 1);
            return { trip: { ...state.trip, day: updatedDays } };
        }
        return {};
    }),

    // Itinerary item actions
    addItineraryItem: (dayIndex, item) => set((state) => {
        const updatedDays = [...state.trip.day];
        // Ensure the array has enough elements
        while (updatedDays.length <= dayIndex) {
            updatedDays.push([]);
        }
        updatedDays[dayIndex] = [...(updatedDays[dayIndex] || []), item];
        return { trip: { ...state.trip, day: updatedDays } };
    }),

    updateItineraryItem: (dayIndex, itemIndex, updatedItem) => set((state) => {
        if (dayIndex >= 0 && dayIndex < state.trip.day.length &&
            itemIndex >= 0 && itemIndex < state.trip.day[dayIndex].length) {
            const updatedDays = [...state.trip.day];
            updatedDays[dayIndex] = [...updatedDays[dayIndex]];
            updatedDays[dayIndex][itemIndex] = { 
                ...updatedDays[dayIndex][itemIndex], 
                ...updatedItem 
            };
            return { trip: { ...state.trip, day: updatedDays } };
        }
        return {};
    }),

    deleteItineraryItem: (dayIndex, itemIndex) => set((state) => {
        if (dayIndex >= 0 && dayIndex < state.trip.day.length &&
            itemIndex >= 0 && itemIndex < state.trip.day[dayIndex].length) {
            const updatedDays = [...state.trip.day];
            updatedDays[dayIndex] = [...updatedDays[dayIndex]];
            updatedDays[dayIndex].splice(itemIndex, 1);
            return { trip: { ...state.trip, day: updatedDays } };
        }
        return {};
    }),

    // Loading and error states
    setLoading: (isLoading) => set({ isLoading }),
    setError: (error) => set({ error }),
}));