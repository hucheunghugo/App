import {View, Image, ScrollView, TouchableOpacity, TextInput, Dimensions, Alert} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {Ionicons} from '@expo/vector-icons';
import {useNavigation} from "@react-navigation/native";
import {Button} from "~/components/ui/button";
import {Text} from "~/components/ui/text";
import {Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle} from "~/components/ui/card";
import {Avatar, AvatarFallback, AvatarImage} from "~/components/ui/avatar";
import React, {useEffect, useState} from "react";
import {Input} from "~/components/ui/input";
import supabase from "~/lib/supabase";
import {formatDistanceToNow} from 'date-fns';
import {useQuery, useMutation, useQueryClient} from '@tanstack/react-query';
import {Skeleton} from "~/components/ui/skeleton";
import {useSharedValue} from "react-native-reanimated";
import {Link, router, useFocusEffect, useLocalSearchParams} from "expo-router";
import Carousel, {ICarouselInstance, Pagination} from "react-native-reanimated-carousel";
import {string} from "prop-types";
import {
    fetchPostIndex,
    fetchPostComments,
    fetchCommentReplies,
    fetchLikeStatus,
    fetchImages, savedPostAndTrip, fetchPostSavedStatus,
} from "~/app/query";
import {getUserId} from "~/app/utils/userData";

interface PostIndex {
    id: number,
    created_by: number,
    title: string,
    content: string,
    hashtags: string[],
    likes: number,
}

interface PostComment {
    id: number; // Assuming the comment ID is a string
    content: string; // The content of the comment
    user_id: string | number; // User ID can be a string or number depending on your data model
    username: string; // The name of the user who made the comment
    timeAgo: string; // A formatted string representing the time since the comment was created
}

interface CommentReply {
    reply_id: number,
    content: string | null;
    user_id: number | null; // Change this to number | null
    username: string | null | undefined;
    comment_id: number | null;
    timeAgo: string;
}

interface CommentProps {
    username: string,
    comment: string,
    timeAgo: string,
    avatarUrl: string,
    commentId: number,
    postId: string,
    userId: string | number
}

// Constants
const GITHUB_AVATAR_URI = 'https://github.com/mrzachnugent.png';
const width = Dimensions.get("window").width;

function CommentItem({username, comment, timeAgo, avatarUrl, commentId, postId, userId}: CommentProps) {
    const [isReplying, setIsReplying] = useState(false);
    const [showReplies, setShowReplies] = useState(false);
    const [replyText, setReplyText] = useState('');
    const queryClient = useQueryClient();
    const str_CommentId = commentId.toString();
    const replyMutation = useReplyMutation(postId, str_CommentId);

    const {data: replies = [], isLoading: isLoadingReplies} = useQuery({
        queryKey: ['replies', commentId],
        queryFn: () => fetchCommentReplies(str_CommentId),
        enabled: showReplies,
    });

    const handleReplySubmit = () => {
        if (!replyText.trim()) return;
        replyMutation.mutate(replyText);
        setReplyText('');
        setIsReplying(false);
    };

    return (
        <View style={{backgroundColor: '#1F1F1F', borderRadius: 8, marginBottom: 10}}>
            <View className="p-3">
                <View className="flex-row">
                    <Link
                        href={{
                            pathname: '/community/profile',
                            params: {user_id: userId as unknown as string }
                        }}
                        asChild={true}
                    >
                        <TouchableOpacity>
                            <Avatar alt="User's Avatar">
                                <AvatarImage source={{uri: avatarUrl || GITHUB_AVATAR_URI}}/>
                                <AvatarFallback><Text>ZN</Text></AvatarFallback>
                            </Avatar>
                        </TouchableOpacity>
                    </Link>
                    <View className="ml-3 flex-1">
                        <View className="flex-row items-center justify-between">
                            <Link
                            key={commentId}
                            href={{
                                pathname: '/community/profile',
                                params: {user_id: userId as unknown as string }
                            }}
                            asChild={true}
                            >
                             <Text className="font-semibold text-white">{username}</Text>
                            </Link>
                            <Text className="text-xs text-gray-400">{timeAgo}</Text>
                        </View>
                        <Text className="text-gray-300 mt-1">{comment}</Text>
                        <View className="flex-row items-center justify-between">
                            <TouchableOpacity className="py-1" onPress={() => setIsReplying(!isReplying)}>
                                <Text className="text-white text-xs font-bold">Reply</Text>
                            </TouchableOpacity>
                            <TouchableOpacity className="py-1" onPress={() => setShowReplies(!showReplies)}>
                                <Text className="text-white text-xs font-bold">
                                    {showReplies ? 'Hide Replies' : 'More Comments'}
                                </Text>
                            </TouchableOpacity>
                        </View>
                        {showReplies && (
                            <View className="mt-2">
                                {isLoadingReplies ? (
                                    <Text className="text-gray-400 text-xs">Loading replies...</Text>
                                ) : (
                                    replies.map(reply => (
                                        <View key={reply.reply_id} className="ml-5 mt-2 border-l border-gray-600 pl-3">
                                            <Text
                                                className="text-gray-300 text-xs font-semibold">{reply.username}</Text>
                                            <Text className="text-gray-400 text-xs">{reply.timeAgo}</Text>
                                            <Text className="text-gray-200 text-sm">{reply.content}</Text>
                                        </View>
                                    ))
                                )}
                            </View>
                        )}
                        {isReplying && (
                            <View className="mt-2">
                                <TextInput
                                    className="border border-gray-600 rounded px-3 py-2 text-sm text-white bg-gray-700"
                                    placeholder="Write your reply..."
                                    placeholderTextColor="gray"
                                    value={replyText}
                                    onChangeText={setReplyText}
                                />
                                <View className="flex-row mt-2">
                                    <TouchableOpacity className="py-1 px-3 bg-green-500 rounded mr-2"
                                                      onPress={handleReplySubmit}>
                                        <Text className="text-white text-sm">Send</Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity className="py-1 px-3 bg-gray-500 rounded"
                                                      onPress={() => setIsReplying(false)}>
                                        <Text className="text-white text-sm">Cancel</Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        )}
                    </View>
                </View>
            </View>
        </View>
    );
}

function HashtagItem({hashtag, onPress}: { hashtag: string; onPress: (hashtag: string) => void }) {
    return (
        <View className="rounded-full bg-gray-100 px-4 py-1">
            <TouchableOpacity onPress={() => onPress(hashtag)}>
                <Text className="text-gray-600">#{hashtag}</Text>
            </TouchableOpacity>
        </View>
    );
}

const useReplyMutation = (postId: string, commentId: string) => {
    const queryClient = useQueryClient();
    return useMutation({
        mutationFn: async (reply: string) => {
            const {data: authData} = await supabase.auth.getUser();
            if (!authData.user) throw new Error('Not authenticated');
            const {data: userData, error} = await supabase
                .from('users')
                .select('id')
                .eq('uuid', authData.user.id)
                .single();
            if (error) throw error;
            const {data: replyData, error: replyError} = await supabase
                .from('comments_replies')
                .insert([{comment_id: Number(commentId), user_id: userData.id, content: reply}])
                .select();
            if (replyError) throw replyError;
            return replyData[0];
        },
        onSuccess: () => {
            queryClient.invalidateQueries({
                queryKey: ['replies', commentId]
            });
        },
    });
};

// Main Component
export default function TripContent() {
    const navigation = useNavigation();
    const [value, setValue] = useState('');
    const [showAllComments, setShowAllComments] = useState(false);
    const queryClient = useQueryClient();
    const {PostID} = useLocalSearchParams() as { PostID: string };
    const ref = React.useRef<ICarouselInstance>(null);
    const progress = useSharedValue<number>(0);
    const [isCreator, setIsCreator] = useState(false);
    const [userId, setUserId] = useState<number>(0); // Default value of 0
    const [showDropdown, setShowDropdown] = useState(false);

    // Add this function to handle the dropdown toggle
    const toggleDropdown = () => {
        setShowDropdown(!showDropdown);
    };

    // Queries
    const {data: posts = [], isLoading: isLoadingPosts} = useQuery({
        queryKey: ['posts', PostID],
        queryFn: () => fetchPostIndex(PostID),
    });

    const {data: comments = [], isLoading: isLoadingComments} = useQuery({
        queryKey: ['comments', PostID],
        queryFn: () => fetchPostComments(PostID),
    });

    const {data: isLiked = false, isLoading: isLoadingLikeStatus} = useQuery({
        queryKey: ['likeStatus', PostID],
        queryFn: () => fetchLikeStatus(PostID),
    });

    const {data: imageURL = [], isLoading: isLoadingImages} = useQuery({
        queryKey: ['images', PostID],
        queryFn: () => fetchImages(PostID),
    });

    const {data: isSaved , refetch: refetchIsSavedStatus, isLoading: isLoadingSavedStatus} = useQuery({
        queryKey: ['savedStatus', PostID],
        queryFn: () => fetchPostSavedStatus(PostID, userId),
    });

    // Mutations
    const commentMutation = useMutation({
        mutationFn: async (newComment: string) => {
            const {data: authData} = await supabase.auth.getUser();
            if (!authData.user) throw new Error('Not authenticated');
            const {data: userData, error} = await supabase
                .from('users')
                .select('id')
                .eq('uuid', authData.user.id)
                .single();
            if (error) throw error;
            const {data, error: insertError} = await supabase
                .from('posts_comments')
                .insert([{post_id: Number(PostID), user_id: userData.id, content: newComment}])
                .select();
            if (insertError) throw insertError;
            return data[0];
        },
        onSuccess: () => {
            queryClient.invalidateQueries({
                queryKey: ['comments', PostID]
            });
            setValue('');
        },
    });

    const likeMutation = useMutation({
        mutationFn: async (shouldLike: boolean) => {

            const {data: userData, error} = await supabase
                .from('users')
                .select('post_liked')
                .eq('uuid', userId.toString())
                .single();
            if (error) throw error;

            const postLikedArray = (userData).post_liked || [];
            const newPostLikedArray = shouldLike
                ? [...postLikedArray, PostID]
                : postLikedArray.filter(postId => postId !== PostID);

            await supabase.from('users').update({post_liked: newPostLikedArray}).eq('uuid', userId.toString());
            const {data: postData} = await supabase.from('posts').select('likes').eq('id', Number(PostID)).single();
            const currentLikes = postData?.likes || 0;
            await supabase.from('posts').update({likes: shouldLike ? currentLikes + 1 : currentLikes - 1}).eq('id', Number(PostID));
        },
        onSuccess: () => {
            queryClient.invalidateQueries({
                queryKey: ['posts', PostID]
            });
            queryClient.invalidateQueries({
                queryKey: ['likeStatus', PostID]
            });
        },
    });

    // Handlers
    const handlePostComment = () => {
        if (!value.trim()) return;
        commentMutation.mutate(value);
    };

    const handleLikeToggle = () => {
        likeMutation.mutate(!isLiked);
    };

    const handleHashtagClick = (hashtag: string) => {
        console.log(`Clicked on hashtag: ${hashtag}`);
    };

    const onPressPagination = (index: number) => {
        ref.current?.scrollTo({count: index - progress.value, animated: true});
    };

    const displayedComments = showAllComments ? comments : comments.slice(0, 3);
    const hasMoreComments = comments.length > 3;

    const deletePost = async () => {
        try {

            // Confirm deletion with user
            Alert.alert(
                'Delete Post',
                'Are you sure you want to delete this post? This action cannot be undone.',
                [
                    {
                        text: 'Cancel',
                        style: 'cancel',
                    },
                    {
                        text: 'Delete',
                        style: 'destructive',
                        onPress: async () => {
                            // Delete comments first to maintain referential integrity
                            await supabase.from('posts_comments').delete().eq('id', Number(PostID));

                            // Delete the post
                            const {error} = await supabase.from('posts').delete().eq('id', Number(PostID));

                            if (error) {
                                console.error('Error deleting post:', error);
                                Alert.alert('Error', 'Failed to delete post');
                                return;
                            }

                            // Delete images from storage
                            await supabase.storage.from('image').remove([`posts/${PostID}`]);

                            // Navigate back and refresh posts list
                            queryClient.invalidateQueries({
                                queryKey: ['post']
                            });
                            navigation.goBack();
                        },
                    },
                ],
                {cancelable: true}
            );
        } catch (error) {
            console.error('Error in delete process:', error);
            Alert.alert('Error', 'An unexpected error occurred');
        }
    };

    const handleSave = async () => {
        if (isSaved){
            await supabase
                .from('saved')
                .delete()
                .eq('post_id', Number(PostID))
                .eq('user_id', userId);
        } else {
            try {
                await savedPostAndTrip("POST", userId, Number(PostID));
            } catch (error) {
                console.error("Error saving post:", error);
                Alert.alert('Error', 'Failed to save post');
            }
        }

        await refetchIsSavedStatus();
    };

    useEffect(() => {
        // Function to load user ID
        const loadUserId = async () => {
            try {
                const id = await getUserId(); // Await the Promise
                if (id !== null) { // Check for null explicitly
                    setUserId(id);
                }
            } catch (error) {
                console.error("Error loading user ID:", error);
            }
        };

        // Call the function to load user ID
        loadUserId();

        // Refetch data when the screen gains focus
        refetchIsSavedStatus();

        // Check if the current user is the post creator
        if (!isLoadingPosts && posts.length > 0) {
            setIsCreator(posts[0].created_by === userId);
        }

        // Cleanup function (if needed)
        return () => {
            // Any cleanup logic can go here
        };
    }, [isLoadingPosts, posts, userId, isSaved]); // Combine dependencies

    return (
        <SafeAreaView className="flex-1 bg-white">
            <View className="flex-1">
                <ScrollView className="mb-16">
                    <View className="relative h-30 w-full overflow-hidden">
                        {isLoadingImages ? (
                            <Skeleton className="h-full w-full"/>
                        ) : imageURL.length > 0 ? (
                            imageURL.length === 1 ? (
                                <Image source={{uri: imageURL[0]}}
                                       style={{width: '100%', height: '100%', resizeMode: 'cover'}}/>
                            ) : (
                                <>
                                    <Carousel
                                        ref={ref}
                                        width={width}
                                        height={width / 2}
                                        data={imageURL}
                                        onProgressChange={progress}
                                        renderItem={({index}) => (
                                            <Image source={{uri: imageURL[index]}}
                                                   style={{width: '100%', height: '100%', resizeMode: 'cover'}}/>
                                        )}
                                    />
                                    <Pagination.Basic
                                        progress={progress}
                                        data={imageURL}
                                        dotStyle={{backgroundColor: "rgba(0,0,0,0.2)", borderRadius: 50}}
                                        containerStyle={{gap: 5, marginTop: 10}}
                                        onPress={onPressPagination}
                                    />
                                </>
                            )
                        ) : (
                            <View className="h-20 w-full flex items-center justify-center">
                            </View>
                        )}
                        <View className="absolute top-4 left-4 right-4 flex-row justify-between">
                            <TouchableOpacity
                                className="bg-white rounded-full p-2"
                                onPress={() => router.back()}
                            >
                                <Ionicons name="arrow-back" size={20} color="#333" />
                            </TouchableOpacity>
                            <View className="flex-row">
                                <TouchableOpacity
                                    className="bg-white rounded-full p-2 mr-2"
                                    onPress={() => {
                                        console.log('Save Post');
                                        handleSave();
                                    }}>
                                    {isSaved ? (
                                        <Ionicons name="bookmark" size={20} color="#333" />
                                    ) : (
                                        <Ionicons name="bookmark-outline" size={20} color="#333" />
                                    )}
                                </TouchableOpacity>
                                <TouchableOpacity className="bg-white rounded-full p-2"
                                                  onPress={toggleDropdown}>
                                    <Ionicons name="ellipsis-vertical-outline" size={20} color="black"/>
                                </TouchableOpacity>
                                {/* Dropdown menu */}
                                {showDropdown && (
                                    <View className="absolute right-2 top-12 bg-white rounded-lg shadow-lg z-10 w-30">
                                        {isCreator ? (
                                            <TouchableOpacity
                                                className="px-4 py-3 border-b border-gray-200"
                                                onPress={() => {
                                                    console.log('Delete Trip');
                                                    setShowDropdown(false);
                                                    deletePost();
                                                }}
                                            >
                                                <Text className="text-gray-800">Delete Trip</Text>
                                            </TouchableOpacity>
                                        ) : (
                                            <View/>
                                        )}
                                        <TouchableOpacity
                                            className="px-4 py-3 border-b border-gray-200"
                                            onPress={() => {
                                                console.log('Save Trip');
                                                setShowDropdown(false);
                                            }}
                                        >
                                            <Text className="text-gray-800">Save Trip</Text>
                                        </TouchableOpacity>
                                        <TouchableOpacity
                                            className="px-4 py-3"
                                            onPress={() => {
                                                console.log('Report Trip');
                                                setShowDropdown(false);
                                            }}
                                        >
                                            <Text className="text-gray-800">Report</Text>
                                        </TouchableOpacity>
                                    </View>
                                )}
                            </View>
                        </View>
                    </View>

                    {posts.some(post => post.hashtags?.length > 0) && (
                        <View className="flex-row gap-2 p-4">
                            {posts.flatMap(post => post.hashtags?.map((hashtag, index) => (
                                <HashtagItem key={index} hashtag={hashtag} onPress={handleHashtagClick}/>
                            )) || [])}
                        </View>
                    )}

                    <View className="p-4">
                        <View className="flex-row items-center justify-between">
                            <View className="flex-row items-center">
                                <Image
                                    source={{uri: 'https://plus.unsplash.com/premium_photo-1661887292499-cbaefdb169ce?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG9uZyUyMGtvbmclMjBza3lsaW5lfGVufDB8fDB8fHww'}}
                                    className="h-12 w-12 rounded-lg"
                                />
                                {isLoadingPosts ? (
                                    <Skeleton className="ml-3 h-6 w-32"/>
                                ) : (
                                    posts.map(post => (
                                        <Text key={post.id} className="ml-3 text-lg font-semibold">{post.title}</Text>
                                    ))
                                )}
                            </View>
                            <TouchableOpacity>
                                <Ionicons name="chevron-forward" size={24} color="black"/>
                            </TouchableOpacity>
                        </View>

                        <View className="mt-4">
                            {isLoadingPosts ? (
                                <Skeleton className="h-24 w-full"/>
                            ) : (
                                posts.map(post => (
                                    <Text key={post.id} className="text-base leading-6 text-gray-700">
                                        <Text>✨ </Text>{post.content}
                                    </Text>
                                ))
                            )}
                        </View>

                        <ScrollView className="mt-6 border-t border-gray-200 pt-4">
                            <Text className="mb-4 text-lg font-semibold">Comments</Text>
                            {isLoadingComments ? (
                                Array.from({length: 2}).map((_, i) => (
                                    <View key={i} className="mb-4 flex-row">
                                        <Skeleton className="h-10 w-10 rounded-full"/>
                                        <View className="ml-3 flex-1">
                                            <Skeleton className="h-4 w-24"/>
                                            <Skeleton className="mt-2 h-12 w-full"/>
                                        </View>
                                    </View>
                                ))
                            ) : (
                                <>
                                    {displayedComments.map(comment => (
                                        <CommentItem
                                            key={comment.id}
                                            username={comment.username}
                                            comment={comment.content}
                                            timeAgo={comment.timeAgo}
                                            commentId={comment.id}
                                            userId={comment.user_id}
                                            postId={PostID}
                                            avatarUrl={GITHUB_AVATAR_URI}
                                        />
                                    ))}
                                    {hasMoreComments && !showAllComments && (
                                        <TouchableOpacity className="my-2 py-2"
                                                          onPress={() => setShowAllComments(true)}>
                                            <Text className="text-center text-blue-500 font-semibold">
                                                View {comments.length - 3} more comments
                                            </Text>
                                        </TouchableOpacity>
                                    )}
                                    {showAllComments && hasMoreComments && (
                                        <TouchableOpacity className="my-2 py-2"
                                                          onPress={() => setShowAllComments(false)}>
                                            <Text className="text-center text-blue-500 font-semibold">Show less</Text>
                                        </TouchableOpacity>
                                    )}
                                </>
                            )}
                        </ScrollView>
                    </View>
                </ScrollView>

                <View className="absolute bottom-0 w-full border-t border-gray-200 bg-white p-4">
                    <View className="flex-row items-center justify-between gap-4">
                        <Input
                            className="flex-1 border-r-accent"
                            placeholder="Write some stuff..."
                            value={value}
                            onChangeText={setValue}
                        />
                        <TouchableOpacity className="bg-blue-500 px-3 py-2 rounded-lg" onPress={handlePostComment}>
                            <Text className="text-white font-semibold">Post</Text>
                        </TouchableOpacity>
                        <View className="flex flex-row gap-4">
                            <TouchableOpacity className="flex-row items-center" onPress={handleLikeToggle}>
                                <Ionicons
                                    name={isLiked ? "heart" : "heart-outline"}
                                    size={24}
                                    color={isLiked ? "red" : "black"}
                                />
                                <Text className="ml-2">{posts[0]?.likes || 0}</Text>
                            </TouchableOpacity>
                            <TouchableOpacity>
                                <Ionicons name="share-social-outline" size={24} color="black"/>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </View>
        </SafeAreaView>
    );
}
