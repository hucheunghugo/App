import React, {useCallback, useRef, useState} from 'react';
import {View, TextInput, TouchableOpacity, ScrollView, Image, Pressable, StyleSheet, Alert} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {ChevronLeft, MapPin, Eye, Save, ChevronRight} from 'lucide-react-native';
import {Text} from '~/components/ui/text';
import {useNavigation} from '@react-navigation/native';
import {Textarea} from "~/components/ui/textarea";
import {Link, useRouter} from "expo-router";
import * as ImagePicker from 'expo-image-picker';
import {
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle, AlertDialogTrigger
} from '~/components/ui/alert-dialog';
import { AlertDialog } from '~/components/ui/alert-dialog';
import {BottomSheetBackdrop, BottomSheetModal, BottomSheetView} from "@gorhom/bottom-sheet";
import { RadioGroup, RadioGroupItem } from '~/components/ui/radio-group';
import {Label} from "~/components/ui/label";
import {Database} from "~/database.types";
import { useForm, Controller, SubmitHandler } from "react-hook-form"
import {cn} from "~/lib/utils";
import {useMutation} from "@tanstack/react-query";
import supabase from "~/lib/supabase";
import { decode } from 'base64-arraybuffer'
import { BottomSheetDefaultBackdropProps } from '@gorhom/bottom-sheet/lib/typescript/components/bottomSheetBackdrop/types';

interface IFormInput {
    title: string
    content: string
    visbility: Database["public"]["Enums"]["visbility"]
}

const CreatePost: React.FC = () => {
    const navigation = useNavigation();
    const [title, setTitle] = useState('');
    const [image, setImage] = useState<string[] | null>([]);
    const [radioValue, setRadioValue] = React.useState('Public');
    const [content, setContent] = React.useState('');
    const bottomSheetModalRef = useRef<BottomSheetModal>(null);
    const router = useRouter();
    const {control, handleSubmit, formState: {errors}} = useForm({
        defaultValues: {
            title: "",
            content: "",
            visbility: 'PUBLIC',
        },
    })

    const arrayBufferToBase64 = (buffer: ArrayBuffer) => {
        let binary = '';
        const bytes = new Uint8Array(buffer);
        const len = bytes.byteLength;
        for (let i = 0; i < len; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return `data:image/jpeg;base64,${btoa(binary)}`; // Use 'image/jpeg' for JPG
    };

    const pickImage = async () => {
        const res = await ImagePicker.getMediaLibraryPermissionsAsync();
        let result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ['images'],
            allowsEditing: true,
            aspect: [4, 3],
            quality: 1,
        });
        if (!result.canceled) {
            const response = await fetch(result.assets[0].uri);
            const arrayBuffer = await response.arrayBuffer(); // Fetch as ArrayBuffer
            const base64Image = arrayBufferToBase64(arrayBuffer); // Convert to Base64
            setImage((prev) => [...prev, base64Image]); // Store Base64 image
        }
    };

    const photoUploading = async (base64Image: string, imageName: string) => {
        try {

            const base64Data = base64Image.split(',')[1]; // Strip off the data URL part

            const {data, error} = await supabase.storage
                .from('image')
                .upload(`posts/${imageName}`, decode(base64Data), {
                    contentType: 'image/jpeg', // Set the content type to 'image/jpeg'
                });

            if (error) {
                throw new Error(`Image Upload error: ${error.message}`);
            }

            console.log('File uploaded successfully:', data?.path);

            const {publicURL} = supabase.storage
                .from('image')
                .getPublicUrl(`posts/${imageName}`);

            console.log('Public URL:', publicURL);
            return publicURL; // Return the public URL
        } catch (error) {
            console.error('Upload error:', error.message);
            throw error; // Rethrow the error to handle it in the calling function
        }
    };

    const createPostMutation = useMutation({
        mutationKey: ['createPost'],
        mutationFn: async (data: IFormInput & { hashtags: string[] }) => {

            const {data: authData} = await supabase.auth.getUser();
            if (!authData.user) throw new Error('Not authenticated');
            const {data: userData, error} = await supabase
                .from('users')
                .select('id')
                .eq('uuid', authData.user.id)
                .single();

            console.log(data)
            console.log(data.hashtags)

            // Validate images
            if (!image || image.length === 0) {
                Alert.alert('Validation Error', 'At least one image is required.');
                throw new Error('No images provided');
            }

            // Loop through each hashtag
            for (const hashtag of data.hashtags) {
                // Check if the hashtag already exists
                const {data: existingHashtags, error: fetchError} = await supabase
                    .from('hashtags')
                    .select('id')
                    .eq('hashtag', hashtag)
                    .single();

                if (fetchError && fetchError.code !== 'PGRST116') { // Handle error here (not found)
                    console.error("Error fetching hashtag:", fetchError);
                    throw fetchError;
                }

                if (!existingHashtags) {
                    // If hashtag does not exist, insert it
                    const {data: newHashtag, error: insertError} = await supabase
                        .from('hashtags')
                        .insert([{hashtag: hashtag, number: 1}])
                        .select();

                    if (insertError) {
                        console.error("Error inserting hashtag:", insertError);
                        throw insertError;
                    }

                    console.log("Inserted new hashtag:", newHashtag);
                } else {

                    const {data: existingHashtags, error: fetchError} = await supabase
                        .from('hashtags')
                        .select('number')
                        .eq('hashtag', hashtag)
                        .single();

                    if (fetchError) {
                        console.error("Error fetching hashtag:", fetchError);
                        throw fetchError;
                    }

                    const currentNumber = existingHashtags ? existingHashtags.number : 0; // Default to 0 if not found
                    const newNumber = currentNumber ? currentNumber + 1 : 0 // Increment the current value

                    const {data: updatedHashtag, error: updateError} = await supabase
                        .from('hashtags')
                        .update({
                            number: newNumber
                        })
                        .eq('hashtag', hashtag)
                        .select();

                    if (updateError) {
                        console.error("Error updating hashtag:", updateError);
                        throw updateError;
                    }

                    console.log("Updated existing hashtag:", updatedHashtag);
                }
            }

            const {data: postData, error: postError} = await supabase
                .from('posts')
                .insert([
                    {
                        title: data.title,
                        content: data.content,
                        visibility: 'PUBLIC',
                        hashtags: data.hashtags,
                        created_by: userData?.id
                    },
                ])
                .select('id') // Specify that you want to return the 'id' field
            console.log('ID: ' + authData.user.id)
            const imageUploadPromises = image.map((base64Image, index) => {

                if (postData) {
                    const imageName = `${postData[0].id}/${index + 1}.jpg`;
                    // Use .jpg extension
                    return photoUploading(base64Image, imageName); // Upload image
                }
            });

            const publicURLs = await Promise.all(imageUploadPromises);
            console.log('Uploaded image URLs:', publicURLs);
        },
        onSuccess: () => {
            console.log('success!')
            router.navigate('/(tabs)/newTrip')
        },
        onError: (error) => {
            console.error('Error creating post:', error);
        }
    })


    const handlePresentModalPress = useCallback(() => {
        bottomSheetModalRef.current?.present();
    }, []);

    function onLabelPress(label: string) {
        return () => {
            setRadioValue(label);
            bottomSheetModalRef.current?.dismiss()
        };
    }

    const onSubmit: SubmitHandler<IFormInput> = (data) => {
        createPostMutation.mutate({...data, hashtags});
    };


    const onPreview: SubmitHandler<IFormInput> = (data) => {
        console.log(data)
    }

    const renderBackdrop = useCallback(
        (props: React.JSX.IntrinsicAttributes & BottomSheetDefaultBackdropProps) => (
            <BottomSheetBackdrop
                {...props}
                disappearsOnIndex={-1}
                pressBehavior="close"
                opacity={1}
            />
        ),
        [],
    );

    const [hashtags, setHashtags] = useState<string[]>([]);
    const [hashtagInput, setHashtagInput] = useState('');

    const handleAddHashtag = () => {
        if (hashtagInput.trim() && !hashtags.includes(hashtagInput.trim())) {
            setHashtags([...hashtags, hashtagInput.trim()]);
            setHashtagInput('');
        }
    };

    const handleRemoveHashtag = (tag: string) => {
        setHashtags(hashtags.filter((t) => t !== tag));
    };

    function RadioGroupItemWithLabel({
                                         value,
                                         onLabelPress,
                                     }: {
        value: string;
        onLabelPress: () => void;
    }) {
        return (
            <Pressable className={'flex-row gap-2 items-center'}>
                <RadioGroupItem aria-labelledby={`label-for-${value}`} value={value} />
                <Label nativeID={`label-for-${value}`} onPress={onLabelPress}>
                    {value}
                </Label>
            </Pressable>
        );
    }

    return (
        <SafeAreaView className="flex-1 bg-white">
            {/* Header */}
            <View className="flex-row items-center px-4 py-4 border-b border-gray-200 gap-4">
                <AlertDialog>
                    <AlertDialogTrigger asChild>
                        <ChevronLeft size={24} color="black"/>
                    </AlertDialogTrigger>
                    <AlertDialogContent className={"w-full"}>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This action cannot be undone.
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>
                                <Text>Cancel</Text>
                            </AlertDialogCancel>
                            <AlertDialogAction onPress={() => navigation.goBack()}>
                                <Text>Continue</Text>
                            </AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
                <Text className={"text-2xl font-bold"}>New post</Text>
            </View>
            <ScrollView className="flex-1">
                {/* Image Upload Section */}

                <View className="flex-row p-4">
                    {
                        image?.map((img, index) => {
                            return (
                                <View className="w-24 h-24 bg-gray-100 rounded-md overflow-hidden mr-2" key={index}>
                                    <Image
                                        source={{uri: img}}
                                        className="w-full h-full"
                                    />
                                </View>

                            )
                        })
                    }
                    <Pressable className="w-24 h-24 bg-gray-100 rounded-md items-center justify-center"
                               onPress={pickImage}>
                        <Text className="text-3xl text-gray-400">+</Text>
                    </Pressable>
                </View>

                {/* Title Input */}
                <View className="px-4">
                    <Controller
                        name="title"
                        control={control}
                        rules={{
                            required: "Title is required",
                        }}
                        render={({ field: { onChange, onBlur, value } }) => (
                            <>
                                <TextInput
                                    placeholder="Add a title"
                                    onBlur={onBlur}
                                    onChangeText={onChange}
                                    value={value}
                                    className={cn(
                                        "text-lg py-2 font-bold",
                                        errors.title && "border-red-500"
                                    )}
                                />
                                {errors.title && (
                                    <Text className="text-red-500 text-sm mt-1">
                                        {errors.title.message}
                                    </Text>
                                )}
                            </>
                        )}
                    />

                </View>

                {/* Content Input */}
                <View className="px-4">
                    <Controller
                        name="content"
                        control={control}
                        rules={{
                            required: "Content is required",
                        }}
                        render={({ field: { onChange, onBlur, value } }) => (
                            <>
                                <Textarea
                                    placeholder='Write some stuff...'
                                    onBlur={onBlur}
                                    onChangeText={onChange}
                                    value={value}
                                    aria-labelledby='textareaLabel'
                                    className={cn(
                                        "text-base border-0 h-48 px-0",
                                        errors.content && "border-red-500"
                                    )}
                                />
                                {errors.content && (
                                    <Text className="text-red-500 text-sm mt-1">
                                        {errors.content.message}
                                    </Text>
                                )}
                            </>
                        )}
                    />
                </View>

                {/* Location Section */}
                {/*<View className=" pt-6 py-6 border-t border-gray-100 gap-4">*/}
                {/*    <View className="px-4 flex-row items-center justify-between">*/}
                {/*        <View className="flex-row items-center">*/}
                {/*            <MapPin size={20} color="gray"/>*/}
                {/*            <Text className="ml-2">Trips</Text>*/}
                {/*        </View>*/}
                {/*    </View>*/}
                {/*    <Link href={"/"} asChild={true}>*/}
                {/*        <Pressable*/}
                {/*            className="p-4 mx-4 flex-row items-center justify-between bg-gray-200 rounded-md">*/}
                {/*            <Text className={"font-bold"}>Select...</Text>*/}
                {/*            <ChevronLeft size={20} color="black" style={{transform: [{rotate: '180deg'}]}}/>*/}
                {/*        </Pressable>*/}

                {/*    </Link>*/}
                {/*</View>*/}

                {/* Privacy Settings */}
                {/*<View className="px-4 py-6 border-t border-gray-500 gap-4">*/}
                {/*    <View className=" flex-row items-center justify-between">*/}
                {/*        <View className="flex-row items-center">*/}
                {/*            <Eye size={20} color="gray"/>*/}
                {/*            <Text className="ml-2">Visbility</Text>*/}
                {/*        </View>*/}
                {/*    </View>*/}
                {/*    <TouchableOpacity className="flex-row items-center justify-between"*/}
                {/*                      onPress={handlePresentModalPress}>*/}
                {/*        <Text>{radioValue}</Text>*/}
                {/*        <ChevronLeft size={20} color="gray" style={{transform: [{rotate: '180deg'}]}}/>*/}
                {/*    </TouchableOpacity>*/}
                {/*</View>*/}
                {/*<Controller*/}
                {/*    name="content"*/}
                {/*    control={control}*/}
                {/*    rules={{*/}
                {/*        required: true,*/}
                {/*    }}*/}
                {/*    render={({ field }) => (*/}
                {/*        <BottomSheetModal*/}
                {/*            ref={bottomSheetModalRef}*/}
                {/*            index={0}*/}
                {/*            backdropComponent={renderBackdrop}*/}
                {/*            backgroundStyle={{*/}
                {/*                backgroundColor: '#FFFFFF',*/}
                {/*            }}*/}
                {/*            enableDynamicSizing={true}*/}
                {/*        >*/}
                {/*            <BottomSheetView style={styles.contentContainer}>*/}
                {/*                <View className='flex-1 justify-center px-6 mb-4'>*/}
                {/*                    <Text className={"text-2xl font-bold pb-4"}>Visibility settings</Text>*/}
                {/*                    <RadioGroup value={radioValue} onValueChange={setRadioValue}*/}
                {/*                                className='gap-3 color-amber-100'>*/}
                {/*                        <RadioGroupItemWithLabel value='Public' onLabelPress={onLabelPress('Public')}/>*/}
                {/*                        <RadioGroupItemWithLabel value='Linked only'*/}
                {/*                                                 onLabelPress={onLabelPress('Linked only')}/>*/}
                {/*                        <RadioGroupItemWithLabel value='Private' onLabelPress={onLabelPress('Private')}/>*/}
                {/*                    </RadioGroup>*/}
                {/*                </View>*/}
                {/*            </BottomSheetView>*/}
                {/*        </BottomSheetModal>*/}
                {/*    )}*/}
                {/*/>*/}
                {/* Hashtag Section */}
                <View className="px-4 pb-4">
                    <Text className="text-lg font-bold">Hashtags</Text>
                    <View className="flex-row items-center mt-2 border border-gray-300 rounded-md p-2">
                        <TextInput
                            className="flex-1 text-base"
                            placeholder="Add hashtag..."
                            value={hashtagInput}
                            onChangeText={setHashtagInput}
                            onSubmitEditing={handleAddHashtag}
                        />
                        <TouchableOpacity onPress={handleAddHashtag} className="px-2 py-1 bg-blue-500 rounded-md">
                            <Text className="text-white">Add</Text>
                        </TouchableOpacity>
                    </View>
                    <View className="flex-row flex-wrap mt-2">
                        {hashtags.map((tag, index) => (
                            <View key={index} className="flex-row items-center bg-gray-200 rounded-full px-3 py-1 m-1">
                                <Text className="text-gray-800">#{tag}</Text>
                                <TouchableOpacity onPress={() => handleRemoveHashtag(tag)} className="ml-2">
                                    <Text className="text-red-500">✕</Text>
                                </TouchableOpacity>
                            </View>
                        ))}
                    </View>
                </View>
            </ScrollView>

            {/* Bottom Bar */}
            <View className="flex-row items-center px-4 py-3 border-t border-gray-200">
                {/*<TouchableOpacity className="mr-4 flex-row items-center">*/}
                {/*    <Save size={24} color="gray"/>*/}
                {/*    <Text className="ml-2">Save</Text>*/}
                {/*</TouchableOpacity>*/}
                <TouchableOpacity className="mr-4 flex-row items-center">
                    <Eye size={24} color="gray"/>
                    <Text className="ml-2">Preview</Text>
                </TouchableOpacity>
                <TouchableOpacity className="flex-1" onPress={handleSubmit(onSubmit)}>
                    <View className="bg-red-500 rounded-full py-3">
                        <Text className="text-white text-center font-bold" >Post</Text>
                    </View>
                </TouchableOpacity>
            </View>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 24,
        justifyContent: 'center',
        backgroundColor: 'grey',
    },
    contentContainer: {
        flex: 1,
    },
});

export default CreatePost;
