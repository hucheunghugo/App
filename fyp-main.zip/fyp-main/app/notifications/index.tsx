import React from 'react';
import { View, Text, TouchableOpacity, FlatList, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ChevronLeft } from 'lucide-react-native';
import {useNavigation} from "@react-navigation/native";

interface Notification {
    id: string;
    type: 'like' | 'follow' | 'like_reel' | 'multiple_likes';
    username: string;
    additionalUsers?: number;
    time: string;
    section: 'Today' | 'Yesterday' | 'This Week';
    thumbnail?: string;
    contentThumbnail?: string;
}

const NotificationItem: React.FC<{ notification: Notification }> = ({ notification }) => {
    return (
        <TouchableOpacity className="flex-row items-center px-4 py-3">
            <Image
                source={{ uri: notification.thumbnail }}
                className="w-12 h-12 rounded-full"
            />
            <View className="flex-1 ml-3">
                <Text className="text-black">
                    <Text className="font-semibold">{notification.username}</Text>
                    {notification.type === 'like' && ' liked your photo. '}
                    {notification.type === 'follow' && ' is on Instagram. '}
                    {notification.type === 'like_reel' && ' liked your reel. '}
                    {notification.type === 'multiple_likes' &&
                        `, ${notification.additionalUsers} others liked your reel. `}
                    <Text className="text-gray-500">{notification.time}</Text>
                </Text>
            </View>
            {notification.contentThumbnail && (
                <Image
                    source={{ uri: notification.contentThumbnail }}
                    className="w-12 h-12"
                />
            )}
            {notification.type === 'follow' && (
                <TouchableOpacity className="bg-[#0095F6] px-6 py-2 rounded-md">
                    <Text className="text-white font-semibold">Follow</Text>
                </TouchableOpacity>
            )}
        </TouchableOpacity>
    );
};

const NotificationsScreen: React.FC = () => {
    const navigation = useNavigation()
    const notifications: Notification[] = [
        {
            id: '1',
            type: 'like',
            username: 'city77photo',
            time: '14h',
            section: 'Today',
            thumbnail: 'https://placeholder.com/150',
            contentThumbnail: 'https://placeholder.com/150'
        },
        {
            id: '2',
            type: 'follow',
            username: 'winwin_ez_travel',
            time: '1d',
            section: 'Yesterday',
            thumbnail: 'https://placeholder.com/150',
        },
        {
            id: '3',
            type: 'like_reel',
            username: 'musicjack7',
            time: '2d',
            section: 'This Week',
            thumbnail: 'https://placeholder.com/150',
            contentThumbnail: 'https://placeholder.com/150'
        },
        {
            id: '4',
            type: 'multiple_likes',
            username: 'officialjeffreydiamond',
            additionalUsers: 118,
            time: '2d',
            section: 'This Week',
            thumbnail: 'https://placeholder.com/150',
            contentThumbnail: 'https://placeholder.com/150'
        },
    ];

    const renderSectionHeader = (section: string) => (
        <View className="px-4 py-3">
            <Text className="text-base font-semibold">{section}</Text>
        </View>
    );

    return (
        <SafeAreaView className="flex-1 bg-white">
            <View className="flex-row items-center px-4 py-3 border-b border-gray-200">
                <TouchableOpacity onPress={() => navigation.goBack()}>
                    <ChevronLeft size={24} color="black" />
                </TouchableOpacity>
                <Text className="text-2xl font-bold ml-4">Activity</Text>
            </View>

            <TouchableOpacity className="flex-row items-center px-4 py-4 border-b border-gray-100">
                <View className="w-12 h-12 rounded-full bg-gray-100 items-center justify-center">
                    <Text>🌟</Text>
                </View>
                <View className="flex-1 ml-3">
                    <Text className="font-semibold text-base">Monetization & Shops</Text>
                    <Text className="text-gray-500">Branded content, monetization and shopping</Text>
                </View>
                <ChevronLeft size={24} color="black" style={{ transform: [{ rotate: '180deg' }] }} />
            </TouchableOpacity>

            {['Today', 'Yesterday', 'This Week'].map(section => (
                <View key={section}>
                    {renderSectionHeader(section)}
                    {notifications
                        .filter(notif => notif.section === section)
                        .map(notification => (
                            <NotificationItem key={notification.id} notification={notification} />
                        ))}
                </View>
            ))}
        </SafeAreaView>
    );
};

export default NotificationsScreen;
