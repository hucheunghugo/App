import { View, Image, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Text } from "~/components/ui/text";
import {useNavigation} from "@react-navigation/native";

interface PlaceCardProps {
    name: string;
    rating: number;
    reviews: number;
    imageUrl: string;
    time: string;
    price: string;
    onPress?: () => void;
}

function PlaceCard({ name, rating, reviews, imageUrl, time, price, onPress }: PlaceCardProps) {
    return (
        <TouchableOpacity
            className="mb-4 overflow-hidden rounded-xl bg-white"
            onPress={onPress}
        >
            <Image
                source={{ uri: imageUrl }}
                className="h-48 w-full"
            />
            <View className="p-3">
                <Text className="text-lg font-semibold">{name}</Text>
                <View className="mt-1 flex-row items-center">
                    <View className="flex-row">
                        {[...Array(5)].map((_, i) => (
                            <Ionicons
                                key={i}
                                name="star"
                                size={16}
                                color={i < rating ? "#FFD700" : "#E0E0E0"}
                            />
                        ))}
                    </View>
                    <Text className="ml-1 text-sm text-gray-600">({reviews} reviews)</Text>
                </View>
                <View className="mt-2 flex-row items-center justify-between">
                    <View className="flex-row items-center">
                        <Ionicons name="time-outline" size={16} color="#666" />
                        <Text className="ml-1 text-sm text-gray-600">{time}</Text>
                    </View>
                    <Text className="text-sm text-gray-600">{price}</Text>
                </View>
            </View>
        </TouchableOpacity>
    );
}

function DateSelector() {
    return (
        <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            className="mb-4"
        >
            {["December 3rd", "December 4th", "December 5th"].map((date, index) => (
                <TouchableOpacity
                    key={date}
                    className={`mr-3 rounded-full px-6 py-2 ${
                        index === 0 ? "bg-black" : "bg-gray-100"
                    }`}
                >
                    <Text className={index === 0 ? "text-white" : "text-gray-600"}>
                        {date}
                    </Text>
                </TouchableOpacity>
            ))}
        </ScrollView>
    );
}

export default function TripItineraryScreen() {
    const navigation = useNavigation()
    const places = [
        {
            id: '1',
            name: "Cafe de l'ambre",
            rating: 4.5,
            reviews: 1234,
            imageUrl: "https://example.com/cafe.jpg",
            time: "08:00 - 00:00 AM",
            price: "$30.00"
        },
        {
            id: '2',
            name: "Tokyo Tower",
            rating: 5,
            reviews: 5678,
            imageUrl: "https://example.com/tower.jpg",
            time: "09:00 AM - 12:00 PM",
            price: "$50.00"
        },
        {
            id: '3',
            name: "Tsukiji Tamra Sushi",
            rating: 4.8,
            reviews: 3456,
            imageUrl: "https://example.com/sushi.jpg",
            time: "12:00 - 15:00 PM",
            price: "$55.00"
        }
    ];

    return (
        <SafeAreaView className="flex-1 bg-gray-50">
            {/* Header */}
            <View className="p-4">
                <View className="flex-row items-center justify-between">
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={24} color="black" />
                    </TouchableOpacity>
                    <View className="flex-row">
                        <TouchableOpacity className="mr-4">
                            <Ionicons name="share-outline" size={24} color="black" />
                        </TouchableOpacity>
                        <TouchableOpacity>
                            <Ionicons name="ellipsis-horizontal" size={24} color="black" />
                        </TouchableOpacity>
                    </View>
                </View>

                {/* Title Section */}
                <View className="mt-4">
                    <Text className="text-2xl font-bold">Tokyo, Japan</Text>
                    <View className="mt-2">
                        <Image
                            source={{ uri: "https://example.com/map.jpg" }}
                            className="h-32 w-full rounded-xl"
                        />
                    </View>
                </View>

                {/* Date Selector */}
                <View className="mt-4">
                    <DateSelector />
                </View>
            </View>

            {/* Places List */}
            <ScrollView className="flex-1 px-4">
                {places.map((place) => (
                    <PlaceCard
                        key={place.id}
                        name={place.name}
                        rating={place.rating}
                        reviews={place.reviews}
                        imageUrl={place.imageUrl}
                        time={place.time}
                        price={place.price}
                        onPress={() => {}}
                    />
                ))}
            </ScrollView>

            {/* FAB */}
            <TouchableOpacity
                className="absolute bottom-6 right-6 rounded-full bg-black p-4"
                onPress={() => {}}
            >
                <Ionicons name="add" size={24} color="white" />
            </TouchableOpacity>
        </SafeAreaView>
    );
}
