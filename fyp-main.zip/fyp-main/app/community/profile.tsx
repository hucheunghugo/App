import React from 'react';
import {View, Text, Image, TouchableOpacity, ScrollView, Pressable} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import {Link, router, useFocusEffect, useLocalSearchParams} from 'expo-router';
import {getUserId} from "~/app/utils/userData";
import {useQuery} from "@tanstack/react-query";
import {loadMyPosts, loadMyTrips, postsQuery, userInfoQuery} from "~/app/query";
import {string} from "prop-types";

type MyTripData = {
  title: string;
  dateFrom: string;
  dateTo: string;
  description: string;
  imageUrl: string;
  onPress?: () => void;
};

interface MyPostData {
  id: number;
  title: string;
  likes: number;
  imageUrl: string;
  onPress?: () => void;
}

function MyTripCard({ title, dateFrom, dateTo, description, imageUrl, onPress }: MyTripData) {
  return (
      <TouchableOpacity
          className="mb-4 overflow-hidden rounded-xl bg-gray-100"
          onPress={onPress}
      >
        <View className="flex-row">
          <Image
              source={{ uri: imageUrl }}
              className="h-full w-36 rounded-xl"
          />
          <View className="flex-1 p-3 justify-center">
            <Text className="text-lg font-semibold">{title}</Text>
            <View className="mt-2">
              <View className="flex-row items-center">
                <Ionicons name="time-outline" size={16} color="#666" />
                <Text className="ml-1 text-sm text-gray-600">{"From: " + dateFrom +"       To: "+ dateTo}</Text>
              </View>
              <Text className="text-sm text-gray-600 mt-1">{"Description: " + description}</Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
  );
}

function MyPostCard({ title, likes, imageUrl, onPress }: MyPostData) {
  return (
      <TouchableOpacity
          className="mb-4 overflow-hidden rounded-xl bg-gray-100"
          onPress={onPress}
          style={{ height: 110 }} // Set a fixed height
      >
        <View className="flex-row h-full">
          <Image
              source={{ uri: imageUrl }}
              className="h-full w-36 rounded-xl"
          />
          <View className="flex-1 p-3 justify-center">
            <Text className="text-lg font-semibold">{title}</Text>
            <View className="mt-2">
              <View className="flex-row items-center">
                <Ionicons name="heart-outline" size={16} color="#666" />
                <Text className="ml-1 text-sm text-gray-600">{likes}</Text>
              </View>
              <Text className="text-sm text-gray-600 mt-1">{"Description: "}</Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
  );
}

export default function ProfileScreen() {
  const {user_id} = useLocalSearchParams() as { user_id: string };
  console.log(user_id)

  // Use the hook directly in your component
  const { data: userInfo, refetch: refetchInfo, isLoading: isLoadingInfo } = useQuery({
    queryKey: ['userInfo', user_id],
    queryFn: async () => {
      if (!user_id) throw new Error('User ID is not available');
      return userInfoQuery(Number(user_id));
    }
  });

  const { data: myTrips, refetch: refetchTrips, isLoading: isLoadingMyTrips } = useQuery({
    queryKey: ['myTrips'],
    queryFn: async () => {
      if (!user_id) throw new Error('User ID is not available');
      return loadMyTrips(Number(user_id));
    }
  });

  const { data: myPosts, refetch: refetchPosts, isLoading: isLoadingMyPosts } = useQuery({
    queryKey: ['myPosts'],
    queryFn: async () => {
      if (!user_id) throw new Error('User ID is not available');
      return loadMyPosts(Number(user_id));
    }
  });

  // Use focus effect to refetch data when the screen gains focus
  useFocusEffect(
      React.useCallback(() => {
        refetchTrips();
        refetchPosts();
        refetchInfo();
      }, [refetchTrips, refetchPosts, refetchInfo])
  );

  const TripSection = () => (
      <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          className="flex"
      >
        {myTrips?.map((tripData, index) => (
            <View key={index} className="mr-4" style={{ width: 280 }}>
              <Pressable>
                <MyTripCard
                    title={tripData.title || "Untitled Trip"}
                    description={tripData.description || ""}
                    dateFrom={tripData.dateFrom || ""}
                    dateTo={tripData.dateTo || ""}
                    imageUrl={tripData.imageUrl}
                    onPress={() => console.log(`Trip ${index} pressed`)}
                />
              </Pressable>
            </View>
        ))}
      </ScrollView>
  );

  const PostSection = () => (
      <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          className="flex"
      >
        {myPosts?.map((postData) => (
            <Link
                key={postData.id}
                href={{
                  pathname: '/posts',
                  params: { id: postData.id as unknown as string }
                }}
                asChild={true}
            >
              <View key={postData.id} className="mr-4" style={{ width: 280 }}>
                <Pressable>
                  <MyPostCard
                      id={postData.id}
                      title={postData.title || "Untitled Post"}
                      likes={postData.likes}
                      imageUrl={postData.imageUrl}
                      onPress={() => router.push({
                        pathname: '/posts',
                        params: {
                          PostID: postData.id,
                        }
                      })}
                  />
                </Pressable>
              </View>
            </Link>
        ))}
      </ScrollView>
  );




  // Sample data - replace with actual user data
  const userData = {
    name: 'Judy W. Adams',
    location: 'Gruenauer Strasse 29',
    followers: 5614,
    following: 2068,
    rewards: 103,
    about: 'By day I help some of Google\'s most valued Education partners share their vision with the world. By night, I design dresses inspired by the business women I see around me',
    photos: [
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8ZmFzaGlvbiUyMG1vZGVsfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60',
      'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8ZmFzaGlvbiUyMG1vZGVsfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60',
      'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8ZmFzaGlvbiUyMG1vZGVsfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60',
    ]
  };

  return (
    <SafeAreaView className="flex-1 bg-white">
      {/* Header */}
      <View className="bg-blue-500 pt-2 pb-2 h-48">
        <View className="flex-row justify-between items-center px-4">
          <TouchableOpacity
              onPress={() => router.back()}
          >
            <Ionicons name="arrow-back" size={24} color="white" />
          </TouchableOpacity>
          <Text className="text-white text-lg font-medium">Profile</Text>
          <View className="flex-row">
            <TouchableOpacity className="mr-4">
              <Ionicons name="search" size={24} color="white" />
            </TouchableOpacity>
            <TouchableOpacity>
              <Ionicons name="ellipsis-vertical" size={24} color="white" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Profile Info - centered vertically in remaining space */}
        <View className="flex-1 justify-center px-4">
          <View className="flex-row items-center">
            <Image
                source={{ uri: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60' }}
                className="w-20 h-20 rounded-full border-2 border-white"
            />
            <View className="ml-4">
              <Text className="text-white text-2xl font-semibold">{userInfo?.name}</Text>
              <Text className="text-white text-lg opacity-80">{userInfo?.email}</Text>
            </View>
            <TouchableOpacity className="ml-auto">
              <Ionicons name="pencil" size={20} color="white" />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      {/* Stats */}
      <View className="flex-row justify-around py-4 bg-white rounded-t-3xl -mt-2 shadow-sm">
        <View className="items-center">
          <View className="flex-row items-center mb-1">
            <Ionicons name="trail-sign-outline" size={16} color="#6B7280" />
          </View>
          <Text className="text-blue-500 font-bold text-xl">{userInfo?.postCount || 0}</Text>
          <Text className="text-gray-500 text-xs">Posts</Text>
        </View>
        <View className="items-center">
          <View className="flex-row items-center mb-1">
            <Ionicons name="file-tray-full-outline" size={16} color="#6B7280" />
          </View>
          <Text className="text-blue-500 font-bold text-xl">{userInfo?.tripCount || 0}</Text>
          <Text className="text-gray-500 text-xs">Trips</Text>
        </View>
        <View className="items-center">
          <View className="flex-row items-center mb-1">
            <Ionicons name="trophy-outline" size={16} color="#6B7280" />
          </View>
          <Text className="text-blue-500 font-bold text-xl">{userData.rewards}</Text>
          <Text className="text-gray-500 text-xs">Rewards</Text>
        </View>
      </View>

      <ScrollView className="flex-1 px-4">
        {/* About Section */}
        <View className="mt-6">
          <View className="flex-row items-center mb-2">
            <Ionicons name="chatbubble-ellipses-outline" size={20} color="#6B7280" />
            <Text className="ml-2 text-gray-800 font-medium text-lg">About</Text>
          </View>
          <Text className="text-gray-600 leading-5">{userData.about}</Text>
        </View>

        <View className="mt-2 mb-8">

          <View className="flex-row items-center">
            <Ionicons name="trail-sign-outline" size={20} color="#6B7280" />
            <Text className="ml-2 text-gray-800 font-medium text-lg">Trips</Text>
          </View>

          {isLoadingMyTrips ? (
              <Text>Loading trips...</Text>
          ) : myTrips && myTrips.length > 0 ? (
              <>
                <View>
                  {TripSection()}
                </View>
              </>
            ) : (
                <Text>No trips found</Text>
            )}

            {/* Divider */}
            <View className="h-0.5 bg-gray-200 my-1" />

          {/* Header row with icon and text horizontally aligned */}
          <View className="flex-row items-center">
            <Ionicons name="file-tray-full-outline" size={20} color="#6B7280" />
            <Text className="ml-2 text-gray-800 font-medium text-lg">Posts</Text>
          </View>
          {isLoadingMyPosts ? (
              <Text>Loading Posts...</Text>
          ) : myPosts && myPosts.length > 0 ? (
              <>
                  {/* Trip section on the next row */}
                  <View className="mt-2 mb-2">
                    {PostSection()}
                  </View>
              </>
          ) : (
              <Text>No posts found</Text>
          )}
        
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}