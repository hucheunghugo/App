import React from 'react';
import { Ionicons } from "@expo/vector-icons";
import { View, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { SafeAreaView } from "react-native-safe-area-context";
import { Text } from "~/components/ui/text";
// Import a more generic auth service instead of a hook
import  supabase  from '~/lib/supabase';
import {router} from "expo-router";
import {CommonActions, useNavigation} from "@react-navigation/native"; // Assuming this is your Supabase client

// Define proper TypeScript interfaces
interface SettingsSectionProps {
    title: string;
    children: React.ReactNode;
}

interface SettingsItemProps {
    icon: string;
    iconColor: string;
    title: string;
    subtitle?: string; // Make subtitle optional
    onPress: () => void;
    showBorder?: boolean;
}

export default function Settings() {
    const navigation = useNavigation();
    const handleLogout = async () => {
        try {
            navigation.dispatch(
                CommonActions.reset({
                    index: 0,
                    routes: [{ name: 'auth' }], // Change '/auth' to 'auth'
                })
            );

            // Web history handling remains the same
        } catch (error) {
            // Error handling
        }
    };

    // Handler for reset password
    const handleResetPassword = () => {
        Alert.alert(
            'Reset Password',
            'We will send a password reset link to your registered email address.',
            [
                { text: 'Cancel', style: 'cancel' },
                {
                    text: 'Send Reset Link',
                    onPress: async () => {
                        try {
                            // Example implementation with Supabase
                            // You would typically prompt for email first
                            const email = 'user@example.com'; // Replace with actual user email
                            const { error } = await supabase.auth.resetPasswordForEmail(email);
                            if (error) throw error;
                            Alert.alert('Success', 'Password reset link has been sent to your email.');
                        } catch (error) {
                            Alert.alert('Error', 'Failed to send reset link. Please try again.');
                            console.error('Reset password error:', error);
                        }
                    }
                },
            ]
        );
    };

    // Settings section component with proper typing
    const SettingsSection: React.FC<SettingsSectionProps> = ({ title, children }) => (
        <View className="mb-6">
            <Text className="text-lg font-bold mb-2 text-gray-800">{title}</Text>
            <View className="bg-white rounded-xl overflow-hidden shadow-sm">
                {children}
            </View>
        </View>
    );

    // Settings item component with proper typing
    const SettingsItem: React.FC<SettingsItemProps> = ({
                                                           icon,
                                                           iconColor,
                                                           title,
                                                           subtitle,
                                                           onPress,
                                                           showBorder = true
                                                       }) => (
        <TouchableOpacity
            className={`px-4 py-3 flex-row items-center ${showBorder ? 'border-b border-gray-100' : ''}`}
            onPress={onPress}
        >
            <View className="w-10 h-10 rounded-full bg-gray-100 items-center justify-center mr-3">
                <Ionicons name={icon as any} size={22} color={iconColor} />
            </View>
            <View className="flex-1">
                <Text className="text-base font-medium">{title}</Text>
                {subtitle && <Text className="text-sm text-gray-500">{subtitle}</Text>}
            </View>
            <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
        </TouchableOpacity>
    );

    return (
        <SafeAreaView className="flex-1 bg-gray-50">
            <View className="bg-blue-500 pt-2 pb-2 h-24">
                <View className="flex-1 justify-center px-4">
                    <View className="flex-row items-center">
                        <Text className="text-white text-xl font-bold">Settings</Text>
                    </View>
                </View>
            </View>

            <ScrollView className="flex-1 px-4 pt-4">
                {/* Account Settings Section */}
                <SettingsSection title="Account Settings">
                    <SettingsItem
                        icon="person-outline"
                        iconColor="#3B82F6"
                        title="Profile Information"
                        subtitle="Update your personal details"
                        onPress={() => router.push({
                        pathname: '/community/profileEdit'
                    })}
                    />
                    <SettingsItem
                        icon="notifications-outline"
                        iconColor="#10B981"
                        title="Notifications"
                        subtitle="Manage notification preferences"
                        onPress={() => Alert.alert('Notifications', 'Navigate to notification settings')}
                    />
                    <SettingsItem
                        icon="lock-closed-outline"
                        iconColor="#F59E0B"
                        title="Reset Password"
                        subtitle="Change your account password"
                        onPress={handleResetPassword}
                    />
                    <SettingsItem
                        icon="log-out-outline"
                        iconColor="#EF4444"
                        title="Logout"
                        subtitle="Sign out from your account"
                        onPress={handleLogout}
                        showBorder={false}
                    />
                </SettingsSection>

                {/* Preferences Section */}
                <SettingsSection title="Preferences">
                    <SettingsItem
                        icon="moon-outline"
                        iconColor="#8B5CF6"
                        title="Dark Mode"
                        subtitle="Toggle between light and dark theme"
                        onPress={() => Alert.alert('Dark Mode', 'Toggle dark mode functionality')}
                    />
                    <SettingsItem
                        icon="globe-outline"
                        iconColor="#EC4899"
                        title="Language"
                        subtitle="Choose your preferred language"
                        onPress={() => Alert.alert('Language', 'Language selection options')}
                        showBorder={false}
                    />
                </SettingsSection>

                {/* General Section */}
                <SettingsSection title="General">
                    <SettingsItem
                        icon="information-circle-outline"
                        iconColor="#6366F1"
                        title="About"
                        subtitle="App information and version"
                        onPress={() => Alert.alert('About', 'App version: 1.0.0')}
                    />
                    <SettingsItem
                        icon="document-text-outline"
                        iconColor="#14B8A6"
                        title="Terms of Service"
                        subtitle="Legal information"
                        onPress={() => Alert.alert('Terms', 'View terms of service')}
                    />
                    <SettingsItem
                        icon="shield-checkmark-outline"
                        iconColor="#0EA5E9"
                        title="Privacy Policy"
                        subtitle="How we handle your data"
                        onPress={() => Alert.alert('Privacy', 'View privacy policy')}
                        showBorder={false}
                    />
                </SettingsSection>

                {/* Help & Support Section */}
                <SettingsSection title="Help & Support">
                    <SettingsItem
                        icon="help-circle-outline"
                        iconColor="#8B5CF6"
                        title="FAQ"
                        subtitle="Frequently asked questions"
                        onPress={() => Alert.alert('FAQ', 'View frequently asked questions')}
                    />
                    <SettingsItem
                        icon="chatbubble-ellipses-outline"
                        iconColor="#F59E0B"
                        title="Contact Support"
                        subtitle="Get help with app issues"
                        onPress={() => Alert.alert('Contact', 'Contact customer support')}
                        showBorder={false}
                    />
                </SettingsSection>

                <View className="py-8 items-center">
                    <Text className="text-gray-400 text-sm">App Version 1.0.0</Text>
                </View>
            </ScrollView>
        </SafeAreaView>
    );
}