import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { getUserId } from "~/app/utils/userData";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { userInfoQuery } from "~/app/query";
import supabase from "~/lib/supabase";

export default function ProfileEditScreen() {
    const [username, setUsername] = useState<string>('');
    const [originalUsername, setOriginalUsername] = useState<string>('');
    const [isSaving, setIsSaving] = useState<boolean>(false);
    const [error, setError] = useState<string>('');

    const queryClient = useQueryClient();

    // Fetch current user info
    const { data: userInfo, isLoading: isLoadingInfo } = useQuery({
        queryKey: ['userInfo'],
        queryFn: async () => {
            const userId = await getUserId();
            if (!userId) throw new Error('User ID is not available');
            return userInfoQuery(userId);
        }
    });

    // Set up initial values when data loads
    useEffect(() => {
        if (userInfo && userInfo.name) {
            setUsername(userInfo.name);
            setOriginalUsername(userInfo.name);
        }
    }, [userInfo]);

    // Update profile mutation
    const updateProfile = useMutation({
        mutationFn: async (newUsername: string) => {
            const userId = await getUserId();
            if (!userId) throw new Error('User ID is not available');

            // Check if username is already taken (except by current user)
            const { data: existingUsers, error: checkError } = await supabase
                .from('users')
                .select('id')
                .eq('name', newUsername)
                .neq('id', userId);

            if (checkError) throw checkError;

            if (existingUsers && existingUsers.length > 0) {
                throw new Error('Username is already taken');
            }

            // Update user profile
            const { data, error } = await supabase
                .from('users')
                .update({ name: newUsername })
                .eq('id', userId)
                .select();

            if (error) throw error;
            return data;
        },
        onSuccess: () => {
            // Invalidate the userInfo query to refetch with new data
            queryClient.invalidateQueries({ queryKey: ['userInfo'] });
            Alert.alert('Success', 'Profile updated successfully');
            router.back();
        },
        onError: (error) => {
            setError(error.message);
            Alert.alert('Error', error.message);
        },
        onSettled: () => {
            setIsSaving(false);
        }
    });

    const handleSave = () => {
        // Validation
        if (!username.trim()) {
            setError('Username cannot be empty');
            return;
        }

        // Check if username has changed
        if (username === originalUsername) {
            router.back();
            return;
        }

        // Save changes
        setIsSaving(true);
        setError('');
        updateProfile.mutate(username);
    };

    const handleUsernameChange = (text: string) => {
        setUsername(text);
    };

    return (
        <SafeAreaView className="flex-1 bg-white">
            {/* Header */}
            <View className="flex-row items-center justify-between bg-blue-500 px-4 py-4">
                <TouchableOpacity onPress={() => router.back()} className="p-1">
                    <Ionicons name="arrow-back" size={24} color="#fff" />
                </TouchableOpacity>
                <Text className="text-lg font-semibold text-white">Edit Profile</Text>
                <TouchableOpacity
                    onPress={handleSave}
                    className={`rounded px-3 py-1.5 bg-white bg-opacity-20 ${isSaving ? "opacity-70" : ""}`}
                    disabled={isSaving}
                >
                    {isSaving ? (
                        <ActivityIndicator size="small" color="#fff" />
                    ) : (
                        <Text className="text-white font-semibold">Save</Text>
                    )}
                </TouchableOpacity>
            </View>

            {/* Content */}
            <View className="flex-1 p-5">
                {isLoadingInfo ? (
                    <ActivityIndicator size="large" color="#3b82f6" className="mt-10" />
                ) : (
                    <>
                        <Text className="text-base font-medium text-gray-700 mb-2">Username</Text>
                        <TextInput
                            className="border border-gray-300 rounded-lg px-3 py-2.5 text-base mb-1.5"
                            value={username}
                            onChangeText={handleUsernameChange}
                            placeholder="Enter your username"
                            autoCapitalize="none"
                        />
                        {error ? <Text className="text-red-500 mb-2.5">{error}</Text> : null}

                        <Text className="text-gray-500 text-sm mt-3 leading-5">
                            Your username is visible to all users and is used to identify you on the platform.
                        </Text>
                    </>
                )}
            </View>
        </SafeAreaView>
    );
}