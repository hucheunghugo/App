import React from "react";
import {SafeAreaView} from "react-native-safe-area-context";
import {Image, TouchableOpacity, View} from "react-native";
import {Ionicons} from "@expo/vector-icons";
import {Text} from "~/components/ui/text";
import {useQuery} from "@tanstack/react-query";
import {getUserId} from "~/app/utils/userData";
import {loadMyPosts, loadMyTrips, loadSavedPosts, loadSavedTrips} from "~/app/query";
import {router} from "expo-router";

interface SavedPostData {
    id: number;
    title: string;
    likes: number;
    imageUrl: string;
    onPress?: () => void;
}

type SavedTripData = {
    id: number;
    title: string;
    dateFrom: string;
    dateTo: string;
    description: string;
    imageUrl: string;
    onPress?: () => void;
};

function SavedPostCard({ id, title, likes, imageUrl, onPress }: SavedPostData) {
    return (
        <TouchableOpacity
            className="m-1 overflow-hidden rounded-xl bg-white shadow-md"
            onPress={onPress}
            style={{ height: 180, width: '48%' }}
        >
            <View className="h-full">
                {/* Image at the top */}
                <Image
                    source={{ uri: imageUrl }}
                    className="h-2/3 w-full"
                    resizeMode="cover"
                />

                {/* Content at the bottom */}
                <View className="flex-1 p-2 justify-between">
                    <Text className="text-sm font-bold" numberOfLines={1}>
                        {title}
                    </Text>

                    <View className="flex-row items-center justify-between mt-1">
                        <View className="flex-row items-center">
                            <Ionicons name="heart" size={14} color="#FF1493" />
                            <Text className="ml-1 text-xs text-gray-600">{likes}</Text>
                        </View>
                        <View className="bg-blue-100 px-2 py-1 rounded-full">
                            <Text className="text-xs text-blue-600">View</Text>
                        </View>
                    </View>
                </View>
            </View>
        </TouchableOpacity>
    );
}

function SavedTripCard({ id, title, dateFrom, dateTo, imageUrl, onPress }: SavedTripData) {
    // Format dates to be more readable
    const formatDate = (dateString: string) => {
        if (!dateString) return "";
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        } catch (e) {
            return dateString;
        }
    };

    const formattedDateFrom = formatDate(dateFrom);
    const formattedDateTo = formatDate(dateTo);

    return (
        <TouchableOpacity
            className="m-1 overflow-hidden rounded-xl bg-white shadow-md"
            onPress={onPress}
            style={{ height: 180, width: '48%' }}
        >
            <View className="h-full">
                {/* Image at the top */}
                <Image
                    source={{ uri: imageUrl }}
                    className="h-2/3 w-full"
                    resizeMode="cover"
                />

                {/* Content at the bottom */}
                <View className="flex-1 p-2 justify-between">
                    <Text className="text-sm font-bold" numberOfLines={1}>
                        {title || "Untitled Trip"}
                    </Text>

                    <View className="flex-row items-center justify-between mt-1">
                        <View className="flex-row items-center">
                            <Ionicons name="calendar-outline" size={14} color="#1E90FF" />
                            <Text className="ml-1 text-xs text-gray-600">
                                {formattedDateFrom} - {formattedDateTo}
                            </Text>
                        </View>
                        <View className="bg-blue-100 px-2 py-1 rounded-full">
                            <Text className="text-xs text-blue-600">View</Text>
                        </View>
                    </View>
                </View>
            </View>
        </TouchableOpacity>
    );
}

export default function Saved() {
    const [isPost, setIsPost] = React.useState<boolean>(true);
    const [isTrip, setIsTrip] = React.useState<boolean>(false);
    const toggle = () => {
        setIsPost(!isPost);
        setIsTrip(!isTrip);
    }

    const { data: savedPosts, refetch: refetchPosts, isLoading: isLoadingSavedPosts } = useQuery({
        queryKey: ['savedPosts'],
        queryFn: async () => {
            const userId = await getUserId();
            if (!userId) throw new Error('User ID is not available');
            return loadSavedPosts(userId);
        }
    });

    const { data: savedTrips, refetch: refetchTrips, isLoading: isLoadingSavedTrips } = useQuery({
        queryKey: ['savedTrips'],
        queryFn: async () => {
            const userId = await getUserId();
            if (!userId) throw new Error('User ID is not available');
            return loadSavedTrips(userId);
        }
    });

    // Function to chunk the array into pairs for the 2-column layout
    const chunkArray = <T,>(array: T[] | undefined, size: number) => {
        if (!array) return [];
        const chunkedArr = [];
        for (let i = 0; i < array.length; i += size) {
            chunkedArr.push(array.slice(i, i + size));
        }
        return chunkedArr;
    };

    // Group posts and trips into pairs for the 2-column layout
    const postRows = chunkArray(savedPosts || [], 2);
    const tripRows = chunkArray(savedTrips || [], 2);

    return (
        <SafeAreaView className="flex-1 bg-white">
            <View className="bg-blue-500 pt-2 pb-2 h-24">
                <View className="flex-1 justify-center px-4">
                    <View className="flex-row items-center">
                        <TouchableOpacity
                            className="bg-white rounded-full p-2 mr-2"
                            onPress={() => router.back()}
                        >
                            <Ionicons name="arrow-back" size={20} color="#333" />
                        </TouchableOpacity>

                        <Text className="text-white text-xl font-bold">My Collections</Text>
                    </View>
                </View>
            </View>

            <View className="flex-row justify-around py-4 bg-white rounded-t-3xl -mt-2 shadow-sm">
                <View className="items-center">
                    <View className="flex-row items-center mb-1">
                        <TouchableOpacity
                            className={`rounded-xl px-16 py-2 mr-4 ${isPost ? 'bg-[#FF1493]' : 'bg-gray-300'}`}
                            onPress={() => {
                                if (!isPost) {
                                    toggle();
                                }
                            }}
                        >
                            <View className="flex-row items-center">
                                <Ionicons name="file-tray-full-outline" size={20} color={isPost ? 'white' : 'black'} />
                                <Text className={`ml-2 ${isPost ? 'text-white' : 'text-black'}`}>Posts</Text>
                            </View>
                        </TouchableOpacity>

                        <TouchableOpacity
                            className={`rounded-xl px-16 py-2 ${isTrip ? 'bg-[#FF1493]' : 'bg-gray-300'}`}
                            onPress={() => {
                                if (!isTrip) {
                                    toggle();
                                }
                            }}
                        >
                            <View className="flex-row items-center">
                                <Ionicons name="airplane-outline" size={20} color={isTrip ? 'white' : 'black'} />
                                <Text className={`ml-2 ${isTrip ? 'text-white' : 'text-black'}`}>Trips</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>

            {/* Content Container */}
            <View className="flex-1 px-2 pt-4">
                {isPost && (
                    <>
                        {isLoadingSavedPosts ? (
                            <View className="flex-1 items-center justify-center">
                                <Text>Loading...</Text>
                            </View>
                        ) : savedPosts && savedPosts.length > 0 ? (
                            <View>
                                {postRows.map((row, rowIndex) => (
                                    <View key={`row-${rowIndex}`} className="flex-row justify-between mb-2">
                                        {row.map((post) => (
                                            <SavedPostCard
                                                key={post.id}
                                                id={post.id}
                                                title={post.title || "Untitled Post"}
                                                likes={post.likes || 0}
                                                imageUrl={post.imageUrl}
                                                onPress={() => router.push({
                                                    pathname: '/posts',
                                                    params: {
                                                        PostID: post.id,
                                                    }
                                                })}
                                            />
                                        ))}
                                        {/* If we have an odd number of items, add an empty view to maintain grid layout */}
                                        {row.length === 1 && <View style={{ width: '48%' }} />}
                                    </View>
                                ))}
                            </View>
                        ) : (
                            <View className="flex-1 items-center justify-center">
                                <Ionicons name="bookmark-outline" size={64} color="#DDD" />
                                <Text className="text-gray-400 mt-4">No saved posts yet</Text>
                            </View>
                        )}
                    </>
                )}

                {isTrip && (
                    <>
                        {isLoadingSavedTrips ? (
                            <View className="flex-1 items-center justify-center">
                                <Text>Loading...</Text>
                            </View>
                        ) : savedTrips && savedTrips.length > 0 ? (
                            <View>
                                {tripRows.map((row, rowIndex) => (
                                    <View key={`trip-row-${rowIndex}`} className="flex-row justify-between mb-2">
                                        {row.map((trip) => (
                                            <SavedTripCard
                                                key={trip.id}
                                                id={trip.id}
                                                title={trip.title || "Untitled Trip"}
                                                dateFrom={trip.dateFrom}
                                                dateTo={trip.dateTo}
                                                description={trip.description || ""}
                                                imageUrl={trip.imageUrl}
                                                onPress={() => router.push({
                                                    pathname: '/trip',
                                                    params: {
                                                        id: trip.id,
                                                    }
                                                })}
                                            />
                                        ))}
                                        {/* If we have an odd number of items, add an empty view to maintain grid layout */}
                                        {row.length === 1 && <View style={{ width: '48%' }} />}
                                    </View>
                                ))}
                            </View>
                        ) : (
                            <View className="flex-1 items-center justify-center">
                                <Ionicons name="airplane-outline" size={64} color="#DDD" />
                                <Text className="text-gray-400 mt-4">No saved trips yet</Text>
                            </View>
                        )}
                    </>
                )}
            </View>
        </SafeAreaView>
    );
}