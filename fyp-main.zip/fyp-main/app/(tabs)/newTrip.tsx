import {View, Text, TextInput, TouchableOpacity, ScrollView, Image} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {Ionicons} from '@expo/vector-icons';
import {useNavigation} from '@react-navigation/native';
import {useState} from 'react';
import {Link} from "expo-router";
import {Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle} from "~/components/ui/card";
import * as React from "react";

export default function ChatScreen() {
    const [userInput, setUserInput] = useState('');
    const navigation = useNavigation();

    const suggestedQuestions = [
        "How is the weather like today in Hong Kong?",
        "Food under $75 in Mong Kok",
        "Recommend a top 10 trip"
    ];

    return (
        <SafeAreaView className="flex-1 bg-white">
            <ScrollView className="flex-1">
                {/* Header */}
                <View className="px-4 pt-4">
                    <Text className="mb-4 text-4xl font-bold">New Item</Text>
                </View>

                {/* Suggested Questions */}
                <View className="mt-8 px-4 gap-4">
                    <Link
                        className="text-center text-lg font-semibold text-white"
                        href={{
                            pathname: '/trip/new',
                        }}>
                        <Card className='w-full'>
                            <Image
                                source={{uri: 'https://plus.unsplash.com/premium_photo-1661887292499-cbaefdb169ce?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG9uZyUyMGtvbmclMjBza3lsaW5lfGVufDB8fDB8fHww'}}
                                className="h-48 w-full rounded-t-lg"
                            />
                            <CardHeader>
                                <CardTitle>Trip</CardTitle>
                                <CardDescription>Card Description</CardDescription>
                            </CardHeader>
                        </Card>
                    </Link>
                    <Link
                        className="text-center text-lg font-semibold text-white"
                        href={{
                            pathname: '/posts/new',
                        }}>
                        <Card className='w-full'>
                            <Image
                                source={{uri: 'https://plus.unsplash.com/premium_photo-1661887292499-cbaefdb169ce?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG9uZyUyMGtvbmclMjBza3lsaW5lfGVufDB8fDB8fHww'}}
                                className="h-48 w-full rounded-t-lg"
                            />
                            <CardHeader>
                                <CardTitle>Posts</CardTitle>
                                <CardDescription>Card Description</CardDescription>
                            </CardHeader>
                        </Card>
                    </Link>


                </View>
            </ScrollView>
        </SafeAreaView>
);
}
