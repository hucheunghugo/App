import FontAwesome from '@expo/vector-icons/FontAwesome';
import { Tabs } from 'expo-router';
import {ThemeToggle} from "~/components/ThemeToggle";
import {MapPin, MessageSquare, Plus, Settings, User} from "lucide-react-native";
import {Pressable} from "react-native";
import {BottomSheetModal, BottomSheetView} from "@gorhom/bottom-sheet";
import {Text} from './../../components/ui/text'
import {useCallback, useRef} from "react";
export default function TabLayout() {
    const bottomSheetModalRef = useRef<BottomSheetModal>(null);

    // callbacks
    const handlePresentModalPress = useCallback(() => {
        bottomSheetModalRef.current?.present();
    }, []);
    const handleSheetChanges = useCallback((index: number) => {
        console.log('handleSheetChanges', index);
    }, []);
  return (
      <Tabs screenOptions={{ tabBarActiveTintColor: 'blue', tabBarHideOnKeyboard: true, headerShown:false, }}>
        <Tabs.Screen
            name="index"
            options={{
              title: 'Home',
              tabBarIcon: ({ color }) => <FontAwesome size={28} name="home" color={color} />,
                headerRight: () => <ThemeToggle/>
            }}
        />
        <Tabs.Screen
            name="trips"
            options={{
                title: 'My Trip',
              tabBarIcon: ({ color }) => <MapPin size={28} color={color} />,
            }}
        />
          <Tabs.Screen
              name="newTrip"
              options={{
                  title: 'Add',
                  tabBarIcon: ({ color }) => <Plus color={color} />,
              }}
          />
          <Tabs.Screen
              name="chat"
              options={{
                  title: 'Chat',
                  tabBarIcon: ({ color }) => <MessageSquare color={color} />,
              }}
          />
          <Tabs.Screen
              name="me"
              options={{
                  title: 'Me',
                  tabBarIcon: ({ color }) => <User color={color} />,
              }}
          />
      </Tabs>
  );
}
