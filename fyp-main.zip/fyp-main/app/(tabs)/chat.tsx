import { View, Text, TextInput, TouchableOpacity, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useState } from 'react';
import {Link} from "expo-router";

export default function ChatScreen() {
    const [userInput, setUserInput] = useState('');
    const navigation = useNavigation();

    const suggestedQuestions = [
        "How is the weather like today in Hong Kong?",
        "Food under $75 in Mong Kok",
        "Recommend a top 10 trip"
    ];

    return (
        <SafeAreaView className="flex-1 bg-white">
            <ScrollView className="flex-1">
                {/* Header */}
                <View className="px-4 pt-4">
                    <Text className="mb-4 text-4xl font-bold">TripGenie</Text>
                </View>

                {/* AI Assistant Icon */}
                <View className="items-center justify-center py-4">
                    <View className="h-16 w-16">
                        <Ionicons name="chatbubble-ellipses-outline" size={64} color="black" />
                    </View>
                </View>

                {/* Main Question */}
                <View className="items-center px-4 py-6">
                    <Text className="text-3xl font-semibold">How can I help you?</Text>
                </View>

                {/* Input Section */}
                <View className="px-4">
                    <View className="mb-4 overflow-hidden rounded-lg bg-gray-100">
                        <TextInput
                            placeholder="Placeholder"
                            className="px-4 py-3 text-base"
                            placeholderTextColor="#666"
                            value={userInput}
                            onChangeText={setUserInput}
                        />
                    </View>
                    <Link
                        className="text-center text-lg font-semibold text-white"
                        asChild={true}
                        href={{
                            pathname: '/(message)',
                            params: { initialMessage: userInput }
                        }}>
                        <TouchableOpacity
                            className="rounded-lg bg-[#FF1493] py-4"
                        >
                            <Text className="text-center text-lg font-semibold text-white">
                                Continue
                            </Text>
                        </TouchableOpacity>
                    </Link>
                </View>

                {/* Suggested Questions */}
                <View className="mt-8 px-4">
                    {suggestedQuestions.map((question, index) => (

                        <Link
                        className="text-center text-lg font-semibold text-white"
                        asChild={true}
                    href={{
                        pathname: '/(message)',
                        params: { initialMessage: question }
                    }}>
                            <TouchableOpacity
                                key={index}
                                className="mb-4 rounded-lg border border-gray-200 bg-white p-4"
                            >
                                <Text className="text-lg">{question}</Text>
                            </TouchableOpacity>
                </Link>
                    ))}
                </View>
            </ScrollView>
        </SafeAreaView>
    );
}
