import React, {useCallback, useState, useEffect} from 'react';
import {View, Text, Image, TouchableOpacity, ScrollView, Pressable, Modal, TextInput} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import {Link, router, useFocusEffect, useRouter} from 'expo-router';
import {getUserId} from "~/app/utils/userData";
import {useQuery} from "@tanstack/react-query";
import {loadMyPosts, loadMyTrips, postsQuery, userInfoQuery, usernameQuery} from "~/app/query";
import {string} from "prop-types";
import supabase from "~/lib/supabase";
import { debounce } from 'lodash'; // Make sure to import lodash or implement your own debounce

type MyTripData = {
  id: number;
  title: string;
  dateFrom: string;
  dateTo: string;
  description: string;
  imageUrl: string;
  onPress?: () => void;
};

interface MyPostData {
  id: number;
  title: string;
  likes: number;
  imageUrl: string;
  onPress?: () => void;
}

function MyTripCard({ title, dateFrom, dateTo, description, imageUrl, onPress }: MyTripData) {
  return (
      <TouchableOpacity
          className="mb-4 overflow-hidden rounded-xl bg-gray-100"
          onPress={onPress}
      >
        <View className="flex-row">
          <Image
              source={{ uri: imageUrl }}
              className="h-full w-36 rounded-xl"
          />
          <View className="flex-1 p-3 justify-center">
            <Text className="text-lg font-semibold">{title}</Text>
            <View className="mt-2">
              <View className="flex-row items-center">
                <Ionicons name="time-outline" size={16} color="#666" />
                <Text className="ml-1 text-sm text-gray-600">{"From: " + dateFrom +"       To: "+ dateTo}</Text>
              </View>
              <Text className="text-sm text-gray-600 mt-1">{"Description: " + description}</Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
  );
}

function MyPostCard({ title, likes, imageUrl, onPress }: MyPostData) {
  return (
      <TouchableOpacity
          className="mb-4 overflow-hidden rounded-xl bg-gray-100"
          onPress={onPress}
          style={{ height: 110 }} // Set a fixed height
      >
        <View className="flex-row h-full">
          <Image
              source={{ uri: imageUrl }}
              className="h-full w-36 rounded-xl"
          />
          <View className="flex-1 p-3 justify-center">
            <Text className="text-lg font-semibold">{title}</Text>
            <View className="mt-2">
              <View className="flex-row items-center">
                <Ionicons name="heart-outline" size={16} color="#666" />
                <Text className="ml-1 text-sm text-gray-600">{likes}</Text>
              </View>
              <Text className="text-sm text-gray-600 mt-1">{"Description: "}</Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
  );
}

export default function ProfileScreen() {
  const [searchModalVisible, setSearchModalVisible] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const userId = getUserId();

  // Use the hook directly in your component
  const { data: userInfo, refetch: refetchInfo, isLoading: isLoadingInfo } = useQuery({
    queryKey: ['userInfo', userId],
    queryFn: async () => {
      const userId = await getUserId();
      if (!userId) throw new Error('User ID is not available');
      return userInfoQuery(userId);
    }
  });

  const { data: myTrips, refetch: refetchTrips, isLoading: isLoadingMyTrips } = useQuery({
    queryKey: ['myTrips'],
    queryFn: async () => {
      const userId = await getUserId();
      if (!userId) throw new Error('User ID is not available');
      return loadMyTrips(userId);
    }
  });

  const { data: myPosts, refetch: refetchPosts, isLoading: isLoadingMyPosts } = useQuery({
    queryKey: ['myPosts'],
    queryFn: async () => {
      const userId = await getUserId();
      if (!userId) throw new Error('User ID is not available');
      return loadMyPosts(userId);
    }
  });

  // Use focus effect to refetch data when the screen gains focus
  useFocusEffect(
      React.useCallback(() => {
        refetchTrips();
        refetchPosts();
        refetchInfo();
      }, [refetchTrips, refetchPosts, refetchInfo])
  );

  // Properly implement debounce for search
  const debouncedSearch = useCallback(
      debounce(async (input: string) => {
        if (!input || input.length === 0) {
          setSearchResults([]);
          setIsSearching(false);
          return;
        }

        try {
          setIsSearching(true);
          const { data, error } = await usernameQuery(input);
          if (error) throw error;
          setSearchResults(data || []);
        } catch (error) {
          console.error('Error searching users:', error);
        } finally {
          setIsSearching(false);
        }
      }, 300), // 300ms delay - adjust as needed
      []
  );

  // Handle search input changes
  const handleSearchChange = (text: string) => {
    setSearchQuery(text);
    if (text.length > 0) {
      setIsSearching(true);
      debouncedSearch(text);
    } else {
      setSearchResults([]);
      setIsSearching(false);
    }
  };

  // Clear search
  const clearSearch = () => {
    setSearchQuery('');
    setSearchResults([]);
    setIsSearching(false);
  };

  // Cache search results
  const [searchCache, setSearchCache] = useState<{[key: string]: any[]}>({});

  // Use the cache when possible
  useEffect(() => {
    if (searchQuery && searchCache[searchQuery]) {
      setSearchResults(searchCache[searchQuery]);
      setIsSearching(false);
    }
  }, [searchQuery, searchCache]);

  // Update cache with new results
  useEffect(() => {
    if (searchQuery && searchResults.length > 0) {
      setSearchCache(prev => ({...prev, [searchQuery]: searchResults}));
    }
  }, [searchQuery, searchResults]);

  const TripSection = () => (
      <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          className="flex"
      >
        {myTrips?.map((tripData, index) => (
            <View key={index} className="mr-4" style={{ width: 280 }}>
              <Pressable>
                <MyTripCard
                    id={tripData.id}
                    title={tripData.title || "Untitled Trip"}
                    description={tripData.description || ""}
                    dateFrom={tripData.dateFrom || ""}
                    dateTo={tripData.dateTo || ""}
                    imageUrl={tripData.imageUrl}
                    onPress={() => router.push({
                      pathname: '/trip',
                      params: {
                        id: tripData.id,
                      }
                    })}
                />
              </Pressable>
            </View>
        ))}
      </ScrollView>
  );

  const PostSection = () => (
      <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          className="flex"
      >
        {myPosts?.map((postData) => (
            <View key={postData.id} className="mr-4" style={{ width: 280 }}>
              <Pressable>
                <MyPostCard
                    id={postData.id}
                    title={postData.title || "Untitled Post"}
                    likes={postData.likes}
                    imageUrl={postData.imageUrl}
                    onPress={() => router.push({
                      pathname: '/posts',
                      params: {
                        PostID: postData.id,
                      }
                    })}
                />
              </Pressable>
            </View>
        ))}
      </ScrollView>
  );

  return (
      <SafeAreaView className="flex-1 bg-white">
        {/* Modal with proper spacing at the top */}
        <Modal
            animationType="slide"
            transparent={false}
            visible={searchModalVisible}
            onRequestClose={() => {
              setSearchModalVisible(false);
              clearSearch();
            }}
        >
          <SafeAreaView style={{ flex: 1, backgroundColor: 'white', marginTop: 20 }}>
            <View className="px-4 py-2 bg-blue-500">
              <View className="flex-row items-center">
                <TouchableOpacity
                    onPress={() => {
                      setSearchModalVisible(false);
                      clearSearch();
                    }}
                    className="mr-2">
                  <Ionicons name="arrow-back" size={24} color="white" />
                </TouchableOpacity>
                <View className="flex-1 flex-row bg-white rounded-full px-3 py-1 items-center">
                  <Ionicons name="search" size={20} color="gray" />
                  <TextInput
                      className="flex-1 ml-2 text-base"
                      placeholder="Search users..."
                      value={searchQuery}
                      onChangeText={handleSearchChange}
                      autoFocus
                  />
                  {searchQuery.length > 0 && (
                      <TouchableOpacity onPress={clearSearch}>
                        <Ionicons name="close-circle" size={20} color="gray" />
                      </TouchableOpacity>
                  )}
                </View>
              </View>
            </View>

            <ScrollView className="flex-1 px-4 pt-2">
              {/* Loading indicator */}
              {isSearching && (
                  <View className="py-4 items-center">
                    <Text className="text-gray-500">Searching...</Text>
                  </View>
              )}

              {/* Search results */}
              {!isSearching && searchResults.map((user, index) => (
                  <TouchableOpacity
                      key={index}
                      className="flex-row items-center py-3 border-b border-gray-200"
                      onPress={() => {
                        setSearchModalVisible(false);
                        clearSearch();
                        // Since your query might not return IDs, we need to adjust
                        router.push({
                          pathname: '/community/profile',
                          params: {user_id: user.id as unknown as string }
                        });
                      }}
                  >
                    <View className="w-10 h-10 bg-blue-100 rounded-full items-center justify-center">
                      <Text className="text-blue-500 font-bold">{user.name.charAt(0)}</Text>
                    </View>
                    <View className="ml-3">
                      <Text className="font-medium">{user.name}</Text>
                    </View>
                  </TouchableOpacity>
              ))}

              {!isSearching && searchQuery.length > 0 && searchResults.length === 0 && (
                  <View className="py-4 items-center">
                    <Text className="text-gray-500">No users found</Text>
                  </View>
              )}
            </ScrollView>
          </SafeAreaView>
        </Modal>

        {/* Header */}
        <View className="bg-blue-500 pt-2 pb-2 h-40">
          <View className="flex-row justify-between items-center px-4 mt-2">
            <Text className="text-white text-lg font-medium">Profile</Text>
            <View className="flex-row">
              <TouchableOpacity className="mr-4" onPress={() => setSearchModalVisible(true)}>
                <Ionicons name="search" size={24} color="white" />
              </TouchableOpacity>
              <TouchableOpacity
                  onPress={() => router.push({
                    pathname: '/community/settings',
                  })}>
                <Ionicons name="settings-outline" size={24} color="white" />
              </TouchableOpacity>
            </View>
          </View>

          {/* Profile Info - centered vertically in remaining space */}
          <View className="flex-1 justify-center px-4">
            <View className="flex-row items-center">
              <Image
                  source={{ uri: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60' }}
                  className="w-20 h-20 rounded-full border-2 border-white"
              />
              <View className="ml-4">
                <Text className="text-white text-2xl font-semibold">{userInfo?.name}</Text>
                <Text className="text-white text-lg opacity-80">{userInfo?.email}</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Stats */}
        <View className="flex-row justify-around py-4 bg-white rounded-t-3xl -mt-2 shadow-sm">
          <View className="items-center">
            <View className="flex-row items-center mb-1">
              <Ionicons name="trail-sign-outline" size={16} color="#6B7280" />
            </View>
            <Text className="text-blue-500 font-bold text-xl">{userInfo?.postCount || 0}</Text>
            <Text className="text-gray-500 text-xs">Posts</Text>
          </View>
          <View className="items-center">
            <View className="flex-row items-center mb-1">
              <Ionicons name="file-tray-full-outline" size={16} color="#6B7280" />
            </View>
            <Text className="text-blue-500 font-bold text-xl">{userInfo?.tripCount || 0}</Text>
            <Text className="text-gray-500 text-xs">Trips</Text>
          </View>
          <View className="items-center">
            <View className="flex-row items-center mb-1">
              <TouchableOpacity
                  onPress={() => router.push({
                    pathname: '/community/saved'
                  })}>
                <Ionicons name="bookmark-outline" size={16} color="#6B7280" />
              </TouchableOpacity>
            </View>
            <TouchableOpacity
                onPress={() => router.push({
                  pathname: '/community/saved'
                })}>
            <Text className="text-blue-500 font-bold text-xl">{userInfo?.saveCount || 0}</Text>
            </TouchableOpacity>
            <TouchableOpacity
                onPress={() => router.push({
                  pathname: '/community/saved'
                })}>
            <Text className="text-gray-500 text-xs">Saved</Text>
            </TouchableOpacity>
          </View>
        </View>

        <ScrollView className="flex-1 px-4">

          {/* Photos Section */}
          <View className="mt-6 mb-8">
            {isLoadingMyTrips ? (
                <Text>Loading your trips...</Text>
            ) : myTrips && myTrips.length > 0 ? (
                <>
                  {/* Top section - Horizontal Scrolling */}
                  <View className="mb-2">

                    <View className="flex-row items-center">
                      <Ionicons name="trail-sign-outline" size={20} color="#6B7280" />
                      <Text className="ml-2 text-gray-800 font-medium text-lg">Trips</Text>
                    </View>

                    <View className="mt-2">
                      {TripSection()}
                    </View>
                  </View>

                  {/* Divider */}
                  <View className="h-0.5 bg-gray-200 my-1" />

                  {/* Bottom section - Vertical layout */}
                  <View className="mb-2">
                    {/* Header row with icon and text horizontally aligned */}
                    <View className="flex-row items-center">
                      <Ionicons name="file-tray-full-outline" size={20} color="#6B7280" />
                      <Text className="ml-2 text-gray-800 font-medium text-lg">Posts</Text>
                    </View>

                    {/* Trip section on the next row */}
                    <View className="mt-2">
                      {PostSection()}
                    </View>
                  </View>
                </>
            ) : (
                <Text>No trips found. Create your first trip!</Text>
            )}
          </View>
        </ScrollView>
      </SafeAreaView>
  );
}