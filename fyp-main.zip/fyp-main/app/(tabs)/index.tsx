import {
    View,
    StyleSheet,
    Image,
    Pressable,
    TouchableOpacity,
    TextInput,
    ScrollView,
    Linking,
    Alert, ActivityIndicator
} from 'react-native';
import DefaultCard from "~/components/DefaultCard";
import * as React from "react";
import { SafeAreaView } from 'react-native-safe-area-context';
import {Ionicons} from "@expo/vector-icons";
import {Link, useFocusEffect} from "expo-router";
import supabase from "~/lib/supabase";
import { useQuery} from "@tanstack/react-query";
import GetLocation from "react-native-get-location";
import {useEffect, useState} from "react";
import {Text} from "~/components/ui/text";
import {Skeleton} from "~/components/ui/skeleton";
import {fetchImages, postsQuery, tripsQuery} from '../query';
import userInfoScreen from "~/app/auth/userInfo"; // Adjust the path as necessary

type DisplayDataType = Posts[] | Trips[];

interface Posts{
    id: number,
    title: string,
    username: string | null
}

interface Trips{
    id: number,
    title: string,
    username: string | null
}

// Create a separate component for the post image
const PostImage = ({ postId }: { postId: string }) => {
    const { data: imageURL = [] } = useQuery({
        queryKey: ['images', postId],
        queryFn: () => fetchImages(postId),
        enabled: !!postId,
    });

    return (
        <Image
            source={{ uri: imageURL[0] || 'https://plus.unsplash.com/premium_photo-1661887292499-cbaefdb169ce?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG9uZyUyMGtvbmclMjBza3lsaW5lfGVufDB8fDB8fHww' }}
            className="h-48 w-full rounded-t-lg"
        />
    );
};


export default function Tab() {
    const [isPost, setIsPost] = React.useState<boolean>(true);
    const [isTrip, setIsTrip] = React.useState<boolean>(false);
    const [displayData, setDisplayData] = useState<DisplayDataType>([]);
    const [currentLocation, setCurrentLocation] = useState<string>('')


    const {data:location, isLoading} = useQuery({
        queryKey:['getGeolocation'],
        queryFn: async () => await GetLocation.getCurrentPosition({
            enableHighAccuracy: true,
            timeout: 60000,
        })
    })
    const {data: formattedAddress, isLoading: addressIsLoading} = useQuery({
        queryKey: ['geocoding'],
        queryFn: async () => {
            const response = await fetch(
                `${process.env.EXPO_PUBLIC_API_URL}/api/locations/geocode?latitude=${location?.latitude}&longitude=${location?.longitude}`
            );
            const data = await response.json();
            const formattedAddress = data.results[0]?.formatted_address;
            setCurrentLocation(formattedAddress);
            return formattedAddress;
        },
        enabled: !isLoading && !!location?.latitude && !!location?.longitude,
    });

    const {data: nearbyData, isLoading: nearbyIsLoading} = useQuery({
        queryKey: ['nearbyItems'],
        queryFn: async () => {
            const response = await fetch(
                `${process.env.EXPO_PUBLIC_API_URL}/api/locations/nearby?latitude=${location?.latitude}&longitude=${location?.longitude}`
            );
            const data = await response.json();
            return data;
        },
        enabled: !isLoading && !!location?.latitude && !!location?.longitude,
    });

    //Post Loading
    const usePosts = (isPost: boolean) => {
        const { data: posts, refetch: refetchPosts, isLoading: isLoadingPost } = useQuery<Posts[]>({
            queryKey: ['posts'],
            queryFn: () => postsQuery(),
            enabled: isPost, // Now it's properly used
        });

        return { posts, refetchPosts, isLoadingPost };
    };

    const { posts, refetchPosts, isLoadingPost } = usePosts(isPost);

    const loadImage = ({ postId }: { postId: string }) => {
        const { data: imageURL = [] } = useQuery({
            queryKey: ['images', postId],
            queryFn: () => fetchImages(postId),
            enabled: !!postId,
        });

        return (
            <Image
                source={{ uri: imageURL[0] || 'https://plus.unsplash.com/premium_photo-1661887292499-cbaefdb169ce?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG9uZyUyMGtvbmclMjBza3lsaW5lfGVufDB8fDB8fHww' }}
                className="h-48 w-full rounded-t-lg"
            />
        );
    };

    //Trip Loading
    const useTrips = (isTrip: boolean) => {
        const { data: trips, refetch: refetchTrips,  isLoading: isLoadingTrip } = useQuery<Trips[]>({
            queryKey: ['trips'],
            queryFn: () => tripsQuery(),
            enabled: isTrip, // Now it's properly used
        });

        return { trips, refetchTrips, isLoadingTrip };
    };

    const { trips, refetchTrips, isLoadingTrip } = useTrips(isTrip);

    useFocusEffect(
        React.useCallback(() => {
            refetchTrips();
            refetchPosts();
        }, [refetchTrips, refetchPosts])
    );

    const openGoogleMaps = (address: string) => {
        // Encode the address for use in URL
        const encodedAddress = encodeURIComponent(address);
        // Create the Google Maps search URL
        const url = `https://www.google.com/maps/search/?api=1&query=${encodedAddress}`;

        Linking.openURL(url)
            .then((supported) => {
                if (supported) {
                    return true
                } else {
                    Alert.alert("Error", "Unable to open Google Maps");
                }
            })
            .catch((err) => Alert.alert("Error", err.message));
    };

    const toggle = () =>{
        setIsPost(!isPost);
        setIsTrip(!isTrip);
    }

    return (
        <SafeAreaView className="flex-1 bg-gray-50 mt-2">
            <ScrollView>
                {/* Current Location Header */}
                <View className="my-2 px-4 ">
                    <Text className="text-gray-500 mb-2">Current location</Text>
                    <View className="flex-row items-center justify-between">
                        <View className="flex-row items-center flex-1 mr-4">
                            <Ionicons name="location" size={24} color="#FF1493" />
                            {addressIsLoading || isLoading ? (
                                <Skeleton className='h-12 w-12 rounded-full' />
                            ) : (
                                <Text numberOfLines={1} className="ml-2 text-lg font-semibold flex-1">{formattedAddress}</Text>
                            )}
                        </View>
                        <Link href={'/notifications'} asChild={true}>
                            <TouchableOpacity>
                                <View className="relative">
                                    <Ionicons name="notifications-outline" size={24} color="black" />
                                    <View className="absolute -right-1 -top-1 h-3 w-3 rounded-full bg-red-500" />
                                </View>
                            </TouchableOpacity>
                        </Link>
                    </View>
                </View>

                {/* Search Bar */}
                <View className="mx-4 mb-4 my-4">
                    <View className="flex-row items-center rounded-lg bg-white px-4 py-3">
                        <Link href={'/search'} asChild={true}>
                            <TextInput
                                placeholder="Search for trips, location..."
                                className="flex-1 text-gray-600"
                            />
                        </Link>
                    </View>
                </View>

                {/* Next Location Section */}
                <View className="px-4">
                    <View className="flex-row items-center justify-between">
                        <Text className="text-xl font-semibold">Attractions nearby</Text>
                        <Link href={{ pathname: '/locations' }}>
                            <TouchableOpacity>
                                <Text className="text-[#FF1493]">See more</Text>
                            </TouchableOpacity>
                        </Link>
                    </View>

                    <ScrollView className={"gap-4"} horizontal={true}>
                        {nearbyData?.data.map(attraction => (
                            <View key={attraction.id} className="mt-4 rounded-lg bg-white p-4 mr-4 max-w-xl">
                                <View className="flex-row">
                                    <Image
                                        source={{ uri: 'https://plus.unsplash.com/premium_photo-1661887292499-cbaefdb169ce?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG9uZyUyMGtvbmclMjBza3lsaW5lfGVufDB8fDB8fHww' }}
                                        className="h-24 w-24 rounded-lg"
                                    />
                                    <View className="ml-4">
                                        <Text className="text-lg font-semibold">{attraction.name}</Text>
                                        <Text className="text-gray-500 line-clamp-2 break-words">
                                            {attraction.address_obj.address_string}
                                        </Text>
                                        <TouchableOpacity
                                            className="mt-2 flex-row items-center"
                                            onPress={() => openGoogleMaps(attraction.name + ' ' + attraction.address_obj.address_string)}
                                        >
                                            <Ionicons name="location" size={20} color="#FF1493" />
                                            <Text className="ml-2 text-[#FF1493]">GET DIRECTIONS</Text>
                                        </TouchableOpacity>
                                    </View>
                                </View>
                            </View>
                        ))}
                    </ScrollView>
                </View>

                {/* Explore Section */}
                <View className="mt-6 px-4">
                    <View className="flex-row items-center justify-between">
                        <Text className="text-xl font-semibold">Explore</Text>
                        <TouchableOpacity>
                            <Text className="text-[#FF1493]">See all</Text>
                        </TouchableOpacity>
                    </View>

                    {/* Navigation Pills */}
                    <View className="mt-4 flex-row space-x-4">
                        <TouchableOpacity
                            className={`rounded-full px-6 py-2 mr-2 ${isPost ? 'bg-[#FF1493]' : 'bg-gray-300'}`} // Change background color based on isPost
                            onPress={() => {
                                if (!isPost) {
                                    toggle();
                                }
                            }}
                        >
                            <View className="flex-row items-center">
                                <Ionicons name="home" size={20} color={isPost ? 'white' : 'black'} /> {/* Change icon color based on isPost */}
                                <Text className={`ml-2 ${isPost ? 'text-white' : 'text-black'}`}>Posts</Text> {/* Change text color based on isPost */}
                            </View>
                        </TouchableOpacity>

                        <TouchableOpacity
                            className={`rounded-full px-6 py-2 mr-2 ${isTrip ? 'bg-[#FF1493]' : 'bg-gray-300'}`} // Change background color based on isTrip
                            onPress={() => {
                                if (!isTrip) {
                                    toggle();
                                }
                            }}
                        >
                            <View className="flex-row items-center">
                                <Ionicons name="airplane-outline" size={20} color={isTrip ? 'white' : 'black'} /> {/* Change icon color based on isTrip */}
                                <Text className={`ml-2 ${isTrip ? 'text-white' : 'text-black'}`}>Trips</Text> {/* Change text color based on isTrip */}
                            </View>
                        </TouchableOpacity>
                    </View>

                    {/* Trip Cards */}
                    {isLoadingPost || isLoadingTrip ? (
                        <View className="mt-4">
                            {/* <Text className="text-gray-500">Loading...</Text> */}
                            {/* Optionally, you can use a spinner here */}
                            <ActivityIndicator size="large" color="#FF1493" />
                        </View>
                    ) : isPost ? (
                        posts?.map(post => (
                            <Link
                                key={post.id}
                                href={{
                                    pathname: '/posts',
                                    params: { PostID: post.id as unknown as string }
                                }}
                                asChild={true}
                            >
                                <Pressable className="mt-4">
                                    <View className="rounded-lg bg-white">
                                        <PostImage postId={post.id.toString()} />
                                        <View className="p-4">
                                            <View className="flex-row items-center justify-between">
                                                <Text className="text-lg font-semibold">{post.title}</Text>
                                                <View className="flex-row items-center">
                                                    <Ionicons name="star" size={16} color="gold" />
                                                    <Text className="ml-1">5.0</Text>
                                                </View>
                                            </View>
                                            <Text className="text-gray-500" numberOfLines={1}>{post.username}</Text>
                                        </View>
                                    </View>
                                </Pressable>
                            </Link>
                        ))
                    ) : isTrip ? (
                        trips?.map(trip => (
                            <Link
                                key={trip.id}
                                href={{
                                    pathname: '/trip',
                                    params: { id: trip.id as unknown as string }
                                }}
                                asChild={true}
                            >
                                <Pressable className="mt-4">
                                    <View className="rounded-lg bg-white">
                                        <Image
                                            source={{ uri: 'https://plus.unsplash.com/premium_photo-1661887292499-cbaefdb169ce?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG9uZyUyMGtvbmclMjBza3lsaW5lfGVufDB8fDB8fHww' }}
                                            className="h-48 w-full rounded-t-lg"
                                        />
                                        <View className="p-4">
                                            <View className="flex-row items-center justify-between">
                                                <Text className="text-lg font-semibold">{trip.title}</Text>
                                                <View className="flex-row items-center">
                                                    <Ionicons name="star" size={16} color="gold" />
                                                    <Text className="ml-1">5.0</Text>
                                                </View>
                                            </View>
                                            <Text className="text-gray-500" numberOfLines={1}>{trip.username}</Text>
                                        </View>
                                    </View>
                                </Pressable>
                            </Link>
                        ))
                    ) : (
                        <Text className="text-gray-500 mt-4">No posts or trips available.</Text>
                    )}
                </View>
            </ScrollView>
        </SafeAreaView>
    );
}
